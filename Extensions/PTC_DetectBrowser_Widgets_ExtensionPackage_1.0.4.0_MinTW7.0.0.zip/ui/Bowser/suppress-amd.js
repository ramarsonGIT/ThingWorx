window.defineBackup = window.define;
window.define = undefined;
