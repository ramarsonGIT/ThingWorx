window.define = window.defineBackup;
window.defineBackup = undefined;
