TW.Runtime.Widgets.detectbrowser= function () {
	var thisWidget = this;
    thisWidget.debug = false;

	this.renderHtml = function () {
		var html = '<div class="widget-content widget-detectbrowser" style="display: none;">Detect Browser</div>';
		return html;
	};

	this.afterRender = function () {
        thisWidget.debug = this.getProperty('Debug', false);
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
        switch (updatePropertyInfo.TargetProperty) {
            case 'Debug' :
            	log("updateProperty(): Debug=" + updatePropertyInfo.RawSinglePropertyValue, true);
                thisWidget.debug = updatePropertyInfo.RawSinglePropertyValue;
                break;
        }
	};

    this.serviceInvoked = function (serviceName) {
    	if (serviceName === 'GetBrowserProperties') {
    	    const parser = bowser.getParser(window.navigator.userAgent);
    	    let result = parser.getResult();
    	    // Later iPads say they are MacOS so apply a workaround to indicate they are indeed a tablet
    	    // https://stackoverflow.com/questions/58019463/how-to-detect-device-name-in-safari-on-ios-13-while-it-doesnt-show-the-correct
    	    if (result.platform.type === 'desktop' && window.navigator.platform === 'MacIntel' && window.navigator.maxTouchPoints > 1) {
	    	    result.platform.type = 'tablet';
	    	}
    	    thisWidget.setProperty('BrowserProperties', result);
    	    log('serviceInvoked(): BrowserProperties=' + JSON.stringify(result));
    	}
    	if (serviceName === 'GetWindowNavigator') {
    		// Serialize the object in another object
    		// https://stackoverflow.com/questions/4970202/serialize-javascripts-navigator-object
    	    var _navigator = {};
    	    for (var i in navigator) {
    	    	_navigator[i] = navigator[i];
    	    }
    	    thisWidget.setProperty('WindowNavigator', _navigator);
    	    log('serviceInvoked(): WindowNavigator=' + JSON.stringify(_navigator));
    	}
    };

    /**
     * Print console messages if debugging is turned on.
     * Usage examples:
     *   log("foo"); // prints "foo" to the console and ThingWorx log if debug is on
     *   log("foo", true); // prints "foo" to the console and ThingWorx log regardless of the debug setting
     *   log("foo", true, "WARN"); // print "foo" to the console and ThingWorx log regardless of the debug setting using the WARN log level
     *   log("foo", false, "TRACE"); // print "foo" to the console and ThingWorx log only if debug is on using the TRACE log level
     */
    function log(str = "", forceLog = false, logLevel = "DEBUG") {
        forceLog = typeof forceLog !== 'undefined' ? forceLog : false;
        logLevel = typeof logLevel !== 'undefined' ? logLevel : "DEBUG";
        if (thisWidget.debug || forceLog) {
        	var message = "[" + thisWidget.jqElementId + "] " + str;
        	console.log("[" + logLevel.toUpperCase().padEnd(5) + "] " + message);
            switch (logLevel.toUpperCase()) {
	            case 'TRACE' :
	                TW.log.trace(message);
	                break;
	            case 'DEBUG' :
	                TW.log.debug(message);
	                break;
	            case 'INFO' :
	                TW.log.info(message);
	                break;
	            case 'WARN' :
	                TW.log.warn(message);
	                break;
	            case 'ERROR' :
	                TW.log.error(message);
	                break;
	            case 'FATAL' :
	                TW.log.fatal(message);
	                break;
	        }
        }
    };

};
