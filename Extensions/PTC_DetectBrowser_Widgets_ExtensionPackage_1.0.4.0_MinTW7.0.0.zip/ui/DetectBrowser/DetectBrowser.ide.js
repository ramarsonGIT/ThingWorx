TW.IDE.Widgets.detectbrowser = function () {

	this.widgetIconUrl = function() {
		return  "../Common/extensions/PTC_DetectBrowser_Widgets_ExtensionPackage/ui/DetectBrowser/DetectBrowser.png";
	};

	this.widgetProperties = function () {
		return {
			'name': 'Detect Browser',
			'description': 'Detect browser properties',
			'category': ['Common'],
            'properties': {
                'BrowserProperties': {
                	'baseType': 'JSON',
                	'isVisible': true,
                	'isBindingSource': true
                },
	            'WindowNavigator': {
	            	'baseType': 'JSON',
	            	'isVisible': true,
	            	'isBindingSource': true
	            },
                'Debug': {
                    'description' : 'If true, turn on debug logging to the console',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                }
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		return false;
	};

	this.renderHtml = function () {
		return 	'<div class="widget-content widget-detectbrowser" style="background: #333; color: #FFF;">Detect Browser</div>';
	};

	this.afterRender = function () {
	};
        
    this.widgetServices = function () {
        return {
        	'GetBrowserProperties': { 'warnIfNotBound': false },
        	'GetWindowNavigator': { 'warnIfNotBound': false }
        };
    };

};