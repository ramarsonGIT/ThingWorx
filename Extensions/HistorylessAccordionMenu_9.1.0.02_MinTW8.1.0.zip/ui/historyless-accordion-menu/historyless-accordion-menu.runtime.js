var twaccordionContext = new Array();

(function () {
    TW.Runtime.Widgets["historyless-accordion-menu"] = function () {
        "use strict";
        var thisWidget = this;

        this.ignoreSelectionEvent = false;
        this.firstChild = undefined;
        this.selectedValue = "";
        this.currentOpen = '';
        this.currentOpenMashup = '';
        this.definitionRows;

        this.menuToMashupMap;
        this.mashupParams;

        this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': true
            };
        };

        this.setUpMapping = function() {
            var data = this.getProperty('_DataToParamMappings');
            if (data && data.length > 0) {
                // reset map obj
                this.menuToMashupMap = {};
                this.mashupParams = [];
                var menuDataKey, mashupParamKey;
                for(var i=0,l=data.length;i<l;i++) {
                    menuDataKey = data[i]['menuDataField'];
                    mashupParamKey = data[i]['mashupParam'] || menuDataKey;
                    this.menuToMashupMap[menuDataKey] = mashupParamKey;
                    this.mashupParams.push(mashupParamKey);
                }
            }
        };

        this.openCurrentMenuIfNeeded = function (useDefault) {
            var uri = window.location.href;
            var el = thisWidget.jqElement;
            if (el) {
                var foundItem;
                var mashup = uri.match(new RegExp('mashup=([^&|#]*)'));
                if (mashup) {
                    foundItem = el.find('[data-mashup="' + mashup[1] + '"]');
                    if (foundItem.length > 0) {
                        if (this !== undefined && this.mashupParams && this.mashupParams.length > 0) {
                            var urlParam;
                            for (var i=0,l=this.mashupParams.length;i<l;i++) {
                                urlParam = uri.match(new RegExp(this.mashupParams[i]+ '=([^&|#]*)'));
                                if (urlParam) {
                                    foundItem = foundItem.filter('[data-'+ this.mashupParams[i].toLowerCase()
                                            + '="' + urlParam[1] + '"]');
                                }
                            }
                        }
                    }
                }
                if ((!foundItem || foundItem.length === 0) && useDefault) {
                    foundItem = foundItem.find('[data-dflt="true"]');
                } else if (foundItem.length > 1 && useDefault) {
                    foundItem = foundItem.filter('[data-dflt="true"]');
                }
                if (foundItem) {
                    foundItem = foundItem.first();
                    var parentMenu = foundItem.data('parent');
                    if (parentMenu !== thisWidget.currentOpen) {
                        thisWidget.currentOpen = parentMenu;
                        el.find(".down").removeClass("down");
                        el.find(".accordion-child").slideUp();
                        el.find("." + parentMenu).slideDown();
                        el.find("#" + parentMenu).addClass("down");
                    }
                    el.find(".AChildSClass").removeClass("AChildSClass");
                    foundItem.addClass("AChildSClass");
                }
            }
        };

        this.renderHtml = function () {
            var html = '<div class="widget-content widget-accordion" style="padding:'
                    + this.getProperty('Padding') + '"></div>';

            this.setUpMapping();

            var fn = this.openCurrentMenuIfNeeded;
            $(window).on('hashchange', function () {
                fn();
            });
            if (this.getProperty('ConfiguredOrDataDriven') === 'configured') {
                this.updateMenu(this.getProperty('Menu'));
            }
            return html;
        };

        this.redirectFromItemClick = function (itemClicked, asHash) {
            var mashup = itemClicked.data("mashup");
            var params = this.generateUrlParams(itemClicked);
            var target = (itemClicked.data("linkTarget") || 'self').toLowerCase();
            switch (target) {
                case 'new':
                    window.open(this.generateNewUrl(mashup, params), '_blank');
                    break;
                case 'popup':
                case 'modalpopup':
                    if (mashup) {
                        var fn;
                        thisWidget.showPopup(mashup, params, fn, fn,
                                (target === 'modalpopup'), '', 0, 0, 0.5,
                                false, "accordionMenuDialog-" + TW.createUUID(), true, true);
                    }
                    break;
                default:
                    if (asHash) {
                        window.location.hash = this.generateNewUrl(mashup, params, true);
                    } else {
                        // This is the only difference between the conver-accordion-menu
                        // and the historyless-accordion-menu (this widget).
                        // This solution was put in place to not save navigation clicks 
                        // in the browser history. This resolves bug FACTORY-2508.
                        window.location.replace(this.generateNewUrl(mashup, params));
                    }
                    break;
            }
        };

        this.generateUrlParams = function(el) {
            if (el && this.mashupParams) {
                var params = [];
                for (var i=0,l=this.mashupParams.length;i<l;i++) {
                    params.push({
                        key: this.mashupParams[i],
                        value: el.data(this.mashupParams[i].toLowerCase())
                    });
                }
                return params;
            }
            return null;
        };

        this.generateNewUrl = function (mashup, params, asHash) {
            var url = window.location.href;
            var separator = url.indexOf('#') !== -1 ? "&" : "#";
            var key, re;
            if (mashup) {
                key = "mashup";
                re = new RegExp("([?&|#])" + key + "=.*?(&|$)", "i");
                if (url.match(re)) {
                    url = url.replace(re, '$1' + key + "=" + mashup + '$2');
                } else {
                    url += separator + key + "=" + mashup;
                    separator = "&";
                }
            }
            if (params) {
                var value, keyMatch;
                for (var i = 0, l = params.length; i < l; i++) {
                    key = params[i].key;
                    value = params[i].value;
                    if (value) {
                        re = new RegExp("([?&|#])" + key + "=.*?(&|$)", "i");
                        if (url.match(re)) {
                            url = url.replace(re, '$1' + key + "=" + value + '$2');
                        } else {
                            url += separator + key + "=" + value;
                            separator = "&";
                        }
                    } else {
                        keyMatch = url.match(new RegExp(key + '=([^&|#]*)'));
                        if (keyMatch) {
                            url = url.replace(keyMatch[1], "");
                        }
                    }
                }
            }
            if (asHash) {
                url = url.substring(url.indexOf('#'));
            }
            return url;
        };

        this.updateMenu = function (menuName) {
            if (menuName === undefined || menuName === null || menuName.length === 0) {
                return;
            }

            var invoker = new ThingworxInvoker({
                entityType: 'Menus',
                entityName: menuName,
                characteristic: 'Services',
                target: 'GetEffectiveMenu',
                apiMethod: 'post'
            });

            invoker.invokeService(function (invoker) {
                thisWidget.buildMenu(invoker.result.rows);
            });
        };

        this.buildMenu = function (rows) {
            var html = "";
            var baseId = "";
            var lastGroup = "";
            var index = 0;
            var areaClass = thisWidget.getProperty('AreaStyle', 'DefaultLabelStyle');
            var titleClass = thisWidget.getProperty('TitleStyle', 'DefaultLabelStyle');
            var titleHoverClass = thisWidget.getProperty('TitleHoverStyle', 'DefaultLabelStyle');
            var childClass = thisWidget.getProperty('ChildStyle', 'DefaultLabelStyle');
            var childHoverClass = thisWidget.getProperty('ChildHoverStyle', 'DefaultLabelStyle');
            var childSelectedClass = thisWidget.getProperty('ChildSelectedStyle', 'DefaultLabelStyle');

            var areaStyle = TW.getStyleCssTextualFromStyleDefinition(areaClass);
            var titleStyle = TW.getStyleCssTextualFromStyleDefinition(titleClass);
            var titleHoverStyle = TW.getStyleCssTextualFromStyleDefinition(titleHoverClass);
            var childStyle = TW.getStyleCssTextualFromStyleDefinition(childClass);
            var childHoverStyle = TW.getStyleCssTextualFromStyleDefinition(childHoverClass);
            var childSelectedStyle = TW.getStyleCssTextualFromStyleDefinition(childSelectedClass);

            var areaSize = TW.getStyleFromStyleDefinition(areaClass).textSize;
            var titleSize = TW.getStyleFromStyleDefinition(titleClass).textSize;
            var childSize = TW.getStyleFromStyleDefinition(childClass).textSize;

            html += '<style>\n\n';
            html += '.AAreaClass { ' + areaStyle + ' }\n\n';
            html += '.ATitleClass { ' + titleStyle + ' }\n\n';
            html += '.ATitleHClass { ' + titleHoverStyle + ' }\n\n';
            html += '.AChildClass { ' + childStyle + ' }\n\n';
            html += '.AChildHClass { ' + childHoverStyle + ' }\n\n';
            html += '.AChildSClass { ' + childSelectedStyle + ' }\n\n';
            html += '</style>\n\n';

            var groupOption = this.getProperty('Groupings'),
                    groupField = this.getProperty('GroupField'),
                    titleSeparator = this.getProperty('TitleSeparator'),
                    group, titleItems;

            for (var i = 0, l = rows.length; i < l; i++) {
                var row = rows[i];
                if (row["parentMenuId"]) {
                    var title = TW.Runtime.convertLocalizableString(row["title"]);
                    if (baseId === row["parentMenuId"]) {
                        index++;
                        switch (groupOption) {
                            case 'field':
                                group = row[groupField] ?
                                        TW.Runtime.convertLocalizableString(row[groupField]) : "";
                                break;
                            case 'separator':
                                if (title.indexOf(titleSeparator) !== -1) {
                                    titleItems = title.split(titleSeparator);
                                    group = titleItems[0];
                                    title = "";
                                    for (var j = 1, tl = titleItems.length; j < tl; j++) {
                                        title += ((j > 1 ? titleSeparator : "") + titleItems[j]);
                                    }
                                }
                                break;
                            default:
                                group = "";
                                break;
                        }
                        if (group && group != lastGroup) {
                            lastGroup = group;
                            html += '<div class="accordion-area AAreaClass textsize-' + areaSize + '">'
                                    + group + '</div>';
                        }
                        var noChildClass = row["linkType"] == 'Mashup' ? 'accordion-parent-nochild ' : "";
                        html += '<div id="' + thisWidget.jqElementId + '_' + index
                                + '" class="accordion-parent '
                                + noChildClass + 'ATitleClass textsize-' + titleSize
                                + '" data-mashup="' + (row['linkDestination'] ? window.twHtmlUtilities.encodeHtml(row['linkDestination']) : "") + '"'
                                + this.genMashupParamDataString(row)
                                + (row['isDefault'] ? ' data-dflt="' + row['isDefault'] + '"' : "")
                                + ' data-link-target="' + (row['linkTarget'] ? row['linkTarget'] : "Self") + '"'
                                + '>' + window.twHtmlUtilities.encodeHtml(title);
                        var icon = row['imageURL'];
                        if (icon) {
                            html += '<div class="icon" style="pointer-events:none"><img src="'
                                    + TW.convertImageLink(icon) + '" style="pointer-events:none" width="30" height="30"/></div>';
                        }
                        html += '</div>';
                    } else {
                        html += '<div class="accordion-child ' + thisWidget.jqElementId
                                + '_' + index + ' AChildClass textsize-' + childSize
                                + '" style="display:none;"'
                                + ' data-mashup="' + row['linkDestination'] + '"'
                                + this.genMashupParamDataString(row)
                                + (row['isDefault'] ? ' data-dflt="' + row['isDefault'] + '"' : '')
                                + ' data-link-target="' + (row['linkTarget'] ? row['linkTarget'] : "Self") + '"'
                                + ' data-parent="' + thisWidget.jqElementId + '_' + index + '"'
                                + '>' + title + '</div>';
                    }
                } else {
                    baseId = row["menuId"];
                }
            }

            thisWidget.jqElement.html(html);

            thisWidget.jqElement.off('click', '.accordion-parent');
            thisWidget.jqElement.on('click', '.accordion-parent', function (e) {
                e.stopPropagation();
                var itemClicked = $(e.target);
                if (!itemClicked.is('.accordion-parent-nochild')) {
                    if (!$("." + itemClicked.attr("id")).is(":visible")) {
                        $(".down").removeClass("down");
                        $(".accordion-child").slideUp();
                        $("." + itemClicked.attr("id")).slideDown();
                        $("#" + itemClicked.attr("id")).addClass("down");
                    } else {
                        $("." + itemClicked.attr("id")).slideUp();
                        $(".down").removeClass("down");
                    }
                } else {
                    thisWidget.redirectFromItemClick(itemClicked);
                }
            });
            thisWidget.jqElement.off('mouseover', '.accordion-parent');
            thisWidget.jqElement.on('mouseover', '.accordion-parent', function (e) {
                e.stopPropagation();
                var itemOver = $(e.target);
                itemOver.removeClass("ATitleClass");
                itemOver.addClass("ATitleHClass");
            });
            thisWidget.jqElement.off('mouseout', '.accordion-parent');
            thisWidget.jqElement.on('mouseout', '.accordion-parent', function (e) {
                e.stopPropagation();
                var itemOver = $(e.target);
                itemOver.removeClass("ATitleHClass");
                itemOver.addClass("ATitleClass");
            });

            thisWidget.jqElement.off('mouseover', '.accordion-child');
            thisWidget.jqElement.on('mouseover', '.accordion-child', function (e) {
                e.stopPropagation();
                var itemOver = $(e.target);
                itemOver.removeClass("AChildClass");
                itemOver.addClass("AChildHClass");
            });
            thisWidget.jqElement.off('mouseout', '.accordion-child');
            thisWidget.jqElement.on('mouseout', '.accordion-child', function (e) {
                e.stopPropagation();
                var itemOver = $(e.target);
                itemOver.removeClass("AChildHClass");
                itemOver.addClass("AChildClass");
            });

            thisWidget.jqElement.off('click', '.accordion-child');
            thisWidget.jqElement.on('click', '.accordion-child', function (e) {
                e.stopPropagation();
                $(".AChildSClass").removeClass("AChildSClass");
                var itemClicked = $(e.target);
                //thisWidget.jqElement.triggerHandler('Clicked');
                itemClicked.addClass("AChildSClass");
                thisWidget.currentOpen = itemClicked.data('parent');
                thisWidget.redirectFromItemClick(itemClicked, true);
            });

            this.openCurrentMenuIfNeeded(true);
        };

        this.genMashupParamDataString = function(rowData) {
            var str = "";
            if (this.menuToMashupMap) {
                for (var key in this.menuToMashupMap) {
                    if (this.menuToMashupMap.hasOwnProperty(key)) {
                        // jquery will convert camelcase,
                        // so just force lowercase attribute name
                        str += ' data-' + this.menuToMashupMap[key].toLowerCase() +
                             '="' + (rowData[key] ? rowData[key] : "") + '"';
                    }
                }
            }

            return str;
        };

        this.selectItem = function () {
        };

        this.afterRender = function () {
            this.jqElement.html('');
        };

        this.updateProperty = function (info) {
            if (info.TargetProperty === 'MenuData' &&
                    this.getProperty('ConfiguredOrDataDriven') === 'datadriven') {
                this.definitionRows = info.ActualDataRows;
                this.buildMenu(this.definitionRows);
            }
        };

        this.beforeDestroy = function () {
            var widgetElement = this.jqElement;

            try {
                widgetElement.unbind();
            } catch (destroyErr) {
            }

            try {
                widgetElement.empty();
            } catch (destroyErr) {
            }
        };
    };
}());
