﻿(function () {
    var addedDefaultStyles = false;
	var LastSelectedNode = "";
	var LastIsStructureSelected = false;
	var LastContextName = "";
	var LastFilterValue = {};

    TW.Runtime.Widgets.CustomCSS = function () {
        "use strict";
    };

    TW.Runtime.AssetMonitor = {};
    TW.Runtime.AssetMonitor.assetPropertyTitles = function(widget) {
        "use strict";
        var mashup = $(widget.idOfThisMashup);
        setTimeout( function() {
            var props = mashup.find(".widget-propertytable span");
            for (var i = 0; i<props.length; i++) {
                var p = props[i];
                p.setAttribute("title", p.textContent);
            }
        }, 1000);
    };
	//TODO Remove this code when bug related to location.protocol not visible in expression is fixed. 
	//See bugs FACTORY-19460 PSPT-6204
	TW.Runtime.Widgets.PTC_SCA_SCO_CustomFunctions = {};
	TW.Runtime.Widgets.PTC_SCA_SCO_CustomFunctions.isSecure = function(){
		"use strict";
		//TODO remove function not needed the parameter is accessible from expression
		var protocol = window.location.protocol;
		return protocol === "https:";
	};
	
	TW.Runtime.Widgets.PTC_SCA_SCO_CustomFunctions.getURLParameter = function(name, url) {
		"use strict";
		if (!url) {
			url = window.location.href;
		}
		name = name.replace(/[\[\]]/g, '\\$&');
		var regex = new RegExp('[#?&]' + name + '(=([^&#]*)|&|#|$)'), results = regex.exec(url);
		if (!results) {
			return null;
		}
		if (!results[2]) {
			return '';
		}
		return decodeURIComponent(results[2].replace(/\+/g, ' '));
	};
		
	
	TW.Runtime.Widgets.AssetMonitor = {};
	
	TW.Runtime.Widgets.AssetMonitor.initFilterCache = function(){
		"use strict";
		LastFilterValue = {};
	}

	TW.Runtime.Widgets.AssetMonitor.refreshNeeded = function(structureSelected, selectedNode, contextName) {
		"use strict";
		var refreshNeeded = false;
		structureSelected = structureSelected || false;

		if (contextName) {
			if (structureSelected != LastIsStructureSelected) {
				refreshNeeded = true;
			} else if (structureSelected && (selectedNode !== LastSelectedNode)) {
				refreshNeeded = true;
			}
		}

		LastSelectedNode = selectedNode;
		LastIsStructureSelected = structureSelected;

		return refreshNeeded;
	}

	TW.Runtime.Widgets.AssetMonitor.refreshContextNeeded = function(contextName) {
		"use strict";
		var refreshNeeded = false;

		if (contextName && (contextName !== LastContextName)) {
			refreshNeeded = true;
		}

		LastContextName = contextName;

		return refreshNeeded;
	}

	TW.Runtime.Widgets.AssetMonitor.baseContextDefined = function(contextName){
		"use strict";
		if (!contextName || contextName == undefined || contextName == "" || contextName.length == 0){
			return false;
		}
		return true;
	}
	
	TW.Runtime.Widgets.AssetMonitor.refreshAssetListNeeded = function(filters,contextName,pageNumber,pageSize){
		"use strict";
		var result = false;
		try{
			var currentFilter = filters ? JSON.parse(JSON.stringify(filters)) : {};

			var filterCurrentValue = {
				"filters":currentFilter,
				"contextName":contextName,
				"pageNumber":pageNumber,
				"pageSize":pageSize
			};

			var currentValue = filterCurrentValue ? filterCurrentValue : undefined;
			var oldValue = LastFilterValue ? LastFilterValue : undefined;
			if ( currentValue ) {
			   if ( oldValue ) {
				   result = !(JSON.stringify(oldValue) === JSON.stringify(currentValue));
			   } else {
				   result = Boolean(currentValue.filters && currentValue.contextName); 
			   }
			}
			LastFilterValue = filterCurrentValue;
		}catch(err){
			console.log('Error in TW.Runtime.Widgets.AssetMonitor.refreshAssetListNeeded error:' + err);
		}
		return result;
	}
	
}());
