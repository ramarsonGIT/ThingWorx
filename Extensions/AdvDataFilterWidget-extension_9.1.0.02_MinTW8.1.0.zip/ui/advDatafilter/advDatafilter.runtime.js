﻿/* Custom data filter based off TW.IDE.Widgets.datafilter. */
/* The purpose of this widget is to support multi state filtering modeled */
/* by a dropdown list. Used for properties such as the 'inError' and 'status'. */
/* Author: jgoudreau */

TW.Runtime.Widgets.advDatafilter = function () {
    "use strict";
    // loader for extension libs
    $('head').append('<script type="text/javascript" src="../Common/extensions/AdvDataFilterWidget-extension/ui/advDatafilter/scoFilters/sigmaFilter.js"></script>');
    $('head').append('<script type="text/javascript" src="../Common/extensions/AdvDataFilterWidget-extension/ui/advDatafilter/scoFilters/sigmaFilter_inError.js"></script>');
    $('head').append('<script type="text/javascript" src="../Common/extensions/AdvDataFilterWidget-extension/ui/advDatafilter/scoFilters/sigmaFilter_serverStatus.js"></script>');

    var widgetReference = this;
    var expire = 200, moveFiltersTimeout,
        filterBarShowing = false,
        liveFiltering = false;

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': false
        };
    };

    this.encodeString = function (stringToEncode){
        var temp = document.createElement('div');
        temp.textContent = window.twHtmlUtilities.encodeHtml(stringToEncode);
        return temp.innerHTML;
    };

    this.renderHtml = function () {

        this.lastFieldDefinitions = undefined;

        //        var cssInfo = TW.getStyleCssTextualFromStyleDefinition(this.getProperty('Style'));

        //        if (cssInfo.length > 0) {
        //            cssInfo = 'style="' + cssInfo + '"';
        //        }

        var containerClass = 'active-filter-bar-container';

        if (widgetReference.getProperty('Horizontal')) {
            // Add a styling class to the filter's drop-down/status/add control.
            containerClass += ' active-filter-bar-container-horizontal';
        }

        var dateFormatToken = window.twHtmlUtilities.encodeHtml(widgetReference.getProperty("DateFormatToken", ''));
        var dateFormatAttr = (dateFormatToken !== '' ? "date-format-token=" + dateFormatToken : '');
        var html =
            '<div class="widget-content widget-datafilter" ' + dateFormatAttr +
            ' tabindex="' + widgetReference.getProperty('TabSequence') + '" width="100%" height="100%" ' +
            'style="z-index:9000;" show-advanced-options="' + widgetReference.getProperty("ShowAdvancedOptions") + '">' +
            '<div class="focusDisplay">' +
            '<div class="' + containerClass + '" style="z-index:9000;">' +
            // content from twActiveFiltersBar.js goes here
            '</div>' +
            '</div>' +
            '</div>';
        return html;
    };

    this.buildFiltersFromFieldDefinitions = function (fieldDefinitions) {
        var thisWidget = this;
        var shouldUpdateFilters = false;
        liveFiltering = thisWidget.getProperty("LiveFiltering");

        var nFields = _.size(fieldDefinitions);

        if (nFields === 0) {
            // if no fields are in the shape definition, ignore this
            shouldUpdateFilters = false;
        } else if (this.lastFieldDefinitions === undefined) {
            shouldUpdateFilters = true;
        } else {
            if (JSON.stringify(this.lastFieldDefinitions) === JSON.stringify(fieldDefinitions)) {
                shouldUpdateFilters = false;
            } else {
                // since datashape from metadata and datashape from actual return data can be different we need to compare field by field
                for (var prop in this.lastFieldDefinitions) {
                    if (fieldDefinitions[prop] === undefined) {
                        shouldUpdateFilters = true;
                        return false;
                    } else if (fieldDefinitions[prop].baseType !== this.lastFieldDefinitions[prop].baseType) {
                        shouldUpdateFilters = true;
                        return false;
                    }
                    return true;
                }

                // now we know that every field in lastFieldDefinitions is in the latest fieldDefinitions and the definition
                // is the same

                // now go through fieldDefinitions and make sure none were added
                for (var prop in fieldDefinitions) {
                    if (this.lastFieldDefinitions[prop] === undefined) {
                        var propInfo = fieldDefinitions[prop];
                        var baseType = propInfo.baseType;
                        if (baseType === 'TAGS') {
                            if (propInfo.aspects !== undefined && propInfo.aspects.tagType !== undefined) {
                                if (propInfo.aspects.tagType === 'DataTags') {
                                    baseType = 'TAGS.Data';
                                } else if (propInfo.aspects.tagType === 'ModelTags') {
                                    baseType = 'TAGS.Model';
                                }
                            }
                        }

                        let fieldTitle = this.localizeAndEncodeTitle(propInfo.Title);
                        widgetReference.filterBar.twActiveFiltersBar(
                            'addPotentialFilter',
                            baseType, propInfo.name,
                            this.encodeString(propInfo.description),
                            false/*inFilterListNow*/,
                            undefined /*currentFilter*/,
                            false /*isSystemFilter*/,
                            true /*editable*/,
                            undefined /*showEdit*/,
                            fieldTitle,
                            liveFiltering
                        );
                    }
                }
            }
            this.lastFieldDefinitions = fieldDefinitions;
        }

        // only update the filters if the data structure has changed
        if (shouldUpdateFilters) {

            this.lastFieldDefinitions = fieldDefinitions;

            // make sure we're above all the other widgets
            this.jqElement.closest('.widget-bounding-box').css('z-index', 9999);

            widgetReference.filterBar = this.jqElement.find('.active-filter-bar-container');
            widgetReference.filterBar.twActiveFiltersBar('destroy');
            widgetReference.filterBar.empty().off();

			var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('BarStyle', 'PTC.Core.DataFilterStyle'));
			var formatAddBtnResult = TW.getStyleFromStyleDefinition(this.getProperty('AddButtonStyle', 'PTC.Core.DataFilterAddButtonStyle'));

            var cssInfo = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
            var cssDataFilterBackground = TW.getStyleCssGradientFromStyle(formatResult);
            var cssDataFilterBorder = TW.getStyleCssBorderFromStyle(formatResult);

            var cssDataFilterAddButtonText = TW.getStyleCssTextualNoBackgroundFromStyle(formatAddBtnResult);
            var cssDataFilterAddButtonBackground = TW.getStyleCssGradientFromStyle(formatAddBtnResult);

            widgetReference.filterBar.twActiveFiltersBar({
                dataFilterId:  widgetReference.jqElementId,
                customCssInfo: {
                    cssInfo:                          cssInfo,
                    cssDataFilterBackground:          cssDataFilterBackground,
                    cssDataFilterBorder:              cssDataFilterBorder,
                    cssDataFilterAddButtonText:       cssDataFilterAddButtonText,
                    cssDataFilterAddButtonBackground: cssDataFilterAddButtonBackground
                },
                sortFilters: this.getProperty('SortFilters', true)
            });

            for (var field in fieldDefinitions) {
                var propInfo = fieldDefinitions[field];
                if (propInfo.__showThisField !== false) {
                    var baseType = propInfo.baseType;
                    if (baseType === 'TAGS') {
                        if (propInfo.aspects !== undefined && propInfo.aspects.tagType !== undefined) {
                            if (propInfo.aspects.tagType === 'DataTags') {
                                baseType = 'TAGS.Data';
                            } else if (propInfo.aspects.tagType === 'ModelTags') {
                                baseType = 'TAGS.Model';
                            }
                        }
                    }

                    let fieldTitle = this.localizeAndEncodeTitle(propInfo.Title);
                    widgetReference.filterBar.twActiveFiltersBar(
                        'addPotentialFilter',
                        baseType,
                        propInfo.name,
                        this.encodeString(propInfo.description),
                        false/*inFilterListNow*/,
                        undefined /*currentFilter*/,
                        false /*isSystemFilter*/,
                        true /*editable*/,
                        undefined /*showEdit*/,
                        fieldTitle,
                        liveFiltering
                    );
                }
            }

            widgetReference.filterBar.on('filtersUpdated', function(e, filters) {
                //TW.log.info('results updated filters: "' + JSON.stringify(filters) + '"');

                var activeFilterInformation = [];

                // go through each filter specified and extract model and data tags to their proper place, put the others into activeFilterInformation
                var filters = widgetReference.filterBar.twActiveFiltersBar('getProperty', 'currentActiveFilters');
                var filterType = widgetReference.filterBar.twActiveFiltersBar('getProperty', 'filterType', 'And');

                // update the 'HasActiveFilters' property of the AdvDatafilter
                var hasActiveFilters = filters.length > 0;
                thisWidget.setProperty('HasActiveFilters', hasActiveFilters)

                for (var i = 0; i < filters.length; i++) {
                    var filter = filters[i];
                    activeFilterInformation.push(filter.currentFilter);
                }

                var queryImplementingThingsFilter = {};
                if (activeFilterInformation.length > 0) {
                    // we have some filters ... need to do special work here
                    // conjunctions need to be pulled from the filter properties

                    var filters = activeFilterInformation;

                    if (filters.length === 1) {
                        queryImplementingThingsFilter =
                        {
                            filters: filters[0]
                        };
                    } else {
                        queryImplementingThingsFilter =
                        {
                            filters: {
                                type: filterType,
                                filters: filters
                            }
                        };
                    }
                }
                widgetReference.setProperty('Query', queryImplementingThingsFilter);

                widgetReference.jqElement.triggerHandler('Changed');
            });
        }
    };

    // Phil: I'm keeping this around as reference for if we ever want to have this information retrieved before receiving any data...
    //    this.updateFilterBar = function () {
    //        var entityName = this.getProperty('EntityName');
    //        var entityType = this.getProperty('StreamOrDataTable');
    //        if (entityName !== undefined && entityName.length > 0) {
    //            $.ajax({ url: '/Thingworx/Things/' + entityName + '/Metadata/?Accept=application%2Fjson&method=get',
    //                type: "GET",
    //                datatype: "json",
    //                cache: false,
    //                async: false,
    //                error: function (xhr, status) {
    //                    TW.log.error('datafilter.runtime.js: could not load Metadata for  "' +
    //                           entityName + '", xhr: "' + JSON.stringify(xhr) + '"');
    //                },
    //                success: function (data) {
    //                    var method = undefined;
    //                    switch (entityType) {
    //                        case 'Stream':
    //                            method = 'QueryStreamEntriesWithData';
    //                            break;
    //                        case 'DataTable':
    //                            method = 'QueryDataTableEntries';
    //                            break;
    //                        default:
    //                            TW.log.error('datafilter.runtime.js: Unknown entityType "' + entityType + '"');
    //                            return;
    //                    }
    //                    var fieldDefinitions = data.serviceDefinitions[method].Outputs.fieldDefinitions;
    //                    widgetReference.buildFiltersFromFieldDefinitions(fieldDefinitions);
    //                }
    //            });
    //        }
    //    };

    this.afterRender = function () {
        var buttonFocusStyle = TW.getStyleFromStyleDefinition(widgetReference.getProperty('FocusStyle', 'DefaultButtonFocusStyle'));
        var cssDataFilterFocusBorder = TW.getStyleCssBorderFromStyle(buttonFocusStyle); // border-width:3px;border-color:#3399ff;border-style:solid;
        cssDataFilterFocusBorder += 'margin: -' + cssDataFilterFocusBorder.match(/border-width:([0-9]+px;)/)[1];

        var styleBlock = '<style>' +
            '#' + widgetReference.jqElementId + ' .focus {' + cssDataFilterFocusBorder + '} ' +
            '</style>';
        $(styleBlock).prependTo(widgetReference.jqElement);

        var widgetSelector = '#' + widgetReference.jqElementId;
        var widgetContainer = '#' + widgetReference.jqElementId + ' .focusDisplay';
        var moveFilterFlag = false;

        $(widgetSelector).on('focusin', function () {
            $(widgetContainer).removeClass('cssDataFilterBorder');
            $(widgetContainer).addClass('focus');

        });

        $(widgetSelector).on('focusout', function (e) {
            $(widgetContainer).removeClass('focus');
            $(widgetContainer).addClass('cssDataFilterBorder');
        });

        // put popup persistent elements into their respective widgets so they move with them
        // resize are momentary (use timeout), folding panel
        $(widgetSelector).on('moveElements', function(e, momentary, considerModalOverlay) {
            filterBarShowing = $(widgetSelector).find('.show-filters').css('display') === 'none' &&
                               $(widgetSelector).find('.hide-filters').is(':visible');
            var filters = $('body').children('.twActiveFiltersBar[data-filter-id="' + widgetReference.jqElementId + '"]');
            var filtersInStack = filters.find('.results-filter-item').length;
            var filterPicker = $('body').children('.category-scroller-container-filter[data-filter-id="' + widgetReference.jqElementId + '"]');

            // keep incrementing expiration amount to reduce flickering of overlapping elements
            expire += 200;

            //move filter picker if needed
            if (filterPicker.length > 0) {
                var addFilterElem = widgetReference.jqElement.find('.toc-item-filter');
                var filterPickerLeft = addFilterElem.offset().left;
                filterPicker.css({
                    left: filterPickerLeft
                });
            }

            // flag to prevent multiple executions (important if momentary)
            if (moveFilterFlag === false) {
                // only move filter elem if it has filters in it - FF, IE fire window resize on load
                if (filtersInStack > 0) {
                    var widgetHeight = widgetReference.jqElement.outerHeight();
                    filters.appendTo('.widget-content' + widgetSelector);
                    filters.css({
                        left : 0,
                        top : widgetHeight
                    });
                    considerModalOverlay = (considerModalOverlay === undefined) ? true : considerModalOverlay;

                    if (momentary) {
                        //only exercise once per event
                        moveFilterFlag = true;
                        moveFiltersTimeout = setTimeout(function() {
                            widgetReference.jqElement.trigger('popElements', [considerModalOverlay]);
                            moveFilterFlag = false;
                        }, expire);
                    }
                }
            }
        });

        var thisWidget = this;
        // put filters back in popup attached to body root in DOM
        $(widgetSelector).on('popElements', function(e, considerModalOverlay) {
            clearTimeout(moveFiltersTimeout);
            var widgetOffset = widgetReference.jqElement.offset();
            var widgetWidth = widgetReference.jqElement.width();
            var widgetHeight = widgetReference.jqElement.outerHeight();
            var filterEditingLeft = widgetOffset.left;
            var filters = widgetReference.jqElement.find('.twActiveFiltersBar.active-filters-bar');
            // if no filters assigned, make sure they aren't already moved to body and hidden
            if (filters.length === 0) {
                filters = $('body').children('.twActiveFiltersBar[data-filter-id="' + widgetReference.jqElementId + '"]');
            }
            // when filter is in editing mode. 714 is to include scrollbar in IE
            // reposition filters if too far right
            if (filters.width() === 690 && widgetOffset.left + 690 - $(window).width() > 0) {
                filterEditingLeft = widgetOffset.left - (widgetOffset.left + 714 - window.innerWidth);
                if (filterEditingLeft < (widgetOffset.left + widgetWidth - 714)) {
                    filterEditingLeft = widgetOffset.left + widgetWidth - 714;
                }
                if (filterEditingLeft < 0) {
                    filterEditingLeft = 0;
                }
            }

            var modalOverlays = $('.mashup-popup-overlay');
            var rootLevelTarget = e.target.id.includes('root_datafilter');

            // Check if there are any modal popups present and should modal overlay be considered
            // If there are, make sure the filters remain at their initial level, and are not moved in front
            if (considerModalOverlay && modalOverlays.length > 0) {
                if (!thisWidget.modalOverlay) {
                    thisWidget.modalOverlay = modalOverlays.get(modalOverlays.length - 1);
                }
                if (rootLevelTarget) {
                    filters.insertBefore(thisWidget.modalOverlay);
                } else {
                    filters.appendTo('body');
                }
            } else {
                filters.appendTo('body');
            }

            //move filters to updated location on body
            filters.css({
                left : filterEditingLeft,
                top : widgetHeight + widgetOffset.top
            });

            if (filterBarShowing) {
                filters.show();
            }

            // reset expire value to starting value
            expire = 200;
        });

        // hide widget components found in body root in DOM
        $(widgetSelector).on('hideElements', function() {
            var bodyFilters = $('body').children('.twActiveFiltersBar[data-filter-id="' + widgetReference.jqElementId + '"]');
            var bodyFilterPicker = $('body').children('.category-scroller-container-filter[data-filter-id="' + widgetReference.jqElementId + '"]');
            bodyFilterPicker.hide();
            bodyFilters.hide();
        });

        // make sure we're above all the other widgets
        this.jqElement.closest('.widget-bounding-box').css('z-index', 9999);
        var columnFormatString = this.getProperty('ColumnFormat');
        if (columnFormatString !== undefined && columnFormatString.length > 0) {
            try {
                var dataShape = JSON.parse(columnFormatString);
                this.buildFiltersFromFieldDefinitions(dataShape);
            } catch (err) {
            }
        }
    };

    this.localizeAndEncodeTitle = function(title) {
        // encode the initial value for the field title
        let defaultTitle = window.twHtmlUtilities.encodeHtml(title);

        // check to see if the initial title value is a l10n token
        let rtnTitle = TW.Runtime.convertLocalizableString(title, defaultTitle, true);

        return rtnTitle;
    };

    this.updateProperty = function (updatePropertyInfo) {
        if (updatePropertyInfo.TargetProperty === "Top" || updatePropertyInfo.TargetProperty === "Left" || updatePropertyInfo.TargetProperty === "Width" || updatePropertyInfo.TargetProperty === "Height") {
            this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
            this.jqElement.css(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue + "px");
        } else if (updatePropertyInfo.TargetProperty === "Data") {
            this.buildFiltersFromFieldDefinitions(updatePropertyInfo.DataShape);
        } else if (updatePropertyInfo.TargetProperty === "Query") {
            widgetReference.filterBar.twActiveFiltersBar('updateActiveFilters', updatePropertyInfo.RawSinglePropertyValue);
            widgetReference.jqElement.trigger('moveElements', [true, false]);
        }
        if (updatePropertyInfo.TargetProperty === 'CustomClass') {
            widgetReference.jqElement.trigger('moveElements', [true, false]);
        }
    };

    this.beforeDestroy = function () {
        $("body").find(".remove-filter-item").click();
        this.lastFieldDefinitions = null;
        widgetReference.filterBar = this.jqElement.find('.active-filter-bar-container');
        widgetReference.filterBar.twActiveFiltersBar('destroy');
        widgetReference.filterBar.empty().off();
        widgetReference = null;
    };

};
