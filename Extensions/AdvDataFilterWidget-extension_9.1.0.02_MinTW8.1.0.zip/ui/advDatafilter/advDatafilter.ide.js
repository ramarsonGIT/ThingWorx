﻿/* Custom data filter based off TW.IDE.Widgets.datafilter. */
/* The purpose of this widget is to support multi state filtering modeled */
/* by a dropdown list. Used for properties such as the 'inError' and 'status'. */
/* Developed by the Draco team */

TW.IDE.Widgets.advDatafilter = function () {
    "use strict";
    this.widgetIconUrl = function () {
        return  "../Common/extensions/AdvDataFilterWidget-extension/ui/advDatafilter/advDatafilter.ide.png";
    };
    this.widgetProperties = function () {
        return {
            'name': 'Advanced Data Filter',
            'description': 'Data Filter widget, with added multi-state property support',
            'category': ['Data'],
            'dataSourceProperty': 'Query',
            'defaultBindingTargetProperty': 'Data',
            'customEditor': 'DataFilterCustomEditor',
            'customEditorMenuText': 'Configure Data Filter Fields',
            'properties': {
                'CustomClass': {
                    'description': TW.IDE.I18NController.translate('tw.checkbox-ide.properties.custom-class.description'),
                    'baseType': 'STRING',
                    'isLocalizable': false,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isVisible': false
                },
                'ColumnFormat': {
                    'isVisible': false,
                    'baseType': 'STRING'
                },
                'Data': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.data.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'Query': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.query.description'),
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'baseType': 'QUERY',
                    'isEditable': false,
                    'warnIfNotBoundAsSource': true
                },
                'ShowAdvancedOptions': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.show-advanced-options.description'),
                    'defaultValue': false,
                    'isVisible': true,
                    'baseType': 'BOOLEAN'
                },
                'LiveFiltering' : {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.live-filtering.description'),
                    'defaultValue': false,
                    'isVisible': true,
                    'baseType': 'BOOLEAN'
                },
                'HasActiveFilters': {
                    'description': 'Flag that indicates whether the data filter currently has active filters or not.',
                    'isBindingSource': true,
                    'defaultValue': false,
                    'isVisible': true,
                    'baseType': 'BOOLEAN'
                },
     		    'SortFilters': {
                    'description':  TW.IDE.I18NController.translate('tw.datafilter-ide.properties.sort-filters.description'),
                    'defaultValue': true,
                    'isVisible':    true,
                    'baseType':     'BOOLEAN'
                },
                'AddButtonStyle': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.add-button-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.16px.TitleSmall.DarkGray'
                },
                'BarStyle': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.bar-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.16px.TitleSmall.DarkGray'
                },
                'FocusStyle': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.focus-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.NoFocusStyle'
                },
                'Horizontal': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.horizontal.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'DateFormatToken': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.date-format-token.description'),
                    'baseType': 'STRING',
                    'defaultValue': '',
                    'isVisible': true,
                    'isLocalizable': true
                },
                'DateFormat': {
                    'description': '',
                    'baseType': 'STRING',
                    'defaultValue': '',
                    'isVisible': false,
                    'isEditable': true
                },
                'Width': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.width.description'),
                    'defaultValue': 285
                },
                'Height': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.height.description'),
                    'defaultValue': 26
                },
                'TabSequence': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.tab-sequence.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'Z-index': {
                    'description': TW.IDE.I18NController.translate('tw.datafilter-ide.properties.z-index.description'),
                    'isEditable': true,
                    'defaultValue': 9000
                },
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'Changed': {'warnIfNotBound': true}
        }
    };

    this.renderHtml = function () {

        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('BarStyle'));
        var formatAddBtnResult = TW.getStyleFromStyleDefinition(this.getProperty('AddButtonStyle'));

        var cssInfo = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
        var cssDataFilterBackground = TW.getStyleCssGradientFromStyle(formatResult);
        var cssDataFilterBorder = TW.getStyleCssBorderFromStyle(formatResult);

        var cssDataFilterAddButtonText = TW.getStyleCssTextualNoBackgroundFromStyle(formatAddBtnResult);
        var cssDataFilterAddButtonBackground = TW.getStyleCssGradientFromStyle(formatAddBtnResult);

        var html =
            '<div class="widget-content widget-datafilter" width="100%" height="100%">' +
            '<div class="datafilter-header" style="' + cssDataFilterBackground + cssDataFilterBorder + '">' +
            '<div class="datafilter-add" style="' + cssDataFilterAddButtonBackground + '">' +
            '<span style="' + cssDataFilterAddButtonText + '">' +
            TW.IDE.I18NController.translate('tw.datafilter-ide.labels.add-filter') +
            '</span>' +
            '</div>' +
            '<span class="count" style="' + cssInfo + '">' +
            TW.IDE.I18NController.translate('tw.datafilter-ide.labels.active-filters') +
            '</span>' +
            '</div>' +
            '</div>';
        return html;
    };

    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo['targetProperty'] === 'Data') {

            // get the infoTableDataShape associated with this property
            var infoTableDataShape = this.getInfotableMetadataForProperty('Data');
            this.setProperty('ColumnFormat', JSON.stringify(infoTableDataShape));
        }
    }

    this.afterSetProperty = function (name, value) {
        var thisWidget = this;
        var result = false;
        var allWidgetProps = this.allWidgetProperties();
        switch (name) {
            case 'BarStyle':
            case 'AddButtonStyle':
                result = true;
                break;
            case 'Width':
                if (value < allWidgetProps['properties']['Width']['defaultValue']) {
                    setTimeout(function () {
                        thisWidget.setProperty('Width', allWidgetProps['properties']['Width']['defaultValue']);
                        TW.IDE.updateWidgetPropertiesWindow();
                    }, 100);
                }
                result = true;
                break;
            case 'ShowAdvancedOptions':
                var defaultWidth = 285;
                var advancedWidth = 385;
                var newDefaultWidth;
                var defaultLabel = TW.IDE.I18NController.translate('tw.datafilter-ide.labels.active-filters');
                var advancedLabel = TW.IDE.I18NController.translate('tw.datafilter-ide.labels.active-filters-advanced');
                newDefaultWidth = value === true ? advancedWidth : defaultWidth;
                allWidgetProps['properties']['Width']['defaultValue'] = newDefaultWidth;
                // toggle width if no manual change to width
                if (thisWidget.getProperty('Width') === defaultWidth || thisWidget.getProperty('Width') === advancedWidth) {
                    setTimeout(function () {
                        thisWidget.setProperty('Width', allWidgetProps['properties']['Width']['defaultValue']);
                        TW.IDE.updateWidgetPropertiesWindow();
                    }, 100);
                }

                thisWidget.jqElement.find('.count').html(value === true ? advancedLabel : defaultLabel);
                result = true;
                break;
        }
        return result;
    };

};
