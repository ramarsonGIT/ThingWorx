﻿/*global Encoder,TW */

TW.IDE.Widgets.dygraphchartwidget = function () {

    // max could be much higher
    this.MAX_SERIES = 9;
    this.isResponsive = false;
    var widgetContainerId;
    this.widgetIconUrl = function () {
        //widget
        //return  "../Common/thingworx/widgets/dygraphchartwidget/images/dygraphchartwidget.ide.png";
        //extension
        return  "../Common/extensions/DygraphWidget-extension/ui/dygraphchartwidget/images/dygraphchartwidget.ide.png";
    };

    this.widgetProperties = function () {
        var properties = {
            'name': 'Dygraph Widget',
            'description': 'Displays a time series chart using the dygraphs JavaScript library',
            'category': ['Data', 'Charts'],
            'dataSourceProperty': 'zoomMin',
            'supportsLabel': false,
            'supportsAutoResize': false,
            'borderWidth': 1,
            'defaultBindingTargetProperty': 'Data',
            'properties': {
                'HexColors': {
                     'description': 'Hex color for each chart',
                     'isBindingTarget': true,
                     'isEditable': true,
                     'baseType': 'STRING',
                     'isVisible': true,
                     'warnIfNotBoundAsTarget': false
                 },
                'SeriesVisibilities': {
                     'description': 'Visibility for each chart',
                     'isBindingTarget': true,
                     'isEditable': true,
                     'baseType': 'STRING',
                     'isVisible': true,
                     'warnIfNotBoundAsTarget': false
                 },
                'JSONData': {
                    'description': 'JSON Data source',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'warnIfNotBoundAsTarget': false
                },
                'ChartTitle': {
                    'description': 'Chart Title',
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isVisible': true,
                    'isLocalizable': true
                },
                'XLabel': {
                    'description': 'Label for the X Axis',
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isVisible': true,
                    'isLocalizable': true
                },
                'YLabel': {
                    'description': 'Label for the Y Axis',
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isVisible': true,
                    'isLocalizable': true
                },
                'Y2Label': {
                    'description': 'Label for the Y2 Axis',
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isVisible': true,
                    'isLocalizable': true
                },
                'Stepped':{
                    'description': 'Step line stepped or not',
                    'defaultValue': true,
                    'isVisible': true,
                    'baseType': 'BOOLEAN',
                    'selectOptions': [
                        { value: false, text: 'Linear' },
                        { value: true, text: 'Stepped' }
                    ]
                },
                'LegendPosition':{
                    'description': 'Position of the legend in the graph',
                    'defaultValue': 'onmouseover',
                    'isVisible': true,
                    'baseType': 'STRING',
                    'selectOptions': [
                        { value: 'follow', text: 'Follow' },
                        { value: 'always', text: 'Always' },
                        { value: 'onmouseover', text: 'On Mouse Over' }
                    ]
                },
                'CustomBars':{
                    'description': 'Enable to allow custom bars in data',
                    'defaultValue': true,
                    'isVisible': true,
                    'baseType': 'BOOLEAN',
                    'selectOptions': [
                        { value: true, text: 'On' },
                        { value: false, text: 'Off' }
                    ]
                },
                'ChartTitleStyle': {
                    'description': 'Chart title and outline style',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultChartTitleStyle'
                },
                'FillArea': {
                    'description': 'Fill the area defined by line with color, Not compatible with custom bar',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    'isVisible' : true
                },
                'FillAreaTrans': {
                    'description': 'The transparency level of the area under a line. Values need to be contained between 0.0 (fully transparent) and 1.0 (solid color). The default value will be applied if any input value is out of this range',
                    'baseType': 'NUMBER',
                    'defaultValue': 0.15,
                    'isVisible' : true
                },
                'StackedGraph': {
                    'description': 'Stack the graph',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    'isVisible' : true
                },
                 'UsePercentageFormat': {
                    'description': 'Show percentage values on Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    'isVisible' : true
                },
                'EnableZoomSynchronizing': {
                    'description': 'Enables the graph to synchronize its zoom with another graph.',
                    'baseType': 'BOOLEAN',
                    'isBindingTarget': true,
                    'defaultValue': false,
                    'isVisible' : true
                },
                'DisableVerticalZoom': {
                    'description': 'Disable vertical zoom feature.',
                    'baseType': 'BOOLEAN',
                    'isBindingTarget': true,
                    'defaultValue' : false
                },
                'HideY-AxisValues': {
                     'description': 'Show values on the Y axis',
                     'baseType': 'BOOLEAN',
                     'defaultValue': false,
                     'isVisible' : true
                },
                'Width': {
                    'defaultValue': 640
                },
                'Height': {
                    'defaultValue': 240
                },
                'Z-index': {
                    'baseType': 'NUMBER',
                    'defaultValue': 10
                },
                'zoomMax': {
                    'baseType': 'NUMBER',
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'defaultValue' : 0
                },
                'zoomMin': {
                    'baseType': 'NUMBER',
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'defaultValue' : 0
                },
                'useValueRange': {
                    'baseType': 'BOOLEAN',
                    'isBindingTarget': true,
                    'defaultValue' : false
                },
                'valueRangeMax': {
                    'baseType': 'NUMBER',
                    'isBindingTarget': true,
                    'defaultValue' : 0
                },
                'valueRangeMin': {
                    'baseType': 'NUMBER',
                    'isBindingTarget': true,
                    'defaultValue' : 0
                },
                'isZoomed': {
                    'baseType': 'BOOLEAN',
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'defaultValue' : false
                },
                'showDecimal': {
                    'baseType': 'BOOLEAN',
                    'defaultValue' : true
                },
                'useDateFormat': {
                    'baseType': 'BOOLEAN',
                    'defaultValue' : false
                },
                'dateFormat': {
                     'baseType': 'STRING',
                     'defaultValue' : ""
                },
                'useAnnotation': {
                     'baseType': 'BOOLEAN',
                     'defaultValue' : false
                },
                'annotationsJSON': {
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue' : ""
                },
                'annotationsDivName': {
                    'baseType': 'STRING',
                    'defaultValue' : ""
                },
                'DrawGridX': {
                    'description': 'Display the X grid in the chart',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    'isVisible' : true
                },
                'DrawGridY': {
                    'description': 'Display the Y grid in the chart',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    'isVisible' : true
                },
                'DrawGridY2': {
                     'description': 'Display the Y2 grid in the chart',
                     'baseType': 'BOOLEAN',
                     'defaultValue': false,
                     'isVisible' : true
                },
                'DrawAxisX': {
                    'description': 'Draw the X axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
                    'isVisible' : true
                },
                'DrawAxisY': {
                    'description': 'Draw the Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
                    'isVisible' : true
                },
                'DrawAxisY2': {
                    'description': 'Draw the Y2 axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
                    'isVisible' : true
                },
                'DisplayTagName': {
                     'description': 'Display tag name in legend',
                     'baseType': 'BOOLEAN',
                     'defaultValue': false,
                     'isVisible' : true
                },
                'ConnectSeparatedPoints': {
                     'description': 'When a gap exists between two data point of a series, connect those points',
                     'baseType': 'BOOLEAN',
                     'defaultValue': true,
                     'isVisible' : true
                },
                'DrawPoints': {
                     'description': 'Draw a small dot at each point, in addition to a line going through the point',
                     'baseType': 'BOOLEAN',
                     'defaultValue': false,
                     'isVisible' : true
                },
                'DateWindowStart': {
                     'description': 'The date window start time for initial x axis range',
                     'baseType': 'DATETIME',
                     'defaultValue': false,
                     'isBindingTarget': true,
                     'isVisible' : true
                },
                'DateWindowEnd': {
                     'description': 'The date window end time for initial x axis range',
                     'baseType': 'DATETIME',
                     'defaultValue': false,
                     'isBindingTarget': true,
                     'isVisible' : true
                },
                'DygraphSynchDefault': {
                     'description': 'If true the dygraph library synchronized will be called when more than one chart is loaded on the page',
                     'baseType': 'BOOLEAN',
                     'defaultValue': false,
                     'isVisible' : true
                }

            }
        };
        
        var seriesNumber;
        for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {

            var datalabelProperty = {
                'description': 'Series data label ' + seriesNumber,
                'baseType': 'STRING',
                'isBindingTarget': true,
                'isVisible': true,
                'isLocalizable': true
            };

            var seriesStyleProperty = {
                'description': 'Series style ' + seriesNumber,
                'baseType': 'STYLEDEFINITION',
                'isVisible': true
            };
			
			var seriesVisibility = {
				'description': 'Series Visibility ' + seriesNumber,
				'defaultValue': true,
                'baseType': 'BOOLEAN',
                'isBindingTarget': true,
                'isVisible': true
			};
			
			var seriesAxis = {
				'description': 'Whether to use Y2 or not',
                'defaultValue': false,
                'isVisible': true,
                'isBindingTarget': true,
                'baseType': 'BOOLEAN'

			};

			var seriesHideLegend = {
                'description': 'Hide the first series',
                'baseType': 'BOOLEAN',
                'defaultValue': false,
                'isVisible' : true

            };

            properties.properties['DataLabel' + seriesNumber] = datalabelProperty;
            properties.properties['SeriesStyle' + seriesNumber] = seriesStyleProperty;
			properties.properties['SeriesVisibility' + seriesNumber] = seriesVisibility;
			properties.properties['SeriesSecondAxis' + seriesNumber] = seriesAxis;
			properties.properties['HideSeries'+ seriesNumber +'InLegend'] = seriesHideLegend;

        }

        return properties;
    };

    this.widgetEvents = function () {
        return {
		 'DoubleClicked': {},
         'SyncRequest': {},
         'Zoomed': {}
        };
		
		
    };
	
	this.widgetServices = function() {
        return {
            'resetZoom':            { 'warnIfNotBound': false },
            'sync':                 { 'warnIfNotBound': false },
            'dygraphSynchronize':   { 'warnIfNotBound': false },
            'detach':               { 'warnIfNotBound': false }
        }
    }

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-dygraphchartwidget">'
             +  '<table height="100%" width="100%"><tr><td valign="middle" align="center">'
             +  '<span>Dygraph Widget</span>'
             +  '</td></tr></table></div>';
        return html;
    };

    this.afterRender = function () {
        // this property can't be hidden in setProperties because ResponsiveLayout is still undefined in most cases
        widgetContainerId = '#' + this.jqElementId;
        // if this is in a inactive tab or similar we must prevent rendering until tab gets clicked
        if(this.properties.ResponsiveLayout){
            this.isResponsive = true;
        }
        if(this.isResponsive && $(widgetContainerId).closest('.widget-panel')) {
            this.isResponsive = false;

        }
            this.updatedProperties();
    };

    this.afterLoad = function () {
        // first function to run if widget already in mashup
        //this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
    };

    this.afterSetProperty = function (name, value) {
      var result = false;
      switch (name) {
         case 'zoomMax':
         case 'zoomMin':
            result = true;
            break;
      }
	  console.log(" after Set property");
      return result;
    };
    
    this.beforeSetProperty = function (name, value) {
    };

    
};
