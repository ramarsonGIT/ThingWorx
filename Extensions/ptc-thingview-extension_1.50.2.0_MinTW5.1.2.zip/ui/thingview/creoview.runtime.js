/* bcwti
 *
 * Copyright (c) 2015-2020 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

/* var s_runtimePluginVersion = "0.50.2+MCHCFW"; */

TW.Runtime.Widgets.thingview = function() {
    var thisWidget = this;
    thisWidget.formatter = thisWidget.getProperty('DataFormatter');
    thisWidget.backgroundStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundStyle', ''));
    thisWidget.occurrenceIdField = thisWidget.getProperty('OccurrenceField');
    if (!thisWidget.occurrenceIdField)
        thisWidget.occurrenceIdField = 'treeId';
    thisWidget.localData = null;
    thisWidget.cachedOccurrencePath = [];
    thisWidget.selectedInstances = [];
    thisWidget.templateUrl = "";
    thisWidget.loadingModel = false;
    thisWidget.figureNums = 0;
    thisWidget.figureName = "";
    thisWidget.isVisible = false;
    thisWidget.pdfToolbar = {pages: true, zoom: true, cursor: true, search: true, sidebar: true, rotate: true, print: false};
    thisWidget.mutationManager = {
        width: "0",
        height: "0",
        observer: null
    };

    thisWidget.viewsData = {
        annotations: [],
        documents: [],
        viewables: [],
        viewstates: []
    };
    thisWidget.viewsData.reset = function () {
        this.annotations = [];
        this.documents = [];
        this.viewables = [];
        this.viewstates = [];
    };

    thisWidget.setFormatter = function(f) {
        thisWidget.formatter = f;
    };

    thisWidget.applyFormatter = function() {
        if (thisWidget.localData && thisWidget.localData.length > 0 && thisWidget.formatter && thisWidget.model) {
            for (var i = 0; i < thisWidget.localData.length; i++) {
                var formatResult = TW.getStyleFromStateFormatting({DataRow: thisWidget.localData[i], StateFormatting: thisWidget.formatter});
                if (formatResult.foregroundColor) {
                    var color = thisWidget.parseRGBA(formatResult.foregroundColor);
                    thisWidget.model.SetPartColor(
                        thisWidget.localData[i][thisWidget.occurrenceIdField],
                        parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]),
                        Module.ChildBehaviour.IGNORED,
                        Module.InheritBehaviour.USE_DEFAULT
                    );
                }
            }
        }
    };

    this.runtimeProperties = function() {
        return {
            'needsDataLoadingAndError': false
        };
    };


    this.renderHtml = function() {
        TW.log.info('Thing View Widget .renderHtml');
        var color = thisWidget.backgroundStyle.backgroundColor;
        var html = '';
        html = `<div class="widget-content widget-thingview"
                style="display:block;`;
        if (color) {
            html += 'background-color: ' + color;
        }
        html += `">
                <div class="thing-view-plugin-wrapper"></div>
                </div>`;
        return html;
    };

    function setTemplateUrl() {
        if (thisWidget.productToView.indexOf("/servlet") > 0) {
            //Set the template param to allow fetching the child files
            var baseUrl = '';
            if (!thisWidget.urlbase) {
                baseUrl = thisWidget.productToView.substring(0, thisWidget.productToView.indexOf("/servlet"));
            }
            if (!thisWidget.templateUrl) {
                baseUrl += '/servlet/WindchillAuthGW/com.ptc.wvs.server.util.WVSContentHelper/redirectDownload/FILENAME_KEY?HttpOperationItem=OID1_KEY&ContentHolder=OID2_KEY&u8=1';
                var clientRedirect = thisWidget.getProperty('AllowClientRedirect');
                if (clientRedirect == undefined) clientRedirect = true;
                if (clientRedirect) {
                    baseUrl += '&twxME_ClientFollowRedirect=true';
                }
                thisWidget.templateUrl = baseUrl;
            }
        }
    }

    this.afterRender = function() {
        if (window.MyThingView === undefined) {
            TW.log.info('Thing View Widget window.MyThingView: is undefined');
            window.MyThingView = {
                thingViewEngineInitialised: false,
                thingViewEngineStarting: false
            };
        }
        TW.log.info('Thing View Widget window.MyThingView: ' + window.MyThingView);
        TW.log.info('Thing View Widget window.MyThingView.thingViewEngineInitialised: ' + window.MyThingView.thingViewEngineInitialised);
        TW.log.info('Thing View Widget window.MyThingView.thingViewEngineStarting: ' + window.MyThingView.thingViewEngineStarting);

        thisWidget.productToView = thisWidget.getProperty('ProductToView');
        thisWidget.baseUrl = thisWidget.getProperty('baseUrl');
        thisWidget.windchillSourceData = thisWidget.getProperty('WindchillSourceData');
        if (thisWidget.windchillSourceData == undefined) thisWidget.windchillSourceData = true;
        if (thisWidget.windchillSourceData == true) {
            setTemplateUrl();
        }

        thisWidget.oid = thisWidget.getProperty('oid');
        thisWidget.mapUrl = thisWidget.getProperty('mapUrl');
        thisWidget.markupUrl = thisWidget.getProperty('markupUrl');

        var selPartsSelMode = thisWidget.getProperty('SelectedPartsSelectionMode');
        if (selPartsSelMode != undefined && selPartsSelMode != "IDPATH") {
            var valueMode = false;
            if (selPartsSelMode == "PROPPATH") valueMode = false;
            else if (selPartsSelMode == "PROPVALUE") valueMode = true;

            thisWidget.selProp = {
                groupName: thisWidget.getProperty('SelectionPropertyGroupName'),
                name: thisWidget.getProperty('SelectionPropertyName'),
                propIdMap: {},
                idPropMap: {},
                valueMode: valueMode
            };
        }

        var infoTableValueViews = thisWidget.getProperty('Views');
        if (infoTableValueViews === undefined) {
            var dataShapeInfoViews;
            TW.Runtime.GetDataShapeInfo("Views", function (info) {
                dataShapeInfoViews = info;

                // create empty infotable
                var infoTable = {
                    'dataShape': dataShapeInfoViews,
                    'name': 'views',
                    'description': TW.Runtime.convertLocalizableString('[[TW.ThingView.Properties.Views.Description]]', 'A list of Views (Name, Type, Id).'),
                    'rows': []
                };
                thisWidget.setProperty('Views', infoTable);
            });
        }

        var infoTableValueParts = thisWidget.getProperty('SelectedParts');
        if (infoTableValueParts === undefined) {
            var dataShapeInfoParts;
            TW.Runtime.GetDataShapeInfo("Selection", function (info) {
                dataShapeInfoParts = info;

                // create empty infotable
                var infoTable = {
                    'dataShape': dataShapeInfoParts,
                    'name': 'SelectedParts',
                    'description': TW.Runtime.convertLocalizableString('[[TW.ThingView.Properties.SelectedParts.Description]]', 'All the selected parts in the session'),
                    'rows': []
                };
                thisWidget.setProperty('SelectedParts', infoTable);
            });
        }
        thisWidget.updatePVHtml();
    };

    this.updatePVHtml = function() {
        var pluginId = thisWidget.getProperty('Id') + "-plugin";

        thisWidget.thingViewId = "ThingViewContainer-" + pluginId;
        var htmlToWrite = '<div id="';
        htmlToWrite += thisWidget.thingViewId;
        htmlToWrite += '" style="width: 100%; height: 100%; margin-left: auto; margin-right: auto;"></div>';

        thisWidget.thingViewControls = thisWidget.getProperty('ThingViewControls');
        if (thisWidget.thingViewControls == undefined) thisWidget.thingViewControls = true;
        if (thisWidget.thingViewControls) {
            thisWidget.displayPlaybackControls = thisWidget.getProperty('DisplayPlaybackControls');
            if (thisWidget.displayPlaybackControls == undefined) thisWidget.displayPlaybackControls = true;

            htmlToWrite += `
            <div class="radialButton rightPaneButtons rightPaneOpener noselect" id="rightPaneOpener" disabled>
                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_right_pane_icon.svg"/>
            </div>
            <div id="rightPaneContainerBG" class="rightPaneContainerBG noselect">
                <div id="rightPaneContainer" class="rightPaneContainer">
                    <div id="rightPaneCloser" class="rightPaneTrapezoidContainer">
                        <div class="rightPaneTrapezoid" id="rightPaneTrapezoid">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/>
                        </div>
                    </div>
                    <div id="rightPaneContent" class="rightPaneContent scrollable-container">
                        <div class="radialButton rightPaneButtons" id="rightPaneButton3">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_show_all.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton1">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_hide.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton2">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_isolate.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton4">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_zoom_to_fit.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton5">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_zoom_to_selected.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton6">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_zoom_to_window.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton7">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_part_dragger.svg"/>
                        </div>
                        <div class="radialButton rightPaneButtons" id="rightPaneButton8">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_restore_location.svg"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="radialButton radialButtonOrient leftPaneOpener noselect" id="leftPaneOpener" disabled>
                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_left_pane_icon.svg"/>
            </div>
            <div id="leftPaneContainerBG" class="leftPaneContainerBG noselect">
                <div id="leftPaneContainer" class="leftPaneContainer">
                    <div id="leftPaneCloser" class="leftPaneTrapezoidContainer">
                        <div class="leftPaneTrapezoid" id="leftPaneTrapezoid">
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/>
                        </div>
                    </div>
                    <div id="leftPaneResizerHighlight" class="leftPaneResizerHighlight"></div>
                    <div id="leftPaneResizer" class="leftPaneResizer"></div>
                    <div id="leftPaneResizerTouch" class="leftPaneResizer leftPaneResizerTouch"></div>
                    <div id="leftPaneOrientsTitle" class="leftPaneTitle">
                        <img id="leftPaneOrientsTitleMark" class="leftPaneTitleMark"
                            src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/>
                        <span id="leftPaneOrientsTitleText" class="leftPaneTitleText"></span>
                    </div>
                    <div id="leftPaneOrientsContent">
                        <div class="widgetOrientPair">
                            <div class="radialButton radialButtonOrient" id="widgetOrientISO1">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_iso1.svg"/>
                            </div>
                            <div class="radialButton radialButtonOrient" id="widgetOrientISO2">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_iso2.svg"/>
                            </div>
                        </div>
                        <div class="widgetOrientPair">
                            <div class="radialButton radialButtonOrient" id="widgetOrientTop">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_top.svg"/>
                            </div>
                            <div class="radialButton radialButtonOrient" id="widgetOrientBottom">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_bottom.svg"/>
                            </div>
                        </div>
                        <div class="widgetOrientPair">
                            <div class="radialButton radialButtonOrient" id="widgetOrientLeft">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_left.svg"/>
                            </div>
                            <div class="radialButton radialButtonOrient" id="widgetOrientRight">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_right.svg"/>
                            </div>
                        </div>
                        <div class="widgetOrientPair">
                            <div class="radialButton radialButtonOrient" id="widgetOrientFront">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_front.svg"/>
                            </div>
                            <div class="radialButton radialButtonOrient" id="widgetOrientBack">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_back.svg"/>
                            </div>
                        </div>
                    </div>
                    <div id="leftPaneViewablesTitle" class="leftPaneTitle">
                        <img id="leftPaneViewablesTitleMark" class="leftPaneTitleMark"
                            src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/>
                        <span id="leftPaneViewablesTitleText" class="leftPaneTitleText"></span>
                    </div>
                    <div id="leftPaneViewablesContent" class="widgetViewableContainer scrollable-container"></div>
                    <div id="bottomBorder" class="leftPaneBottomBorder"></div>
                </div>
            </div>`;
            if (thisWidget.displayPlaybackControls) {
                htmlToWrite += `
                <div id="bottomPaneContainerBG" class="bottomPaneContainerBG noselect">
                    <div id="bottomPaneContainer" class="bottomPaneContainer">
                        <div id ="bottomPaneContent" class="bottomPaneContent">
                            <div class="radialButton bottomPaneDragger" id="bottomPaneDragger">
                                <img class="noselect" src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_dragger.svg"/>
                            </div>
                            <div class="radialButton bottomPaneButtons" id="bottomPaneRewind">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_rewind.svg" style="width:22px;height:18px;margin-left:9px;margin-top:11px;"/>
                            </div>
                            <div class="radialButton bottomPaneButtons" id="bottomPanePrevious">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_previous.svg" style="width:16px;height:18px;margin-left:12px;margin-top:11px;"/>
                            </div>
                            <div class="radialButton bottomPaneButtons" id="bottomPanePlay">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_play.svg" style="width:14px;height:18px;margin-left:13px;margin-top:11px;"/>
                            </div>
                            <div class="radialButton bottomPaneButtons" id="bottomPanePause">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/pause.png"/>
                            </div>
                            <div class="radialButton bottomPaneButtons" id="bottomPanePlayAll">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_play_all.svg" style="width:20px;height:20px;margin-left:10px;margin-top:10px;"/>
                            </div>
                            <div class="radialButton bottomPaneButtons" id="bottomPaneNext">
                                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_next_step.svg" style="width:16px;height:18px;margin-left:12px;margin-top:11px;"/>
                            </div>
                            <div class="bottomPaneSequenceScrollbarContainer" id="bottomPaneSequenceScrollbarContainer">
                                <div class="bottomPaneSequenceScrollbar" id="bottomPaneSequenceScrollbar">
                                    <div class="bottomPaneSequenceScrollbarCore" id="bottomPaneSequenceScrollbarCore"></div>
                                </div>
                                <div class="bottomPaneSequenceScrollbarBackground" id="bottomPaneSequenceScrollbarBackground">
                                    <div class="bottomPaneSequenceScrollbarBackgroundElapsed" id="bottomPaneSequenceScrollbarBackgroundElapsed"></div>
                                </div>
                            </div>
                            <div class="bottomPaneSequenceStep" id="bottomPaneSequenceStep">
                                <span id="bottomPaneSequenceStepText" class="bottomPaneSequenceStepText"></span>
                            </div>
                            <div class="bottomPaneAnimationScrollbarContainer" id="bottomPaneAnimationScrollbarContainer">
                                <div class="bottomPaneAnimationScrollbar" id="bottomPaneAnimationScrollbar">
                                    <div class="bottomPaneAnimationScrollbarCore" id="bottomPaneAnimationScrollbarCore"></div>
                                </div>
                                <div class="bottomPaneAnimationScrollbarBackground" id="bottomPaneAnimationScrollbarBackground">
                                    <div class="bottomPaneAnimationScrollbarBackgroundElapsed" id="bottomPaneAnimationScrollbarBackgroundElapsed"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="bottomPaneAcknowledgeContainer" class="bottomPaneAcknowledgeContainer">
                        <div id="bottomPaneAcknowledgeDialog" class="bottomPaneAcknowledgeDialog">
                            <div id="bottomPaneAcknowledgeDialogTitle" class="title"></div>
                            <div id="bottomPaneAcknowledgeDialogContent" class="content">
                                <p id="bottomPaneAcknowledgeDialogContentText" class="text"></p>
                            </div>
                            <div id="bottomPaneAcknowledgeDialogButtons" class="buttons">
                                <div id="bottomPaneAcknowledgeDialogReplay" class="button"><span></span></div>
                                <div id="bottomPaneAcknowledgeDialogContinue" class="button"><span></span></div>
                                <div id="bottomPaneAcknowledgeDialogComplete" class="button"><span></span></div>
                                <div id="bottomPaneAcknowledgeDialogStop" class="button"><span></span></div>
                            </div>
                        </div>
                    </div>
                </div>`;
            }
        }
        thisWidget.jqElement.find('.thing-view-plugin-wrapper').html(htmlToWrite);

        const convert = TW.Runtime.convertLocalizableString;
        thisWidget.l8nTokens = {
            pdf: {
                displaySidebar: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.DisplaySidebar]]', 'Display Sidebar'),
                firstPage: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.FirstPage]]', 'First Page'),
                previousPage: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PreviousPage]]', 'Previous Page'),
                nextPage: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.NextPage]]', 'Next Page'),
                lastPage: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.LastPage]]', 'Last Page'),
                rotateClockwise: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.RotateClockwise]]', 'Rotate Clockwise'),
                rotateAntiClockwise: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.RotateAntiClockwise]]', 'Rotate Anti-clockwise'),
                zoomIn: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.ZoomIn]]', 'Zoom In'),
                zoomOut: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.ZoomOut]]', 'Zoom Out'),
                panMode: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PanMode]]', 'Pan Mode'),
                textSelectMode: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.TextSelectMode]]', 'Text Select Mode'),
                printPDF: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PrintPDF]]', 'Print PDF'),
                pageMode: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PageMode.PageMode]]', 'Page Mode'),
                original: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PageMode.Original]]', 'Original'),
                fitPage: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PageMode.FitPage]]', 'Fit Page'),
                fitWidth: convert('[[TW.ThingView.WidgetUI.PDF.SideBar.PageMode.FitWidth]]', 'Fit Width'),
                searchInput: convert('[[TW.ThingView.WidgetUI.PDF.Search.Input]]', 'Enter a search term'),
                searchingPage: convert('[[TW.ThingView.WidgetUI.PDF.Search.SearchingPage]]', 'Searching Page'),
                searching: convert('[[TW.ThingView.WidgetUI.PDF.Search.Searching]]', 'Searching for results...'),
                searchNotFound: convert('[[TW.ThingView.WidgetUI.PDF.Search.SearchNotFound]]', 'Search term not found'),
                matches: convert('[[TW.ThingView.WidgetUI.PDF.Search.Matches]]', 'matches'),
                tooltipSearch: convert('[[TW.ThingView.WidgetUI.PDF.Search.Tooltips.Search]]', 'Search'),
                tooltipClear: convert('[[TW.ThingView.WidgetUI.PDF.Search.Tooltips.Clear]]', 'Clear'),
                tooltipNext: convert('[[TW.ThingView.WidgetUI.PDF.Search.Tooltips.Next]]', 'Next'),
                tooltipPrevious: convert('[[TW.ThingView.WidgetUI.PDF.Search.Tooltips.Previous]]', 'Previous'),
                tooltipClose: convert('[[TW.ThingView.WidgetUI.PDF.Search.Tooltips.Close]]', 'Close'),
                enterPassword: convert('[[TW.ThingView.WidgetUI.PDF.Password.EnterPassword]]', 'Please enter a password.'),
                incorrectPassword: convert('[[TW.ThingView.WidgetUI.PDF.Password.IncorrectPassword]]', 'That password is incorrect.'),
                enterPasswordAgain: convert('[[TW.ThingView.WidgetUI.PDF.Search.EnterPasswordAgain]]', 'Please try again.')
            }
        };

        if (thisWidget.thingViewControls) {
            thisWidget.l8nTokens.rightPane = {
                openerTooltip: convert('[[TW.ThingView.WidgetUI.RightPane.Opener.Tooltip]]', 'Zooming & Selection tools')
            };
            thisWidget.l8nTokens.leftPane = {
                openerViewStatesTooltip: convert('[[TW.ThingView.WidgetUI.LeftPane.Opener.ViewStates.Tooltip]]', 'Orientation & View States'),
                openerFiguresTooltip: convert('[[TW.ThingView.WidgetUI.LeftPane.Opener.Figures.Tooltip]]', 'Orientation & Figures'),
                orientationTooltip: convert('[[TW.ThingView.WidgetUI.LeftPane.Orientation.Tooltip]]', 'Toggle orientations'),
                orientationTitle: convert('[[TW.ThingView.WidgetUI.LeftPane.Orientation.Title]]', 'Orientation'),
                viewStatesTooltip: convert('[[TW.ThingView.WidgetUI.LeftPane.ViewStates.Tooltip]]', 'Toggle view states'),
                viewStatesTitle: convert('[[TW.ThingView.WidgetUI.LeftPane.ViewStates.Title]]', 'View States'),
                defaultViewTitle: convert('[[TW.ThingView.WidgetUI.LeftPane.DefaultView.Title]]', 'Default View'),
                figuresTooltip: convert('[[TW.ThingView.WidgetUI.LeftPane.Figures.Tooltip]]', 'Toggle figures'),
                figuresTitle: convert('[[TW.ThingView.WidgetUI.LeftPane.Figures.Title]]', 'Figures')
            };
            thisWidget.l8nTokens.bottomPane = {
                acknowledgementMessageStartText: convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Message.Start]]', 'You are about to view:'),
                acknowledgementMessageEndText: convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Message.End]]', 'You have reached the end of the step:')
            };
            thisWidget.l8nTokens.closerTooltip = convert('[[TW.ThingView.WidgetUI.Closer.Tooltip]]', 'Close');
            thisWidget.l8nTokens.disabled = convert('[[TW.ThingView.WidgetUI.Disabled.Text]]', 'Disabled');

            let 
            showAllTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.ShowAll.Tooltip]]', 'Show All'),
            hideTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.Hide.Tooltip]]', 'Hide Selected'),
            isolateTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.Isolate.Tooltip]]', 'Isolate Selected'),
            zoomAllTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.ZoomAll.Tooltip]]', 'Zoom All'),
            zoomSelectedTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.ZoomSelected.Tooltip]]', 'Zoom Selected'),
            zoomWindowTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.ZoomWindow.Tooltip]]', 'Zoom Window'),
            partDraggerTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.PartDragger.Tooltip]]', 'Part Dragger'),
            restoreLocationTooltip = convert('[[TW.ThingView.WidgetUI.RightPane.RestoreLocation.Tooltip]]', 'Restore Part Location'),
            orientationISO1 = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.ISO1]]', 'ISO 1'),
            orientationISO2 = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.ISO2]]', 'ISO 2'),
            orientationTop = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.Top]]', 'Top'),
            orientationBottom = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.Bottom]]', 'Bottom'),
            orientationLeft = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.Left]]', 'Left'),
            orientationRight = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.Right]]', 'Right'),
            orientationFront = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.Front]]', 'Front'),
            orientationBack = convert('[[TW.ThingView.Properties.Orientations.SelectOptions.Back]]', 'Back');

            thisWidget.jqElement.find('#rightPaneOpener').attr('title', thisWidget.l8nTokens.rightPane.openerTooltip);
            thisWidget.jqElement.find('#rightPaneTrapezoid').attr('title', thisWidget.l8nTokens.closerTooltip);
            thisWidget.jqElement.find('#rightPaneButton3').attr('title', showAllTooltip);
            thisWidget.jqElement.find('#rightPaneButton1').attr('title', hideTooltip);
            thisWidget.jqElement.find('#rightPaneButton2').attr('title', isolateTooltip);
            thisWidget.jqElement.find('#rightPaneButton4').attr('title', zoomAllTooltip);
            thisWidget.jqElement.find('#rightPaneButton5').attr('title', zoomSelectedTooltip);
            thisWidget.jqElement.find('#rightPaneButton6').attr('title', zoomWindowTooltip);
            thisWidget.jqElement.find('#rightPaneButton7').attr('title', partDraggerTooltip);
            thisWidget.jqElement.find('#rightPaneButton8').attr('title', restoreLocationTooltip);
            
            thisWidget.jqElement.find('#leftPaneOpener').attr('title', thisWidget.l8nTokens.leftPane.openerViewStatesTooltip);
            thisWidget.jqElement.find('#leftPaneTrapezoid').attr('title', thisWidget.l8nTokens.closerTooltip);
            thisWidget.jqElement.find('#leftPaneOrientsTitle').attr('title', thisWidget.l8nTokens.leftPane.orientationTooltip);
            thisWidget.jqElement.find('#leftPaneOrientsTitleText').text(thisWidget.l8nTokens.leftPane.orientationTitle);
            thisWidget.jqElement.find('#widgetOrientISO1').attr('title', orientationISO1);
            thisWidget.jqElement.find('#widgetOrientISO2').attr('title', orientationISO2);
            thisWidget.jqElement.find('#widgetOrientTop').attr('title', orientationTop);
            thisWidget.jqElement.find('#widgetOrientBottom').attr('title', orientationBottom);
            thisWidget.jqElement.find('#widgetOrientLeft').attr('title', orientationLeft);
            thisWidget.jqElement.find('#widgetOrientRight').attr('title', orientationRight);
            thisWidget.jqElement.find('#widgetOrientFront').attr('title', orientationFront);
            thisWidget.jqElement.find('#widgetOrientBack').attr('title', orientationBack);
            thisWidget.jqElement.find('#leftPaneViewablesTitle').attr('title', thisWidget.l8nTokens.leftPane.viewStatesTooltip);
            thisWidget.jqElement.find('#leftPaneViewablesTitleText').text(thisWidget.l8nTokens.leftPane.viewStatesTitle);

            if (thisWidget.displayPlaybackControls) {
                let
                bottomPaneDraggerTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.Dragger.Tooltip]]', 'Drag to move'),
                bottomPaneRewindTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.Rewind.Tooltip]]', 'Rewind to Start'),
                bottomPanePreviousTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.Previous.Tooltip]]', 'Previous Step'),
                bottomPanePlayTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.Play.Tooltip]]', 'Play'),
                bottomPanePauseTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.Pause.Tooltip]]', 'Pause'),
                bottomPanePlayAllTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.PlayAll.Tooltip]]', 'Play All'),
                bottomPaneNextTooltip = convert('[[TW.ThingView.WidgetUI.BottomPane.Next.Tooltip]]', 'Next Step'),
                bottomPaneAcknowledgementTitle = convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Title]]', 'Acknowledgement'),
                bottomPaneAcknowledgementReplay = convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Replay]]', 'Replay'),
                bottomPaneAcknowledgementContinue = convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Continue]]', 'Continue'),
                bottomPaneAcknowledgementComplete = convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Complete]]', 'Complete'),
                bottomPaneAcknowledgementStop = convert('[[TW.ThingView.WidgetUI.BottomPane.Acknowledgement.Stop]]', 'Stop');

                thisWidget.jqElement.find('#bottomPaneDragger').attr('title', bottomPaneDraggerTooltip);
                thisWidget.jqElement.find('#bottomPaneRewind').attr('title', bottomPaneRewindTooltip);
                thisWidget.jqElement.find('#bottomPanePrevious').attr('title', bottomPanePreviousTooltip);
                thisWidget.jqElement.find('#bottomPanePlay').attr('title', bottomPanePlayTooltip);
                thisWidget.jqElement.find('#bottomPanePause').attr('title', bottomPanePauseTooltip);
                thisWidget.jqElement.find('#bottomPanePlayAll').attr('title', bottomPanePlayAllTooltip);
                thisWidget.jqElement.find('#bottomPaneNext').attr('title', bottomPaneNextTooltip);

                thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogTitle').text(bottomPaneAcknowledgementTitle);
                thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').find("span").text(bottomPaneAcknowledgementReplay);
                thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').find("span").text(bottomPaneAcknowledgementContinue);
                thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogComplete').find("span").text(bottomPaneAcknowledgementComplete);
                thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogStop').find("span").text(bottomPaneAcknowledgementStop);
            }
        }

        if (window.MyThingView.thingViewEngineInitialised === true) {
            TW.log.info('Thing View Widget already initialised create session');
            thisWidget.CreateSession();
            thisWidget.LoadModel();
        } else if (window.MyThingView.thingViewEngineStarting !== true) {
            TW.log.info('Thing View Widget is not initialised or starting now initialise it');
            TW.log.info("window.MyThingView.thingViewEngineInitialised: " + window.MyThingView.thingViewEngineInitialised);
            window.MyThingView.thingViewEngineStarting = true;

            ThingView.init("../Common/extensions/ptc-thingview-extension/ui/thingview/js/ptc/thingview/", function () {
                window.MyThingView.thingViewEngineInitialised = true;

                var thingviewPref = {
                    ParseNode: {
                        Type: "root",
                        Name: "",
                        Value: "",
                        Locked: false,
                        Children: [
                            {
                                Type: "category",
                                Name: "Shape Scene",
                                Value: "",
                                Locked: false,
                                Children: [
                                    {
                                        Type : "preference_list",
                                        Name : "Sequence label options",
                                        Locked : false,
                                        Children : [
                                            {
                                                Type : "preference_item",
                                                Children : [
                                                    {
                                                        Type : "preference",
                                                        Name : "Anchor point",
                                                        Value : "top left",
                                                        Locked : false
                                                    },
                                                    {
                                                        Type : "preference",
                                                        Name : "X offset",
                                                        Value : "60",
                                                        Locked : false
                                                    },
                                                    {
                                                        Type : "preference",
                                                        Name : "Y offset",
                                                        Value : "-10",
                                                        Locked : false
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                };

                try {
                    ThingView.SetDefaultSystemPreferences(Module.ApplicationType.CREOVIEW);
                    ThingView.AddSystemPreferencesFromJson(JSON.stringify(thingviewPref));
                } catch (e) {
                    TW.log.info('Failed to apply system preferences from json, widget probably shutdown before thingview initialization completed');
                }
                if (thisWidget) {
                    thisWidget.CreateSession();
                    thisWidget.LoadModel();
                }
            });
        } else {
            var initInterval = setInterval(function(){
                if (window.MyThingView.thingViewEngineInitialised) {
                    TW.log.info('ThingView init complete');
                    window.clearInterval(initInterval);

                    thisWidget.CreateSession();
                    thisWidget.LoadModel();
                } else {
                    TW.log.info('Waiting for ThingView init to complete');
                }
            }, 3000);
        }
    };

    function getCachedOccurrencePath(index) {
        var path = thisWidget.cachedOccurrencePath[index];
        if (!path) {
            return thisWidget.constructIdPath(index);
        }
        return path;
    }

    this.getIndex = function(value) {
        if (!value || !thisWidget.localData) {
            return undefined;
        }
        var i = thisWidget.localData.length;
        while (i--) {
            if (getCachedOccurrencePath(i) === value ||
                thisWidget.localData[i][thisWidget.occurrenceIdField] === value) {
                return i;
            }
        }
        return undefined;
    };

    this.getPropPath = function(value) {
        if (!value || !thisWidget.selProp) {
            return undefined;
        }

        var propObj = thisWidget.selProp.idPropMap[value];
        if (propObj) {
            return(thisWidget.selProp.valueMode ? propObj.value : propObj.path);
        } else {
            return undefined;
        }
    };

    this.getKey = function() {
        if (thisWidget.selProp.valueMode) {
            return 'propValue';
        } else {
            return 'propPath';
        }
    };

    this.getParentRow = function(id) {
        if (!thisWidget.localData) {
            return null;
        }

        var i = thisWidget.localData.length;
        while (i--) {
            if (thisWidget.localData[i].objectId === id) {
                return thisWidget.localData[i];
            }
        }

        return null;
    };

    this.constructIdPath = function(index) {
        var row = thisWidget.localData[index];
        var id = row[thisWidget.occurrenceIdField] + '';
        if (id.charAt(0) === '/') {
            return id;
        }
        var parent = row;
        var count = 0;
        while (parent && id.charAt(0) !== '/' && count++ < 100) {
            id = '/' + id;
            parent = this.getParentRow(parent.parentId);
            if (parent) {
                var pid = parent[thisWidget.occurrenceIdField];
                if (pid !== '/' && pid) {
                    id = pid + id;
                }
            }
        }
        thisWidget.cachedOccurrencePath[index] = id;
        return id;
    };

    this.CreateSession = function() {
        MySelectionClass = Module.SelectionEvents.extend("SelectionEvents", {
            OnSelectionBegin: function () {
                thisWidget.tmpIndexes = [];
            },
            OnSelectionChanged: function (clear, removed, added) {
                var infoTableValue = thisWidget.getProperty('SelectedParts');
                if (infoTableValue.rows == undefined)
                    infoTableValue.rows = [];

                if (clear) {
                    infoTableValue.rows = [];
                    thisWidget.setProperty('SelectedOccurrencePath', "");
                    thisWidget.selectedInstances = [];
                }
                var lastIdPath = "";
                for (let i=0;i<added.size();++i) {
                    let idPath = added.get(i);
                    lastIdPath = idPath;
                    if (thisWidget.selProp) {
                        let propPath = thisWidget.getPropPath(idPath);
                        if (propPath != undefined) {
                            var obj = {};
                            obj[thisWidget.getKey()] = propPath;
                            infoTableValue.rows.push(obj);
                        }
                    } else {
                        infoTableValue.rows.push({'idPath': idPath});
                    }
                }
                thisWidget.setProperty('SelectedOccurrencePath', lastIdPath);

                for (var i=0;i<removed.size();++i) {
                    var idPath = removed.get(i);
                    if (thisWidget.selProp) {
                        let propPath = thisWidget.getPropPath(idPath);
                        if (propPath != undefined) {
                            for (let ii=0;ii<infoTableValue.rows.length;++ii) {
                                if (infoTableValue.rows[ii][thisWidget.getKey()] == propPath) {
                                    infoTableValue.rows.splice(ii, 1);
                                }
                            }
                        }
                    } else {
                        for (let ii=0;ii<infoTableValue.rows.length;++ii) {
                            if (infoTableValue.rows[ii].idPath == idPath) {
                                infoTableValue.rows.splice(ii, 1);
                            }
                        }
                    }
                }

                if (thisWidget.localData !== undefined) { // Data property section
                    for (let i=0;i<removed.size();++i) {
                        let idPath = removed.get(i);
                        var idx = thisWidget.selectedInstances.indexOf(idPath);
                        if (idx !== -1)
                            thisWidget.selectedInstances.splice(idx, 1);
                    }
                    for (let i=0;i<added.size();++i) {
                        let idPath = added.get(i);
                        thisWidget.selectedInstances.push(idPath);
                    }
                }

                for (var si=0;si<thisWidget.selectedInstances.length;++si) {
                    let index = thisWidget.getIndex(thisWidget.selectedInstances[si]);
                    if (index !== undefined)
                        thisWidget.tmpIndexes.push(index);
                }

                thisWidget.updateSelection('Data', thisWidget.tmpIndexes);
                thisWidget.setProperty('SelectedParts', infoTableValue);
                thisWidget.jqElement.triggerHandler('SelectionChanged');
            },
            OnSelectionEnd: function () {
                thisWidget.tmpIndexes = [];
                if (thisWidget.thingViewControls) {
                    thisWidget.updateRightPaneButtonsAvailability();
                }
            }
        });

        // Initialisation
        thisWidget.app = ThingView.CreateCVApplication(thisWidget.thingViewId);
        thisWidget.session = thisWidget.app.GetSession();
        thisWidget.shapeScene = thisWidget.session.MakeShapeScene(true);
        thisWidget.shapeView = thisWidget.shapeScene.MakeShapeView(document.getElementById(thisWidget.thingViewId).firstChild.id, true);

        // shapeView settings
        thisWidget.ApplyProjection();
        thisWidget.ApplyNavigation();

        thisWidget.ApplyBackgroundColor();
        thisWidget.ApplyPartDragger();
        thisWidget.shapeView.ShowSpinCenter(thisWidget.getProperty('SpinCenter') == true);
        thisWidget.shapeView.ShowGnomon(thisWidget.getProperty('Gnomon') == true);
        thisWidget.shapeView.SetAntialiasingMode(Module.AntialiasingMode.SS4X);

        // shapeScene settings
        thisWidget.ApplySelectionFilter();
        thisWidget.selectionObserver = new MySelectionClass();
        thisWidget.shapeScene.RegisterSelectionObserver(thisWidget.selectionObserver);
        thisWidget.ApplyShapeFilters(true);

        // session settings
        thisWidget.session.EnableCrossSiteAccess(thisWidget.getProperty('AllowCORSCredentials') == true);
        if (thisWidget.getProperty('EnableWindchillFileCache') == true) {
            var cacheSize = thisWidget.getProperty('WindchillCacheSize');
            if (cacheSize != undefined) {
                thisWidget.session.EnableFileCache(cacheSize);
            }
        }
    };

    this.StopPlaybackControls = function() {
        thisWidget.playAll = false;
        thisWidget.playState = "stopped";

        if (thisWidget.model) {
            thisWidget.model.StopSequence();
            thisWidget.model.StopAnimation();
        }

        if (thisWidget.bottomWidgetPane) {
            thisWidget.bottomWidgetPane.KillSequenceInterval();
            thisWidget.bottomWidgetPane.KillAnimationInterval();
            thisWidget.bottomWidgetPane.hide();
            thisWidget.bottomWidgetPane.mode = "";
        }
    };

    this.UnloadModel = function() {
        if (ThingView.IsPDFSession() || ThingView.IsSVGSession()) {
            ThingView.Destroy2DCanvas();
            if (thisWidget.session)
                ThingView.Show3DCanvas(thisWidget.session);
        }

        if (thisWidget.thingViewControls) {
            thisWidget.leftWidgetPane = undefined;
            thisWidget.rightWidgetPane = undefined;
            if (thisWidget.displayPlaybackControls) {
                thisWidget.StopPlaybackControls();
                thisWidget.bottomWidgetPane = undefined;
            }
            thisWidget.leftScroll = undefined;
            thisWidget.figureNums = 0;
            thisWidget.figureName = "";
        }

        if (thisWidget.session) {
            thisWidget.session.RemoveAllLoadSources();
        }
        if (thisWidget.shapeScene) {
            thisWidget.shapeScene.RemoveAllCVMarkups(Module.CV_MARKUP_TYPES.CVMARKUPTYPE_ALL);
            thisWidget.shapeScene.RemoveSectionCut();
        }
        if (thisWidget.structure) {
            thisWidget.structure = null;
        }
        if (thisWidget.model) {
            thisWidget.model = null;
        }

        var infoTableValueViews = thisWidget.getProperty('Views');
        if (infoTableValueViews != undefined) {
            infoTableValueViews.rows = [];
            thisWidget.setProperty('Views', infoTableValueViews);
        }
        var infoTableValueParts = thisWidget.getProperty('SelectedParts');
        if (infoTableValueParts != undefined) {
            infoTableValueParts.rows = [];
            thisWidget.setProperty('SelectedParts', infoTableValueParts);
        }
    };

    this.LoadDefaultView = function(callback) {
        var idPathArr = new Module.VectorString();
        idPathArr.push_back('/');
        thisWidget.model.LoadPartsWithCb1(idPathArr, true, 
                                          Module.VisibilityBehaviour.SHOW,
                                          function (result) {
            if (result == true) {
                if (callback) callback();
            }
        });
    };

    this.ApplyOrientation = function (animate) {
        if (!thisWidget.shapeView) return;

        var preset = Module.OrientPreset.ORIENT_ISO1;
        var orientation = thisWidget.getProperty('Orientations');
        if (orientation == 'ISO1')
            preset = Module.OrientPreset.ORIENT_ISO1;
        else if (orientation == 'ISO2')
            preset = Module.OrientPreset.ORIENT_ISO2;
        else if (orientation == 'Top')
            preset = Module.OrientPreset.ORIENT_TOP;
        else if (orientation == 'Bottom')
            preset = Module.OrientPreset.ORIENT_BOTTOM;
        else if (orientation == 'Left')
            preset = Module.OrientPreset.ORIENT_LEFT;
        else if (orientation == 'Right')
            preset = Module.OrientPreset.ORIENT_RIGHT;
        else if (orientation == 'Front')
            preset = Module.OrientPreset.ORIENT_FRONT;
        else if (orientation == 'Back')
            preset = Module.OrientPreset.ORIENT_BACK;

        thisWidget.shapeView.ApplyOrientPreset(preset, animate ? 1000 : 0);
    };

    this.ApplyNavigation = function() {
        if (!thisWidget.shapeView) return;

        var mode = Module.NavMode.CREO_VIEW;
        var navigationMode = thisWidget.getProperty('MouseNavigation');
        if (navigationMode == 'CREOVIEW')
            mode = Module.NavMode.CREO_VIEW;
        else if (navigationMode == 'CREO')
            mode = Module.NavMode.CREO;
        else if (navigationMode == 'CATIAV5COMPATIBLE')
            mode = Module.NavMode.CATIA;
        else if (navigationMode == 'EXPLORE')
            mode = Module.NavMode.EXPLORE;

        if (mode == Module.NavMode.EXPLORE)
            thisWidget.shapeView.SetDoNotRoll(true);
        else
            thisWidget.shapeView.SetDoNotRoll(false);

        thisWidget.shapeView.SetNavigationMode(mode);
    };

    this.ApplyProjection = function() {
        if (!thisWidget.shapeView) return;

        var mode = 'Orthographic';
        var projectionMode = thisWidget.getProperty('ProjectionMode');
        if (projectionMode == 'PERSPECTIVE') mode = 'Perspective';
        else if (projectionMode == 'ORTHOGRAPHIC') mode = 'Orthographic';
        else {
            TW.log.error(projectionMode + ' is an invalid projection mode.');
            return;
        }

        if (mode == 'Perspective') {
            var hfov = thisWidget.getProperty('PerspectiveHFOV');
            if (hfov == undefined) hfov = 60;
            if (hfov > 0 && hfov < 180)
                thisWidget.shapeView.SetPerspectiveProjection(hfov);
            else
                TW.log.error('HFOV must be larger than 0 and less than 180.');
        } else if (mode == 'Orthographic') {
            thisWidget.shapeView.SetOrthographicProjection(1.0);
        }
    };

    this.ApplySelectionFilter = function() {
        if (thisWidget.shapeScene) {
            var enablePartSelection = thisWidget.getProperty('EnablePartSelection');
            if (enablePartSelection == undefined) enablePartSelection = true;

            if (enablePartSelection == true) {
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.PART, Module.SelectionList.PRIMARYSELECTION);
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.PART, Module.SelectionList.PRESELECTION);
            } else if (enablePartSelection == false) {
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.DISABLED, Module.SelectionList.PRIMARYSELECTION);
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.DISABLED, Module.SelectionList.PRESELECTION);
            }
        }
    };

    this.ApplyShapeFilters = function(defaultView) {
        if (thisWidget.shapeFilters == undefined) {
            var defaultDisplayFilter =
            '{' +
                '\"ModelAnnotation\": {' +
                    '\"HiddenByDefault\": true,' +
                    '\"PlanarAnnotation\": true,' +
                    '\"FloatingAnnotation\": false,' +
                    '\"MiscAnnotation\": false' +
                '}' +
            '}';
            var displayFilter = thisWidget.getProperty('DisplayFilter');
            if (displayFilter == undefined) {
                displayFilter = defaultDisplayFilter;
            } else {
                displayFilter = displayFilter.replace(/\s/g, "");
                if (displayFilter == "") displayFilter = defaultDisplayFilter;
            }

            var shapeFilterJson = {};
            try {                
                shapeFilterJson = JSON.parse(displayFilter);
            } catch (error) {
                TW.log.error('JSON parsing error: ' + error);
            }

            if (shapeFilterJson == undefined) shapeFilterJson = {};
            if (shapeFilterJson.ModelAnnotation == undefined) shapeFilterJson.ModelAnnotation = {};
            if (shapeFilterJson.ModelAnnotation.HiddenByDefault    == undefined) shapeFilterJson.ModelAnnotation.HiddenByDefault = true;
            if (shapeFilterJson.ModelAnnotation.PlanarAnnotation   == undefined) shapeFilterJson.ModelAnnotation.PlanarAnnotation = true;
            if (shapeFilterJson.ModelAnnotation.FloatingAnnotation == undefined) shapeFilterJson.ModelAnnotation.FloatingAnnotation = false;
            if (shapeFilterJson.ModelAnnotation.MiscAnnotation     == undefined) shapeFilterJson.ModelAnnotation.MiscAnnotation = false;

            thisWidget.shapeFilters = shapeFilterJson;
        }

        if (thisWidget.shapeScene) {
            var shapeFilters = 0x7; // Solids (0x1), Surfaces (0x2) and Cosmetics (0x4) of Model Geometry
            if (defaultView) {
                if (thisWidget.shapeFilters.ModelAnnotation.HiddenByDefault == false) {
                    if (thisWidget.shapeFilters.ModelAnnotation.PlanarAnnotation   == true) shapeFilters |= 0x100000;
                    if (thisWidget.shapeFilters.ModelAnnotation.FloatingAnnotation == true) shapeFilters |= 0x200000;
                    if (thisWidget.shapeFilters.ModelAnnotation.MiscAnnotation     == true) shapeFilters |= 0x400000;
                }
            } else {
                if (thisWidget.shapeFilters.ModelAnnotation.PlanarAnnotation   == true) shapeFilters |= 0x100000;
                if (thisWidget.shapeFilters.ModelAnnotation.FloatingAnnotation == true) shapeFilters |= 0x200000;
                if (thisWidget.shapeFilters.ModelAnnotation.MiscAnnotation     == true) shapeFilters |= 0x400000;
            }

            thisWidget.shapeScene.SetShapeFilters(shapeFilters);
        }
    };

    this.ApplyPartDragger = function() {
        if (thisWidget.shapeView) {
            var enablePartDragger = thisWidget.getProperty('EnablePartDragger');
            if (enablePartDragger == undefined) enablePartDragger = false;
            
            if (enablePartDragger == true) {
                thisWidget.shapeView.SetDragMode(Module.DragMode.DRAG);
            } else if (enablePartDragger == false) {
                thisWidget.shapeView.SetDragMode(Module.DragMode.NONE);
            }
        }
    };

    this.ApplyBackgroundColor = function () {
        var color = thisWidget.backgroundStyle.backgroundColor.toLowerCase();
        if (color) {
            var parsedColor = thisWidget.parseRGBA(color, true);
            if (parsedColor) {
                var toHex = function(num) {
                    var hex = num.toString(16);
                    if (hex.length < 2) {
                        hex = "0" + hex;
                    }
                    return hex;
                };
                parsedColor = "0x" + toHex(parsedColor[0]) + toHex(parsedColor[1]) + toHex(parsedColor[2]) + "FF";
                thisWidget.shapeView.SetBackgroundColor(parseInt(parsedColor));
            }
        }
    };

    this.LoadModel = function() {
        if (thisWidget.session && thisWidget.productToView) {
            var HandleSequenceStepResult = function(playstate, stepInfo, playpos) {
                TW.log.info("OnSequenceEvent");
                thisWidget.setProperty('SequenceStepNumber', stepInfo.number.toString());
                if (playstate == Module.SequencePlayState.PLAYING)
                    thisWidget.playState = "playing";
                else if (playstate == Module.SequencePlayState.STOPPED)
                    thisWidget.playState = "stopped";
                else if (playstate == Module.SequencePlayState.PAUSED)
                    thisWidget.playState = "paused";

                thisWidget.playPosition = 'START';
                if (playpos == Module.SequencePlayPosition.MIDDLE)
                    thisWidget.playPosition = 'MIDDLE';
                else if (playpos == Module.SequencePlayPosition.END)
                    thisWidget.playPosition = 'END';

                if (stepInfo.acknowledge)
                    thisWidget.jqElement.triggerHandler('SequenceStepAcknowledge');

                if (thisWidget.displayPlaybackControls) {
                    thisWidget.bottomWidgetPane.updateSequenceButtonStatus(stepInfo);
                }
            };

            var GetViewableImage = function(viewable) {
                if (viewable.type == undefined) { // figure
                    thisWidget.figureNums++;
                    thisWidget.figureName = viewable.name;
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_figures.svg';
                } else { // viewstate
                    return GetViewstateImage(viewable.type);
                }
            };

            var GetViewstateImage = function(type) {
                if (type == 'AlternateRep') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_simp_rep.svg';
                } else if (type == 'ViewState') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_all_state.svg';
                } else if (type == 'ExplodeState') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_preset_explode.svg';
                } else if (type == 'SectionCut') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_sec_preset.svg';
                } else {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_default_3d_view.svg';
                }
            };

            var GetViewableName = function(name, limit) {
                const lengthLimit = limit || 60; // px
                const c = document.createElement('canvas');
                const ctx = c.getContext('2d');
                ctx.font = "normal 500 12px 'Open Sans', Arial, sans-serif";

                var newName = name;
                for (var i=0;i<name.length;i++) {
                    const tempName = name.substring(0,i+1);
                    const length = ctx.measureText(tempName).width;
                    if (length > lengthLimit && (i+1) < name.length) {
                        newName = $.trim(name.substring(0, i)) + '&hellip;';
                        break;
                    }
                }

                return newName;
            };

            var GetAvailableViewStateTypes = function() {
                var availableTypes = {};
                availableTypes.ViewState    = thisWidget.getProperty('DisplayViewState');
                if (availableTypes.ViewState == undefined) availableTypes.ViewState = true;

                availableTypes.AlternateRep = thisWidget.getProperty('DisplayAlternateRep');
                if (availableTypes.AlternateRep == undefined) availableTypes.AlternateRep = false;
                availableTypes.ExplodeState = thisWidget.getProperty('DisplayExplodeState');
                if (availableTypes.ExplodeState == undefined) availableTypes.ExplodeState = false;
                availableTypes.SectionCut   = thisWidget.getProperty('DisplaySectionCut');
                if (availableTypes.SectionCut == undefined) availableTypes.SectionCut = false;

                return availableTypes;
            };

            var AssignLoadViewstateFunc = function(id, viewstate) {
                var viewableId = '#ThingViewWidgetVB-' + id.toString();
                thisWidget.jqElement.find(viewableId).unbind('click').click({
                    name: viewstate.name,
                    path: viewstate.path
                }, function (e) {
                    var views = thisWidget.getProperty('Views');
                    if (views != undefined) {
                        for (var i = 0; i < views.rows.length; i++) {
                            if (views.rows[i].name == e.data.name &&
                                views.rows[i].value == e.data.path &&
                                views.rows[i].type == "viewstate") {
                                thisWidget.updateSelection('Views', [i]);
                                break;
                            }
                        }
                    }

                    thisWidget.ApplyShapeFilters(false);
                    thisWidget.LoadViewState(e.data.name, e.data.path);
                });
            };

            var AssignLoadIllustrationFunc = function(id, illustration) {
                var viewableId = '#ThingViewWidgetVB-' + id.toString();
                thisWidget.jqElement.find(viewableId).unbind('click').click({
                    name: illustration.name
                }, function(e) {
                    var views = thisWidget.getProperty('Views');
                    if (views != undefined) {
                        for (var i=0;i<views.rows.length;i++) {
                            if (views.rows[i].name == e.data.name &&
                                views.rows[i].value == unescape(encodeURIComponent(e.data.name)) &&
                                views.rows[i].type == "viewable/illustration3d") {
                                thisWidget.updateSelection('Views', [i]);
                                break;
                            }
                        }
                    }
                    thisWidget.LoadIllustration(e.data.name, function(result, stepInfo) {
                        if (thisWidget.displayPlaybackControls) {
                            thisWidget.bottomWidgetPane.mode = result;
                            thisWidget.bottomWidgetPane.updateButtonStatus(stepInfo);
                        }
                    });
                });
            };

            var UpdateWidgetViewables = function(widgetIllustrations, widgetViewStates) {
                var widgetViewables = [];
                var availableViewstateTypes = GetAvailableViewStateTypes();
                if (widgetIllustrations.length) {
                    thisWidget.displayFigure = true;
                    widgetViewables = widgetIllustrations;
                    thisWidget.jqElement.find('#leftPaneViewablesTitleText').text(thisWidget.l8nTokens.leftPane.figuresTitle);
                    thisWidget.jqElement.find('#leftPaneViewablesTitle').attr('title', thisWidget.l8nTokens.leftPane.figuresTooltip);
                } else {
                    thisWidget.displayFigure = false;
                    widgetViewables = widgetViewStates;
                    thisWidget.jqElement.find('#leftPaneViewablesTitleText').text(thisWidget.l8nTokens.leftPane.viewStatesTitle);
                    thisWidget.jqElement.find('#leftPaneViewablesTitle').attr('title', thisWidget.l8nTokens.leftPane.viewStatesTooltip);
                }

                thisWidget.longestViewableNameLength = 0;
                var getLongestViewableNameLength = function (name) {
                    const c = document.createElement("canvas");
                    const ctx = c.getContext("2d");
                    ctx.font = "normal 500 12px 'Open Sans', Arial, sans-serif";
                    const length = ctx.measureText(name).width + 80;

                    if (length > thisWidget.longestViewableNameLength) {
                        thisWidget.longestViewableNameLength = length;
                    }
                };

                var htmlElem = '';
                for (var i = 0; i < widgetViewables.length; i++) {
                    if (widgetViewables[i].type != undefined && !availableViewstateTypes[widgetViewables[i].type])
                        continue;

                    htmlElem += '<div id=\"ThingViewWidgetVB-';
                    htmlElem += i.toString();
                    htmlElem += '\" class=\"leftPaneViewableItem\" title=\"';
                    htmlElem += widgetViewables[i].name.replace(/"/g, '&#34;');
                    htmlElem += '\"><img src=\"';
                    htmlElem += GetViewableImage(widgetViewables[i]);
                    htmlElem += '\" class=\"leftPaneViewableItemImg\"/><span>';
                    htmlElem += GetViewableName(widgetViewables[i].name);
                    htmlElem += '</span></div>';
                    getLongestViewableNameLength(widgetViewables[i].name);
                }

                if (!thisWidget.displayFigure) {
                    var homeElem = '';
                    homeElem += '<div id=\"ThingViewWidgetVB-Home\" class=\"leftPaneViewableItem\">';
                    homeElem += '<img src=\"../Common/extensions/ptc-thingview-extension/ui/thingview/widget_default_3d_view.svg\"';
                    homeElem += ' class=\"leftPaneViewableItemImg\"/>';
                    homeElem += '<span>' + GetViewableName(thisWidget.l8nTokens.leftPane.defaultViewTitle) + '</span></div>';
                    htmlElem = homeElem + htmlElem;
                    getLongestViewableNameLength(thisWidget.l8nTokens.leftPane.defaultViewTitle);
                }
                thisWidget.jqElement.find('#leftPaneViewablesContent').html(htmlElem);
                thisWidget.leftScroll = $("#leftPaneViewablesContent").scrollable({pos: 'left', jqe: thisWidget.jqElement});

                if (!thisWidget.displayFigure) {
                    thisWidget.jqElement.find('#ThingViewWidgetVB-Home').attr('title', thisWidget.l8nTokens.leftPane.defaultViewTitle);
                }

                if (!thisWidget.displayFigure) {
                    thisWidget.jqElement.find('#ThingViewWidgetVB-Home').unbind('click').click(function() {
                        if (thisWidget.shapeScene && thisWidget.model) {
                            thisWidget.model.DeselectAll(Module.SelectionList.PRIMARYSELECTION);
                            thisWidget.model.DeselectAll(Module.SelectionList.PRESELECTION);
                            thisWidget.model.RemoveAllShapeInstances();
                            thisWidget.shapeScene.RemoveAllCVMarkups(Module.CV_MARKUP_TYPES.CVMARKUPTYPE_ALL);
                            thisWidget.shapeScene.RemoveSectionCut();
                            thisWidget.LoadDefaultView(function() {
                                thisWidget.ApplyShapeFilters(true);
                                thisWidget.ApplyBackgroundColor();
                                thisWidget.applyFormatter();
                                thisWidget.ApplyOrientation(true);
                                thisWidget.UpdateLocation();
                            });
                        }
                    });
                }

                for (let i = 0; i < widgetViewables.length; i++) {
                    if (widgetViewables[i].type != undefined) {
                        if (availableViewstateTypes[widgetViewables[i].type]) {
                            AssignLoadViewstateFunc(i, widgetViewables[i]);
                        }
                    } else {
                        AssignLoadIllustrationFunc(i, widgetViewables[i]);
                    }
                }
            };

            var AssignWidgetButtonFunctions = function() {
                function setVisibility(vis, allNode) {
                    if (!thisWidget.model) return;
                    
                    if (allNode) {
                        thisWidget.model.SetPartVisibility('/', vis,
                                                           Module.ChildBehaviour.INCLUDE,
                                                           Module.InheritBehaviour.USE_DEFAULT);
                    } else {
                        for (var i = 0; i < thisWidget.selectedInstances.length; i++) {
                            thisWidget.model.SetPartVisibility(
                                thisWidget.selectedInstances[i], vis,
                                Module.ChildBehaviour.INCLUDE,
                                Module.InheritBehaviour.USE_DEFAULT
                            );
                        }
                    }
                }

                function disableButton(id, title) {
                    var elem = thisWidget.jqElement.find(id);
                    elem.css({
                        cursor: 'default',
                        opacity: 0.2
                    }).prop({
                        disabled: true
                    });
                    if (title) {
                        elem.attr({
                            title: title + ' (' + thisWidget.l8nTokens.disabled + ')'
                        });
                    }
                }
                function enableButton(id, title) {
                    var elem = thisWidget.jqElement.find(id);
                    elem.css({
                        cursor: 'pointer',
                        opacity: 1.0
                    }).prop({
                        disabled: false
                    });
                    if (title) {
                        elem.attr({
                            title: title
                        });
                    }
                }

                // Right pane opener
                thisWidget.jqElement.find('#rightPaneOpener').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    $(this)
                    .css({
                        cursor: 'default',
                        opacity: 0.2
                    }).prop({
                        disabled: true
                    });

                    if (thisWidget.rightWidgetPane != undefined) {
                        thisWidget.rightWidgetPane.open();
                    }
                });

                // Hide selected
                thisWidget.jqElement.find('#rightPaneButton1').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    setVisibility(false, false);
                });

                // Isolate selected
                thisWidget.jqElement.find('#rightPaneButton2').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    setVisibility(false, true);
                    setVisibility(true, false);
                });

                // Show all
                thisWidget.jqElement.find('#rightPaneButton3').unbind('click').click(function() {
                    setVisibility(true, true);
                });

                // Zoom all
                thisWidget.jqElement.find('#rightPaneButton4').unbind('click').click(function() {
                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                });

                // Zoom selected
                thisWidget.jqElement.find('#rightPaneButton5').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
                });

                // Zoom window
                thisWidget.jqElement.find('#rightPaneButton6').unbind('click').click(function() {
                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_WINDOW, 1000.0);
                });

                // Part dragger
                thisWidget.jqElement.find('#rightPaneButton7').unbind('click').click(function() {
                    thisWidget.setProperty('EnablePartDragger', !thisWidget.getProperty('EnablePartDragger'));
                    thisWidget.rightWidgetPane.setPartDraggerButtonStatus();
                    thisWidget.ApplyPartDragger();
                });

                // Restore part location
                thisWidget.jqElement.find('#rightPaneButton8').unbind('click').click(function () {
                    if (thisWidget.model) {
                        thisWidget.model.UnsetLocation(true/*includeChildren*/);
                    }
                });

                thisWidget.updateRightPaneButtonsAvailability = function () {
                    var selectedPart = thisWidget.getProperty('SelectedOccurrencePath');
                    if (selectedPart != undefined && selectedPart.length > 0) {
                        enableButton('#rightPaneButton1');
                        enableButton('#rightPaneButton2');
                        enableButton('#rightPaneButton5');
                    } else {
                        disableButton('#rightPaneButton1');
                        disableButton('#rightPaneButton2');
                        disableButton('#rightPaneButton5');
                    }
                };

                // Right pane
                if (thisWidget.rightWidgetPane == undefined) {
                    thisWidget.rightWidgetPane = {
                        visibility: false,
                        forceClosed: false,
                        animating: false,
                        hidingMargin: 30,
                        closedRight: '0px',
                        containerWidth: 0
                    };
                }

                // Initialise pane
                thisWidget.rightWidgetPane.initialise = function() {
                    this.containerWidth = thisWidget.jqElement.find('#rightPaneContainer').outerWidth();
                    thisWidget.jqElement.find('#rightPaneContainer').css({
                        right: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px',
                        visibility: 'visible'
                    });
                    thisWidget.jqElement.find("#rightPaneCloser").css({
                        right: this.containerWidth.toString() + 'px'
                    });

                    thisWidget.updateRightPaneButtonsAvailability();
                    this.setPartDraggerButtonStatus();
                };

                // Close pane forcefully
                thisWidget.rightWidgetPane.hide = function() {
                    if (thisWidget.jqElement.find('#rightPaneContainer').css('right') == this.closedRight) {
                        // It's open so close it
                        this.forceClosed = true;
                        thisWidget.jqElement.find('#rightPaneContainer').stop().css({
                            right: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px'
                        });
                        this.animating = false;
                    }
                    disableButton("#rightPaneOpener", thisWidget.l8nTokens.rightPane.openerTooltip);

                    this.visibility = false;
                };

                // Open pane
                thisWidget.rightWidgetPane.show = function() {
                    if (this.forceClosed) {
                        this.forceClosed = false;

                        disableButton("#rightPaneOpener", thisWidget.l8nTokens.rightPane.openerTooltip);

                        this.open();
                    } else {
                        if (!this.visibility) {
                            // Closed
                            thisWidget.jqElement.find('#rightPaneContainer').stop().css({
                                right: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px'
                            });
                            enableButton("#rightPaneOpener", thisWidget.l8nTokens.rightPane.openerTooltip);
                        } else {
                            // Open
                            thisWidget.jqElement.find('#rightPaneContainer').stop().css({
                                right: this.closedRight
                            });
                        }
                        this.animating = false;
                    }
                };

                // Resize event
                thisWidget.rightWidgetPane.resize = function() {
                    let rightPaneContainerBGHeight = thisWidget.jqElement.find('#rightPaneContainerBG').outerHeight();

                    if (thisWidget.displayPlaybackControls) {
                        if (thisWidget.bottomWidgetPane.mode != "") {
                            rightPaneContainerBGHeight -= thisWidget.jqElement.find('#bottomPaneContainer').outerHeight();
                        }
                    }

                    let rightPaneContainerHeight  =
                        10 /* Top offset */ +
                        6 /* Top border */ +
                        thisWidget.jqElement.find('#rightPaneCloser').outerHeight() +
                        6 /* Bottom border */ +
                        10 /* Bottom offset */;

                    let rightPaneContentMaxHeight =
                        rightPaneContainerBGHeight -
                        20 /* Top/Bottom margin */ -
                        12 /* Top/Bottom padding */;

                    let buttons = $("#rightPaneContent").find('.rightPaneButtons');

                    let rightPaneContentHeight =
                        + (6 /* Top margin */ + 40 /* Button height */ + 6 /* Bottom margin */) * buttons.length /* No. of buttons */;

                    thisWidget.jqElement.find("#rightPaneContent").css({
                        height: Math.min(rightPaneContentMaxHeight, rightPaneContentHeight).toString() + 'px'
                    });

                    if (thisWidget.rightScroll)
                        thisWidget.rightScroll.onResize();

                    // Hide Zooming & Selection tools if there is not enough space (height & width)
                    if (rightPaneContainerBGHeight < rightPaneContainerHeight ||
                        !thisWidget.leftWidgetPane.enoughWidth) { // Hide
                        this.hide();
                    } else { // Show
                        this.show();
                    }
                };

                // Set DragSelect button status
                thisWidget.rightWidgetPane.setPartDraggerButtonStatus = function() {
                    if (thisWidget.getProperty('EnablePartDragger') == true) {
                        thisWidget.jqElement.find('#rightPaneButton7').addClass('buttonPressed');
                    } else if (thisWidget.getProperty('EnablePartDragger') == false) {
                        thisWidget.jqElement.find('#rightPaneButton7').removeClass('buttonPressed');
                    }
                };

                if (thisWidget.rightScroll == undefined)
                    thisWidget.rightScroll = $("#rightPaneContent").scrollable();

                // Right pane opener
                thisWidget.rightWidgetPane.open = function() {
                    this.animating = true;
                    if (thisWidget.rightScroll)
                        thisWidget.rightScroll.onResize();
                    thisWidget.jqElement.find('#rightPaneContainer').css({
                        backgroundColor: 'rgba(240,240,240,0.9)'
                    }).stop().animate({
                        right: this.closedRight
                    }, 500, 'swing', function () {
                        this.animating = false;
                    });
        
                    this.visibility = true;
                };
                thisWidget.rightWidgetPane.close = function() {
                    if (this.visibility) {
                        this.animating = true;
                        let rightPaneContainerWidth  = thisWidget.jqElement.find('#rightPaneContainer').outerWidth();
                        thisWidget.jqElement.find('#rightPaneContainer').stop().animate({
                            right: '-' + (rightPaneContainerWidth + this.hidingMargin).toString() + 'px'
                        }, 500, 'swing', function () {
                            this.animating = false;
                            thisWidget.jqElement.find('#rightPaneOpener')
                            .css({
                                cursor: 'pointer',
                                opacity: 1.0
                            }).prop({
                                disabled: false
                            });
                        });
            
                        this.visibility = false;
                    }
                };
                thisWidget.jqElement.find('#rightPaneCloser').unbind('click').click(function() {
                    thisWidget.rightWidgetPane.close();
                });

                // Left pane

                // Left pane opener
                thisWidget.jqElement.find('#leftPaneOpener').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    $(this)
                    .css({
                        cursor: 'default',
                        opacity: 0.2
                    }).prop({
                        disabled: true
                    });

                    if (thisWidget.leftWidgetPane != undefined) {
                        thisWidget.leftWidgetPane.open();
                    }
                });

                // Left pane
                if (thisWidget.leftWidgetPane == undefined) {
                    thisWidget.leftWidgetPane = {
                        visibility: false,
                        forceClosed: false,
                        animating: false,
                        orientsContentVis: thisWidget.jqElement.find('#leftPaneOrientsContent').css('display') == 'table',
                        viewstatesContentVis: thisWidget.jqElement.find('#leftPaneViewablesContent').css('display') == 'block',
                        hidingMargin: 30,
                        closedLeft: '0px',
                        containerWidth: 0,
                        resizer: null,
                        minPaneWidth: 140,
                        minOrientsWidth: 120,
                        minContentWidth: 168,
                        minViewableNameWidth: 60
                    };
                }

                if (thisWidget.displayFigure) {
                    thisWidget.leftWidgetPane.openerTitle = thisWidget.l8nTokens.leftPane.openerFiguresTooltip;
                } else {
                    thisWidget.leftWidgetPane.openerTitle = thisWidget.l8nTokens.leftPane.openerViewStatesTooltip;
                }
                thisWidget.jqElement.find("#leftPaneOpener").attr({title: thisWidget.leftWidgetPane.openerTitle});

                // Save & retrieve width of left pane
                thisWidget.leftWidgetPane.storeWidth = function() {
                    if (typeof(Storage) !== "undefined") {
                        const width = parseFloat(thisWidget.jqElement.find('#leftPaneContainer').outerWidth());
                        if (!isNaN(width)) {
                            localStorage.twxTvWidgetLeftPaneWidth = width;
                        }
                    } else {
                        TW.log.error('This browser does not support Web Storage.');
                    }
                };

                thisWidget.leftWidgetPane.retrieveWidth = function() {
                    if (typeof(Storage) !== "undefined") {
                        const widthStr = localStorage.twxTvWidgetLeftPaneWidth || thisWidget.leftWidgetPane.minPaneWidth;
                        thisWidget.jqElement.find("#leftPaneContainer").css({
                            width: widthStr + "px"
                        });
                    } else {
                        TW.log.error('This browser does not support Web Storage.');
                    }
                };

                // Initialise pane
                thisWidget.leftWidgetPane.initialise = function() {
                    this.containerWidth = thisWidget.jqElement.find('#leftPaneContainer').outerWidth();
                    thisWidget.jqElement.find('#leftPaneContainer').css({
                        left: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px',
                        visibility: 'visible'
                    });
                    thisWidget.jqElement.find("#leftPaneCloser").css({
                        left: this.containerWidth.toString() + 'px'
                    });
                    thisWidget.jqElement.find("#leftPaneResizer").css({
                        left: this.containerWidth + 'px'
                    });
                    thisWidget.jqElement.find("#leftPaneResizerTouch").css({
                        left: (this.containerWidth + 10) + 'px'
                    });
                    thisWidget.jqElement.find("#leftPaneResizerHighlight").css({
                        left: this.containerWidth + 'px'
                    });
                };

                // Close pane forcefully
                thisWidget.leftWidgetPane.hide = function() {
                    if (this.orientsContentVis == true) {
                        // Disable orientation button
                        disableButton('#leftPaneOrientsTitle', thisWidget.l8nTokens.leftPane.orientationTooltip);

                        // Close orientation content
                        this.closeOrientsContent();
                        this.resize();
                    } else {
                        if (thisWidget.jqElement.find('#leftPaneContainer').css('left') == this.closedLeft) {
                            // It's open so close it
                            this.forceClosed = true;
                            thisWidget.jqElement.find('#leftPaneContainer').stop().css({
                                left: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px'
                            });
                            this.animating = false;
                        }
                        disableButton("#leftPaneOpener", this.openerTitle);

                        this.visibility = false;
                    }
                };

                // Open pane
                thisWidget.leftWidgetPane.show = function() {
                    if (this.forceClosed) {
                        this.forceClosed = false;

                        disableButton("#leftPaneOpener", this.openerTitle);

                        this.open();
                    } else {
                        if (!this.visibility) {
                            // Closed
                            thisWidget.jqElement.find('#leftPaneContainer').stop().css({
                                left: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px'
                            });

                            enableButton("#leftPaneOpener", this.openerTitle);
                        } else {
                            // Open
                            thisWidget.jqElement.find('#leftPaneContainer').stop().css({
                                left: this.closedLeft
                            });
                        }
                        this.animating = false;
                    }
                };

                // Resize pane
                thisWidget.leftWidgetPane.resize = function () {
                    thisWidget.leftWidgetPane.resizeHorizontally();

                    let leftPaneContainerRect = document.getElementById('leftPaneContainer').getBoundingClientRect();

                    // Set max height of view states
                    let leftPaneContainerBGHeight = thisWidget.jqElement.find('#leftPaneContainerBG').outerHeight();
                    if (leftPaneContainerBGHeight == 0) return;

                    if (thisWidget.displayPlaybackControls) {
                        if (thisWidget.bottomWidgetPane.mode != "") {
                            leftPaneContainerBGHeight -= thisWidget.jqElement.find('#bottomPaneContainer').outerHeight();
                        }
                    }

                    let leftPaneTopOffset = 10;
                    let leftPaneOrientsTitleHeight = thisWidget.jqElement.find("#leftPaneOrientsTitle").outerHeight(true);
                    let leftPaneOrientsContentHeight = document.getElementById('leftPaneOrientsContent').getBoundingClientRect().height;
                    if (this.orientsHeight == undefined)
                        this.orientsHeight = leftPaneOrientsContentHeight;
                    let leftPaneViewablesTitleHeight = thisWidget.jqElement.find("#leftPaneViewablesTitle").outerHeight(true);
                    let leftPaneBottomBorderHeight = thisWidget.jqElement.find('#bottomBorder').outerHeight();
                    let leftPaneBottomOffset = 10;
                    let height =
                        leftPaneTopOffset +
                        leftPaneOrientsTitleHeight +
                        leftPaneOrientsContentHeight +
                        leftPaneViewablesTitleHeight +
                        leftPaneBottomBorderHeight +
                        leftPaneBottomOffset;
                    let viewstateMaxHeight = leftPaneContainerBGHeight - height;

                    let leftPaneHeight = 0;

                    if (this.viewstatesContentVis) {
                        var vsItems = thisWidget.jqElement.find(".leftPaneViewableItem");
                        if (vsItems.length) {
                            var vsItemHeight = vsItems.outerHeight(true);
                            var vsItemsHeight = vsItemHeight * vsItems.length;

                            var vsMinHeight = Math.min(viewstateMaxHeight, vsItemsHeight);

                            thisWidget.jqElement.find("#leftPaneViewablesContent").css({
                                height: vsMinHeight.toString() + 'px'
                            });

                            leftPaneHeight = height + vsItemHeight;
                        } else {
                            var noVS = thisWidget.jqElement.find('#noViewables');
                            if (noVS.length) {
                                var noVSHeight = noVS.outerHeight(true);
                                leftPaneHeight = height + noVSHeight;
                            }
                        }
                    } else {
                        leftPaneHeight = leftPaneContainerRect.height + leftPaneTopOffset + leftPaneBottomOffset;
                    }

                    if (this.orientsContentVis == false) {
                        if ((leftPaneHeight + this.orientsHeight) < leftPaneContainerBGHeight)
                            enableButton('#leftPaneOrientsTitle', thisWidget.l8nTokens.leftPane.orientationTooltip);
                        else
                            disableButton('#leftPaneOrientsTitle', thisWidget.l8nTokens.leftPane.orientationTooltip);
                    }

                    if (thisWidget.leftScroll)
                        thisWidget.leftScroll.onResize();

                    // Width
                    let maxWidth = thisWidget.jqElement.find('#leftPaneContainerBG').outerWidth();
                    let panesWidth =
                        thisWidget.jqElement.find('#leftPaneContainer').outerWidth() +
                        thisWidget.jqElement.find("#leftPaneCloser").outerWidth() +
                        thisWidget.jqElement.find('#rightPaneContainer').outerWidth() +
                        thisWidget.jqElement.find('#rightPaneCloser').outerWidth();
                    this.enoughWidth = (maxWidth > panesWidth);

                    // Hide pane if there is not enough space (height & width)
                    if (leftPaneHeight > leftPaneContainerBGHeight ||
                        !this.enoughWidth) { // Hide
                        this.hide();
                    } else { // Show
                        this.show();
                    }
                };

                thisWidget.leftWidgetPane.resizeHorizontally = function () {
                    this.containerWidth = thisWidget.jqElement.find('#leftPaneContainer').outerWidth();

                    // Viewables
                    const widthOffset = this.containerWidth - this.minPaneWidth;
                    thisWidget.jqElement.find(".scrollable-content-left").css({
                        width: (this.minContentWidth + widthOffset) + "px"
                    });
                    var pairCount = Math.floor((this.minOrientsWidth + widthOffset) / this.minOrientsWidth);
                    if (pairCount == 3) pairCount = 2;
                    const orientsContentWidth = this.minOrientsWidth * pairCount;
                    thisWidget.jqElement.find("#leftPaneOrientsContent").css({
                        width: orientsContentWidth + "px"
                    });
                    thisWidget.jqElement.find("#leftPaneViewablesContent").css({
                        width: (this.minPaneWidth + widthOffset) + "px"
                    });
                    thisWidget.jqElement.find(".leftPaneViewableItem").each(function () {
                        const title = $(this).attr("title");
                        const newName = GetViewableName(title, thisWidget.leftWidgetPane.minViewableNameWidth + widthOffset);
                        $(this).children("span").html(newName);
                    });

                    // Closer & Resizer
                    thisWidget.jqElement.find("#leftPaneCloser").css({
                        left: this.containerWidth + 'px'
                    });
                    thisWidget.jqElement.find("#leftPaneResizer").css({
                        left: this.containerWidth + 'px'
                    });
                    thisWidget.jqElement.find("#leftPaneResizerTouch").css({
                        left: (this.containerWidth + 10) + 'px'
                    });
                    thisWidget.jqElement.find("#leftPaneResizerHighlight").css({
                        left: this.containerWidth + 'px'
                    });
                };

                // Bottom pane
                if (thisWidget.displayPlaybackControls) {
                    if (thisWidget.bottomWidgetPane == undefined) {
                        thisWidget.bottomWidgetPane = {
                            visibility: false,
                            forceClosed: false,
                            widthMode: 0,
                            closedBottom: '0px',
                            containerHeight: 0,
                            containerWidth: 0,
                            containerLeft: -1,
                            textContainerWidth: 0,
                            sequenceNoAck: false,
                            mode: '', // 'Sequence' or 'Animation'
                            dragging: null,
                            sequenceDuration: 0,
                            sequenceIntervalId: null,
                            animationDuration: 0,
                            animationIntervalId: null,
                            snapped: "none"
                        };
                    }

                    // Save & retrieve position of bottom pane
                    thisWidget.bottomWidgetPane.storePosition = function() {
                        if (typeof(Storage) !== "undefined") {
                            if (this.snapped == "none") {
                                const pos = parseFloat(thisWidget.jqElement.find("#bottomPaneContainer").css("left"));
                                if (!isNaN(pos)) {
                                    localStorage.twxTvWidgetBottomPanePosition = pos;
                                }
                            } else {
                                localStorage.twxTvWidgetBottomPanePosition = this.snapped;
                            }
                        } else {
                            TW.log.error("This browser does not support Web Storage.");
                        }
                    };

                    thisWidget.bottomWidgetPane.retrievePosition = function() {
                        if (typeof(Storage) !== "undefined") {
                            const posStr = localStorage.twxTvWidgetBottomPanePosition;
                            if (posStr) {
                                if (posStr == "left" || posStr == "right") {
                                    this.snapped = posStr;
                                } else {
                                    this.snapped = "none";
                                    this.containerLeft = Number(posStr);
                                }
                            }
                        } else {
                            TW.log.error("This browser does not support Web Storage.");
                        }
                    };

                    // Initialise pane
                    thisWidget.bottomWidgetPane.initialise = function() {
                        var bottomPaneContainerElem = thisWidget.jqElement.find('#bottomPaneContainer');
                        this.containerHeight = bottomPaneContainerElem.outerHeight();
                        if (this.containerHeight == 0) {
                            bottomPaneContainerElem.css({
                                visibility: 'hidden'
                            });
                            return;
                        }

                        var containerBGWidth = thisWidget.jqElement.find('#bottomPaneContainerBG').outerWidth();
                        if (containerBGWidth && this.containerWidth) {
                            if (this.containerLeft == -1 ) {
                                this.containerLeft = Math.max(containerBGWidth / 2 - this.containerWidth / 2, 0);
                            }

                            bottomPaneContainerElem.css({
                                bottom: '-' + (this.containerHeight).toString() + 'px',
                                left: (this.containerLeft).toString() + 'px',
                                visibility: 'visible'
                            });
                        }
                    };

                    // Calculate container width
                    thisWidget.bottomWidgetPane.calculateContainerWidth = function() {
                        let width, scroll;
                        if (this.mode == 'Sequence') {
                            width = $('#bottomPaneDragger').outerWidth(true) +
                                    $('#bottomPaneRewind').outerWidth(true) +
                                    $('#bottomPanePrevious').outerWidth(true) +
                                    $('#bottomPanePlay').outerWidth(true) +
                                    $('#bottomPanePlayAll').outerWidth(true) +
                                    $('#bottomPaneNext').outerWidth(true) +
                                    $('#bottomPaneSequenceStep').outerWidth(true) +
                                    16;
                            scroll = $('#bottomPaneSequenceScrollbarContainer').outerWidth(true);
                        } else {
                            width = $('#bottomPaneDragger').outerWidth(true) +
                                    $('#bottomPaneRewind').outerWidth(true) +
                                    $('#bottomPanePlay').outerWidth(true) +
                                    12;
                            scroll = $('#bottomPaneAnimationScrollbarContainer').outerWidth(true);
                        }
                        let min = width,
                            max = width + scroll;

                        let bgWidth = thisWidget.jqElement.find('#bottomPaneContainerBG').outerWidth();

                        if (bgWidth < min) {
                            return {result: 0, width: 0};
                        } else if (min <= bgWidth && bgWidth <= max) {
                            return {result: 1, width: min};
                        } else {
                            return {result: 2, width: max};
                        }
                    };

                    // Reset container width
                    thisWidget.bottomWidgetPane.resetContainerWidth = function() {
                        this.containerWidth = 0;
                        this.textContainerWidth = 0;
                    };

                    // Resize pane
                    thisWidget.bottomWidgetPane.resize = function() {
                        if (this.mode != 'Sequence' && this.mode != 'Animation') return;

                        var elem = thisWidget.jqElement.find('#bottomPaneContainer');

                        var containerHeight = thisWidget.jqElement.find('#bottomPaneContainerBG').outerHeight();
                        if (containerHeight <= this.containerHeight) {
                            // close forcefully
                            this.forceClosed = true;
                            elem.css({
                                bottom: '-' + (this.containerHeight).toString() + 'px'
                            });
                        } else {
                            if (this.forceClosed) {
                                this.forceClosed = false;
                                elem.css({
                                    bottom: this.closedBottom
                                });
                            }
                        }

                        this.widthMode = thisWidget.bottomWidgetPane.calculateContainerWidth();
                        if (this.widthMode.result == 1) {
                            // hide scrollbar
                            if (this.mode == 'Sequence') {
                                thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer').css({display: 'none'});
                            } else {
                                thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer').css({display: 'none'});
                            }
                            elem.css({width: this.widthMode.width + 'px'});
                        } else if (this.widthMode.result == 2) {
                            // show scrollbar
                            if (this.mode == 'Sequence') {
                                thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer').css({display: 'inline-block'});
                                elem.css({width: this.widthMode.width + 'px'});
                                thisWidget.bottomWidgetPane.SequenceIntervalFunc();
                            } else {
                                thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer').css({display: 'inline-block'});
                                elem.css({width: this.widthMode.width + 'px'});
                                thisWidget.bottomWidgetPane.AnimationIntervalFunc();
                            }
                        } else {
                            // hide pane
                            this.forceClosed = true;
                            elem.css({
                                bottom: '-' + (this.containerHeight).toString() + 'px'
                            });
                        }
                    };

                    // Relocate pane
                    thisWidget.bottomWidgetPane.relocate = function() {
                        var elem = thisWidget.jqElement.find('#bottomPaneContainer');
                        if (this.containerLeft > -1) {
                            if (this.snapped == 'right') {
                                elem.css({
                                    right: '0px',
                                    left: ''
                                });
                            } else if (this.snapped == 'left') {
                                elem.css({
                                    right: '',
                                    left: '0px'
                                });
                            } else {
                                let containerBGWidth = thisWidget.jqElement.find('#bottomPaneContainerBG').outerWidth();
                                let containerWidth = elem.outerWidth();
                                let containerRight = containerBGWidth - this.containerLeft - containerWidth;
                                if (containerRight < 0) {
                                    elem.css({
                                        right: '0px',
                                        left: ''
                                    });
                                } else {
                                    elem.css({
                                        right: '',
                                        left: this.containerLeft.toString() + 'px'
                                    });
                                }
                            }
                            this.containerLeft = Math.max(elem[0].offsetLeft, 0);
                            thisWidget.bottomWidgetPane.storePosition();
                        }
                    };

                    // Show pane
                    thisWidget.bottomWidgetPane.show = function() {
                        this.animating = true;
                        if (this.forceClosed) return;
                        thisWidget.jqElement.find('#bottomPaneContainer').stop()
                        .css({
                            visibility: 'visible'
                        }).animate({
                            bottom: this.closedBottom
                        }, 500, 'linear', function() {
                            this.animating = false;
                        });
                    };

                    // Hide pane
                    thisWidget.bottomWidgetPane.hide = function() {
                        thisWidget.jqElement.find('#bottomPaneContainer').stop().css({
                            bottom: '-' + (this.containerHeight).toString() + 'px',
                            visibility: 'hidden'
                        });
                    };

                    // Show button
                    thisWidget.bottomWidgetPane.showButton = function(id) {
                        thisWidget.jqElement.find(id).css({ display: 'inline-block' });
                    };

                    // Hide button
                    thisWidget.bottomWidgetPane.hideButton = function(id) {
                        thisWidget.jqElement.find(id).css({ display: 'none' });
                    };

                    // Update button status
                    thisWidget.bottomWidgetPane.updateButtonStatus = function(stepInfo) {
                        if (this.mode == "") {
                            thisWidget.bottomWidgetPane.hide();
                        } else if (this.mode == "Sequence") {
                            thisWidget.playAll = false;
                            thisWidget.bottomWidgetPane.resetContainerWidth();
                            thisWidget.bottomWidgetPane.updateSequenceButtonStatus(stepInfo);
                            thisWidget.bottomWidgetPane.initialise();
                            thisWidget.bottomWidgetPane.resize();
                            thisWidget.bottomWidgetPane.relocate();
                            thisWidget.bottomWidgetPane.UpdateSequenceSlider(0);
                            thisWidget.bottomWidgetPane.show();
                        } else if (this.mode == "Animation") {
                            thisWidget.bottomWidgetPane.resetContainerWidth();
                            thisWidget.bottomWidgetPane.updateAnimationButtonStatus();
                            thisWidget.bottomWidgetPane.initialise();
                            thisWidget.bottomWidgetPane.resize();
                            thisWidget.bottomWidgetPane.relocate();
                            this.animationDuration = thisWidget.model.GetAnimationDuration();
                            this.AnimationIntervalFunc();
                            thisWidget.bottomWidgetPane.UpdateAnimationSlider(0);
                            thisWidget.bottomWidgetPane.show();
                        }
                        if (thisWidget.leftWidgetPane != undefined) {
                            thisWidget.leftWidgetPane.resize();
                        }
                        if (thisWidget.rightWidgetPane != undefined) {
                            thisWidget.rightWidgetPane.resize();
                        }
                    };

                    // Update animation button status
                    thisWidget.bottomWidgetPane.updateAnimationButtonStatus = function() {
                        this.hideButton('#bottomPanePrevious');
                        this.hideButton('#bottomPanePause');
                        this.hideButton('#bottomPanePlayAll');
                        this.hideButton('#bottomPaneNext');
                        this.hideButton('#bottomPaneSequenceStep');
                        this.hideButton('#bottomPaneSequenceScrollbarContainer');
                        this.showButton('#bottomPaneRewind');
                        this.showButton('#bottomPanePlay');
                        this.showButton('#bottomPaneAnimationScrollbarContainer');
                        enableButton('#bottomPaneRewind');

                        this.containerWidth = $('#bottomPaneDragger').outerWidth(true) +
                                            $('#bottomPaneRewind').outerWidth(true) +
                                            $('#bottomPanePlay').outerWidth(true) +
                                            $('#bottomPaneAnimationScrollbarContainer').outerWidth(true) +
                                            12;
                        var container = thisWidget.jqElement.find('#bottomPaneContainer');
                        container.css({width: this.containerWidth.toString() + 'px'});

                        thisWidget.jqElement.find('#bottomPaneAnimationScrollbar').css({
                            left: thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer')[0].offsetLeft
                        });
                    };

                    // Handle sequence acknowledgement
                    thisWidget.bottomWidgetPane.handleSequenceAcknowledgement = function(stepInfo) {
                        if (thisWidget.playPosition === 'START') {
                            if (this.sequenceNoAck) {
                                this.sequenceNoAck = false;
                            }
                        } else if (thisWidget.playPosition === 'END') {
                            if (stepInfo.acknowledge) {
                                if (this.sequenceNoAck) {
                                    this.sequenceNoAck = false;
                                    return;
                                }

                                var htmlToWrite = decodeURIComponent(escape(stepInfo.name));
                                var buttonsWidth = thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogStop').outerWidth(true);
                                if (stepInfo.number == 0) {
                                    // Continue | Stop
                                    htmlToWrite = thisWidget.l8nTokens.bottomPane.acknowledgementMessageStartText + " " + htmlToWrite;
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').css({display: 'none'});
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').css({display: 'inline-block'});
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogComplete').css({display: 'none'});

                                    buttonsWidth += thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').outerWidth(true);
                                } else if (stepInfo.number == thisWidget.totalSteps) {
                                    // Replay | Complete | Stop
                                    htmlToWrite = thisWidget.l8nTokens.bottomPane.acknowledgementMessageEndText + " " + htmlToWrite;
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').css({display: 'inline-block'});
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').css({display: 'none'});
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogComplete').css({display: 'inline-block'});

                                    buttonsWidth += thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').outerWidth(true);
                                    buttonsWidth += thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogComplete').outerWidth(true);
                                } else {
                                    // Replay | Continue | Stop
                                    htmlToWrite = thisWidget.l8nTokens.bottomPane.acknowledgementMessageEndText + " " + htmlToWrite;
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').css({display: 'inline-block'});
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').css({display: 'inline-block'});
                                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogComplete').css({display: 'none'});

                                    buttonsWidth += thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').outerWidth(true);
                                    buttonsWidth += thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').outerWidth(true);
                                }
                                thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContentText').html(htmlToWrite);

                                this.showAcknowledgementDialog(buttonsWidth);
                            } else {
                                if (thisWidget.playAll) {
                                    if (stepInfo.number == thisWidget.totalSteps) {
                                        thisWidget.playAll = false;
                                    } else {
                                        var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                                        thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(currentStep + 1);
                                        thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
                                    }
                                }
                            }
                        }
                    };
                    thisWidget.bottomWidgetPane.showAcknowledgementDialog = function(buttonsWidth) {
                        var buttonsWidthTotal = Math.min(buttonsWidth + 8 * 2 /* Left/right margin */,
                                                         parseFloat(thisWidget.jqElement.find('#bottomPaneAcknowledgeContainer').css('width')));
                        thisWidget.jqElement.find('#bottomPaneAcknowledgeDialog').css({
                            width: buttonsWidthTotal + 'px'
                        });

                        var titleHeight = parseFloat(thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogTitle').css('height'));
                        var contentHeight = parseFloat(thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContent').css('height'));
                        var buttonsHeight = parseFloat(thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogButtons').css('height'));
                        thisWidget.jqElement.find('#bottomPaneAcknowledgeDialog').css({
                            height: (titleHeight + contentHeight + buttonsHeight).toString() + 'px',
                            visibility: 'visible'
                        });
                        thisWidget.jqElement.find('#bottomPaneAcknowledgeContainer').css({
                            visibility: 'visible'
                        });
                    };
                    thisWidget.bottomWidgetPane.hideAcknowledgementDialog = function(callback) {
                        thisWidget.jqElement.find('#bottomPaneAcknowledgeDialog').css({
                            visibility: 'hidden'
                        });
                        thisWidget.jqElement.find('#bottomPaneAcknowledgeContainer').css({
                            visibility: 'hidden'
                        });
                        if (callback) {
                            callback();
                        }
                    };

                    thisWidget.bottomWidgetPane.UpdateSequenceSlider = function(value) {
                        var scrollbar = thisWidget.jqElement.find('#bottomPaneSequenceScrollbar')[0];
                        var container = thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer')[0];

                        var offset =  container.offsetLeft;
                        var percent = Math.min(Math.max(value, 0), 10000);
                        var max = container.offsetWidth - scrollbar.offsetWidth;
                        var left = max * percent / 10000;
                        scrollbar.style.left = left + offset + 'px';
                        thisWidget.jqElement.find('#bottomPaneSequenceScrollbarBackgroundElapsed')[0].style.width = (percent / 100) + '%';
                    };

                    thisWidget.bottomWidgetPane.SequenceIntervalFunc = function(stepInfo) {
                        if (0/*stepInfo*/) {
                            if (thisWidget.playPosition == 'START') {
                                thisWidget.bottomWidgetPane.UpdateSequenceSlider(0);
                            } else if (thisWidget.playPosition == 'END') {
                                thisWidget.bottomWidgetPane.UpdateSequenceSlider(10000);
                            }
                        } else {
                            let playPosition = thisWidget.model.GetSequenceStepPlayTime();
                            let playPositionRate = (playPosition / (thisWidget.bottomWidgetPane.sequenceDuration || 1)) * 10000;
                            thisWidget.bottomWidgetPane.UpdateSequenceSlider(playPositionRate);
                        }
                    };

                    thisWidget.bottomWidgetPane.SetSequenceInterval = function(stepNumber) {
                        this.sequenceDuration = thisWidget.model.GetSequenceStepDuration(stepNumber);

                        this.sequenceIntervalId = setInterval(this.SequenceIntervalFunc, 10);
                    };

                    thisWidget.bottomWidgetPane.KillSequenceInterval = function() {
                        if (this.sequenceIntervalId != null) {
                            clearInterval(this.sequenceIntervalId);
                            this.sequenceIntervalId = null;
                        }
                    };

                    // Update sequence button status
                    thisWidget.bottomWidgetPane.updateSequenceButtonStatus = function(stepInfoVec) {
                        var stepInfo;
                        if (typeof stepInfoVec.get === 'function') {
                            stepInfo = stepInfoVec.get(0);
                            thisWidget.playState = "stopped";
                            thisWidget.totalSteps = stepInfo.totalSteps - 1;
                        } else {
                            stepInfo = stepInfoVec;
                        }

                        this.SequenceIntervalFunc(stepInfo);

                        this.showButton('#bottomPanePrevious');
                        this.showButton('#bottomPanePlayAll');
                        this.showButton('#bottomPaneNext');
                        this.showButton('#bottomPaneSequenceScrollbarContainer');
                        this.hideButton('#bottomPaneAnimationScrollbarContainer');

                        // Rewind/Previous button
                        if (stepInfo.number == 0 ||
                            thisWidget.playState === "playing" ||
                            thisWidget.bottomWidgetPane.dragging) {
                            disableButton('#bottomPaneRewind');
                            disableButton('#bottomPanePrevious');
                        } else {
                            enableButton('#bottomPaneRewind');
                            enableButton('#bottomPanePrevious');
                        }

                        // Play/Pause button
                        if (thisWidget.playState === "playing") {
                            this.SetSequenceInterval(stepInfo.number);
                            this.hideButton('#bottomPanePlay');
                            disableButton('#bottomPanePlayAll');
                            this.showButton('#bottomPanePause');
                        } else {
                            this.KillSequenceInterval();
                            this.showButton('#bottomPanePlay');
                            enableButton('#bottomPanePlayAll');
                            this.hideButton('#bottomPanePause');

                            if (stepInfo.number == thisWidget.totalSteps &&
                                thisWidget.playPosition === 'END') {
                                disableButton('#bottomPanePlay');
                                disableButton('#bottomPanePlayAll');
                            } else {
                                enableButton('#bottomPanePlay');
                            }
                        }

                        // Next button
                        if ((stepInfo.number == thisWidget.totalSteps &&
                            thisWidget.playPosition === 'END') ||
                            thisWidget.playState === "playing" ||
                            thisWidget.bottomWidgetPane.dragging) {
                            disableButton('#bottomPaneNext');
                        } else {
                            enableButton('#bottomPaneNext');
                        }

                        // Step status
                        this.showButton('#bottomPaneSequenceStep');
                        var htmlToWrite = "";
                        if (stepInfo.number == 0) {
                            htmlToWrite = "(1/" + thisWidget.totalSteps + ")";
                            thisWidget.bottomWidgetPane.UpdateSequenceSlider(0);
                        } else {
                            htmlToWrite = "(";
                            htmlToWrite += stepInfo.number + "/";
                            htmlToWrite += thisWidget.totalSteps;
                            htmlToWrite += ")";
                        }
                        thisWidget.jqElement.find('#bottomPaneSequenceStepText').html(htmlToWrite);

                        var textContainer = thisWidget.jqElement.find('#bottomPaneSequenceStep');
                        this.textContainerWidth = Math.max(this.textContainerWidth, Math.ceil(textContainer.outerWidth()));
                        textContainer.css({width: this.textContainerWidth.toString() + 'px'});

                        this.containerWidth = $('#bottomPaneDragger').outerWidth(true) +
                                            $('#bottomPaneRewind').outerWidth(true) +
                                            $('#bottomPanePrevious').outerWidth(true) +
                                            $('#bottomPanePlay').outerWidth(true) +
                                            $('#bottomPanePlayAll').outerWidth(true) +
                                            $('#bottomPaneNext').outerWidth(true) +
                                            $('#bottomPaneSequenceStep').outerWidth(true) +
                                            16;
                        let scrollbarContainerWidth = $('#bottomPaneSequenceScrollbarContainer').outerWidth(true);
                        if ((this.containerWidth + scrollbarContainerWidth) < thisWidget.jqElement.find('#bottomPaneContainerBG').outerWidth()) {
                            this.containerWidth += scrollbarContainerWidth;
                        } else {
                            thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer').css({
                                display: 'none'
                            });
                        }
                        var container = thisWidget.jqElement.find('#bottomPaneContainer');
                        container.css({width: this.containerWidth.toString() + 'px'});

                        this.handleSequenceAcknowledgement(stepInfo);
                    };

                    thisWidget.bottomWidgetPane.GotoSequenceTime = function(value) {
                        var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                        this.sequenceDuration = thisWidget.model.GetSequenceStepDuration(currentStep);
                        var goToTime = this.sequenceDuration * value / 10000;

                        thisWidget.model.GoToSequenceStepTime(goToTime);
                    };

                    thisWidget.bottomWidgetPane.GotoAnimationTime = function(value) {
                        var goToTime = this.animationDuration * value / 10000;

                        thisWidget.model.GoToAnimationTime(goToTime);
                    };

                    thisWidget.bottomWidgetPane.UpdateAnimationSlider = function(value) {
                        var scrollbar = thisWidget.jqElement.find('#bottomPaneAnimationScrollbar')[0];
                        var container = thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer')[0];

                        var offset =  container.offsetLeft;
                        var percent = Math.min(Math.max(value, 0), 10000);
                        var max = container.offsetWidth - scrollbar.offsetWidth;
                        var left = max * percent / 10000;
                        scrollbar.style.left = left + offset + 'px';
                        thisWidget.jqElement.find('#bottomPaneAnimationScrollbarBackgroundElapsed')[0].style.width = (percent / 100) + '%';
                    };

                    thisWidget.bottomWidgetPane.AnimationIntervalFunc = function(position) {

                        let playPosition = position != undefined ? position : thisWidget.model.GetAnimationPlayTime();

                        let playPositionRate = parseInt((playPosition / thisWidget.bottomWidgetPane.animationDuration) * 10000);
                        thisWidget.bottomWidgetPane.UpdateAnimationSlider(playPositionRate);

                        if (thisWidget.playState == 'playing' &&
                            playPosition == thisWidget.bottomWidgetPane.animationDuration) {
                            thisWidget.playState = 'stopped';
                            thisWidget.bottomWidgetPane.KillAnimationInterval();
                            thisWidget.bottomWidgetPane.showButton('#bottomPanePlay');
                            thisWidget.bottomWidgetPane.hideButton('#bottomPanePause');
                        }
                    };

                    thisWidget.bottomWidgetPane.SetAnimationInterval = function() {
                        this.animationDuration = thisWidget.model.GetAnimationDuration();
                        this.animationIntervalId = setInterval(this.AnimationIntervalFunc, 10);
                    };

                    thisWidget.bottomWidgetPane.KillAnimationInterval = function() {
                        if (this.animationIntervalId != null) {
                            clearInterval(this.animationIntervalId);
                            this.animationIntervalId = null;
                        }
                    };

                    thisWidget.bottomWidgetPane.HandleAnimationCommand = function(command) {
                        if (command == 'play') {
                            thisWidget.playState = 'playing';
                            thisWidget.model.PlayAnimationWithCallback(function() {
                                thisWidget.playState = 'stopped';
                                thisWidget.bottomWidgetPane.KillAnimationInterval();
                                thisWidget.bottomWidgetPane.AnimationIntervalFunc(thisWidget.bottomWidgetPane.animationDuration);
                                thisWidget.bottomWidgetPane.showButton('#bottomPanePlay');
                                thisWidget.bottomWidgetPane.hideButton('#bottomPanePause');
                            });
                            this.SetAnimationInterval();
                            this.hideButton('#bottomPanePlay');
                            this.showButton('#bottomPanePause');
                        } else if (command == 'pause') {
                            thisWidget.playState = 'paused';
                            thisWidget.model.PauseAnimation();
                            this.KillAnimationInterval();
                            this.showButton('#bottomPanePlay');
                            this.hideButton('#bottomPanePause');
                        } else if (command == 'stop') {
                            thisWidget.playState = 'stopped';
                            thisWidget.model.StopAnimation();
                            this.KillAnimationInterval();
                            this.AnimationIntervalFunc(0);
                            this.showButton('#bottomPanePlay');
                            this.hideButton('#bottomPanePause');
                        }
                    };
                }

                thisWidget.resizeWidgetUI = function() {
                    if (thisWidget.mutationManager.height == "0" ||
                        thisWidget.mutationManager.width == "0")
                        return;

                    if (thisWidget.leftWidgetPane != undefined) {
                        thisWidget.leftWidgetPane.initialise();
                        thisWidget.leftWidgetPane.resize();
                    }
                    if (thisWidget.rightWidgetPane != undefined) {
                        thisWidget.rightWidgetPane.initialise();
                        thisWidget.rightWidgetPane.resize();
                    }
                    if (thisWidget.bottomWidgetPane) {
                        thisWidget.bottomWidgetPane.resize();
                        thisWidget.bottomWidgetPane.relocate();
                    }
                };

                thisWidget.pausePlaybackControls = function() {
                    if (thisWidget.displayPlaybackControls) {
                        if (thisWidget.bottomWidgetPane) {
                            if (thisWidget.bottomWidgetPane.mode == 'Sequence') {
                                thisWidget.playAll = false;
                                if (thisWidget.model) {
                                    thisWidget.model.PauseSequence();
                                }
                                thisWidget.bottomWidgetPane.KillSequenceInterval();
                            } else if (thisWidget.bottomWidgetPane.mode == 'Animation') {
                                thisWidget.bottomWidgetPane.HandleAnimationCommand('pause');
                            }
                        }
                    }
                };

                if (!thisWidget.mutationManager.observer) {
                    var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
                    thisWidget.mutationManager.observer = new MutationObserver(function(mutations) {
                        mutations.forEach(function(mutation) {
                            if (mutation.type === 'attributes') {
                                if (mutation.attributeName === 'height' || mutation.attributeName === 'width') {
                                    if (mutation.oldValue != "0" &&
                                        mutation.oldValue != thisWidget.mutationManager[mutation.attributeName]) {
                                        thisWidget.mutationManager[mutation.attributeName] = mutation.oldValue;
                                        thisWidget.resizeWidgetUI();
                                    }

                                    var visibility = thisWidget.jqElement[0].offsetParent != null;
                                    if (thisWidget.isVisible) {
                                        if (!visibility) {
                                            thisWidget.isVisible = false;
                                            thisWidget.pausePlaybackControls();
                                        }
                                    } else {
                                        if (visibility) {
                                            thisWidget.isVisible = true;
                                            thisWidget.resizeWidgetUI();
                                        }
                                    }
                                }
                            }
                        });
                    });

                    thisWidget.mutationManager.observer.observe(thisWidget.jqElement[0], {
                        attributes: true,
                        attributeFilter: ['width', 'height'],
                        attributeOldValue: true,
                        subtree: true
                    });
                }

                thisWidget.leftWidgetPane.retrieveWidth();
                thisWidget.leftWidgetPane.initialise();
                thisWidget.rightWidgetPane.initialise();
                if (thisWidget.displayPlaybackControls) {
                    thisWidget.bottomWidgetPane.retrievePosition();
                }

                // Left pane opener
                thisWidget.leftWidgetPane.open = function() {
                    this.animating = true;
                    if (thisWidget.leftScroll)
                        thisWidget.leftScroll.onResize();
                    thisWidget.jqElement.find('#leftPaneContainer').css({
                        backgroundColor: 'rgba(240,240,240,0.9)'
                    }).stop().animate({
                        left: this.closedLeft
                    }, 500, 'swing', function() {
                        this.animating = false;
                    });
        
                    this.visibility = true;
                };
                thisWidget.leftWidgetPane.close = function() {
                    if (this.visibility) {
                        this.animating = true;
                        thisWidget.jqElement.find('#leftPaneContainer').stop().animate({
                            left: '-' + (this.containerWidth + this.hidingMargin).toString() + 'px'
                        }, 500, 'swing', function() {
                            this.animating = false;
                            thisWidget.jqElement.find('#leftPaneOpener')
                            .css({
                                cursor: 'pointer',
                                opacity: 1.0
                            }).prop({
                                disabled: false
                            });
                        });
            
                        this.visibility = false;
                    }
                };
                thisWidget.jqElement.find('#leftPaneCloser').unbind('click').click(function() {
                    thisWidget.leftWidgetPane.close();
                });

                // Left pane resizer
                thisWidget.leftWidgetPane.setWidth = function(evt) {
                    const _resizer = thisWidget.leftWidgetPane.resizer;
                    if (!_resizer) return;
                    _resizer.xpos = (_resizer.mouseInput ? evt.clientX : evt.touches[0].pageX) - _resizer.xparent;
                    const offset = _resizer.xpos - _resizer.xoff - (_resizer.mouseInput ? 0 : 10);
                    const width = Math.min(Math.max(_resizer.xmin, _resizer.xcur + offset), _resizer.xmax);
                    _resizer.container.style.width = width + "px";
                    thisWidget.leftWidgetPane.resize();
                };
                thisWidget.leftWidgetPane.initialiseResizer = function(evt) {
                    evt.preventDefault();
                    const mouseInput = evt.type.includes("mouse");
                    const parentRect = thisWidget.jqElement[0].getBoundingClientRect();
                    const container = thisWidget.jqElement.find("#leftPaneContainer")[0];
                    const containerRect = container.getBoundingClientRect();
                    const resizer = mouseInput ? thisWidget.jqElement.find("#leftPaneResizer")[0] : thisWidget.jqElement.find("#leftPaneResizerTouch")[0];
                    thisWidget.leftWidgetPane.resizer = {
                        container,
                        mouseInput,
                        xoff: 0,
                        xpos: 0,
                        xcur: parseInt(resizer.style.left),
                        xmin: thisWidget.leftWidgetPane.minPaneWidth,
                        xmax: parentRect.width * 0.4,
                        xparent: parentRect.left
                    };
                    const _resizer = thisWidget.leftWidgetPane.resizer;
                    _resizer.xpos = (mouseInput ? evt.clientX : evt.touches[0].pageX) - _resizer.xparent;
                    _resizer.xoff = _resizer.xpos - (containerRect.left - _resizer.xparent);
                };

                // Left pane resizer - touch
                var leftPaneResizeTouch = function (evt) {
                    thisWidget.leftWidgetPane.initialiseResizer(evt);

                    function touchMove(e) {
                        e.preventDefault();
                        thisWidget.leftWidgetPane.setWidth(e);
                    }
                    function touchEnd() {
                        thisWidget.jqElement
                        .off("touchmove", touchMove)
                        .off("touchend", touchEnd);
                        if (thisWidget.leftWidgetPane.resizer) {
                            thisWidget.leftWidgetPane.resizer = null;
                            thisWidget.leftWidgetPane.storeWidth();
                        }
                    }
                    thisWidget.jqElement
                    .on("touchmove", touchMove)
                    .on("touchend", touchEnd);
                };
                thisWidget.jqElement.find("#leftPaneResizer").on("touchstart", leftPaneResizeTouch);
                thisWidget.jqElement.find("#leftPaneResizerTouch").on("touchstart", leftPaneResizeTouch);

                // Left pane resizer - mouse
                thisWidget.jqElement.find("#leftPaneResizer").on("mousedown", function(evt) {
                    thisWidget.leftWidgetPane.initialiseResizer(evt);

                    function handleDrag(e) {
                        e.preventDefault();
                        thisWidget.leftWidgetPane.setWidth(e);
                    }
                    function handleMouseUp() {
                        thisWidget.jqElement
                        .off("mousemove", handleDrag)
                        .off("mouseup", handleMouseUp)
                        .off("mouseleave", handleMouseUp);
                        if (thisWidget.leftWidgetPane.resizer) {
                            thisWidget.leftWidgetPane.resizer = null;
                            if (!thisWidget.leftWidgetPane.resizerHovering)
                                thisWidget.leftWidgetPane.hideResizerHighlight();
                            thisWidget.leftWidgetPane.storeWidth();
                        }
                    }
                    thisWidget.jqElement
                    .on("mousemove", handleDrag)
                    .on("mouseup", handleMouseUp)
                    .on("mouseleave", handleMouseUp);
                })
                .mouseenter(function() {
                    thisWidget.leftWidgetPane.resizerHovering = true;
                    thisWidget.leftWidgetPane.showResizerHighlight();
                })
                .mouseleave(function() {
                    thisWidget.leftWidgetPane.resizerHovering = false;
                    if (!thisWidget.leftWidgetPane.resizer) {
                        thisWidget.leftWidgetPane.hideResizerHighlight();
                    }
                });
                thisWidget.leftWidgetPane.showResizerHighlight = function() {
                    thisWidget.jqElement.find("#leftPaneResizerHighlight").css({
                        visibility: "visible"
                    });
                };
                thisWidget.leftWidgetPane.hideResizerHighlight = function() {
                    thisWidget.jqElement.find("#leftPaneResizerHighlight").css({
                        visibility: "hidden"
                    });
                };
                thisWidget.jqElement.find("#leftPaneResizer").on("dblclick", function() {
                    if (thisWidget.longestViewableNameLength != 0) {
                        const width =
                            Math.min(
                                Math.max(thisWidget.leftWidgetPane.minPaneWidth,
                                         thisWidget.longestViewableNameLength),
                                thisWidget.jqElement[0].getBoundingClientRect().width * 0.4
                            );
                        thisWidget.jqElement.find("#leftPaneContainer").css({
                            width: width + "px"
                        });
                        thisWidget.leftWidgetPane.resize();
                        thisWidget.leftWidgetPane.storeWidth();
                    }
                });

                // Toggle orientation contents
                thisWidget.leftWidgetPane.closeOrientsContent = function() {
                    thisWidget.jqElement.find('#leftPaneOrientsContent').css({ display: 'none' });
                    thisWidget.jqElement.find('#leftPaneOrientsTitleMark')
                        .attr({
                            src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_expand.svg'
                        });
                        this.orientsContentVis = false;
                };
                thisWidget.leftWidgetPane.openOrientsContent = function() {
                    thisWidget.jqElement.find('#leftPaneOrientsContent').css({ display: 'table' });
                    thisWidget.jqElement.find('#leftPaneOrientsTitleMark')
                    .attr({
                        src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg'
                    });
                    this.orientsContentVis = true;
                };
                thisWidget.jqElement.find('#leftPaneOrientsTitle').unbind('click').click(function () {
                    if ($(this).prop('disabled')) return;

                    if (thisWidget.leftWidgetPane.orientsContentVis) {
                        thisWidget.leftWidgetPane.closeOrientsContent();
                    } else {
                        thisWidget.leftWidgetPane.openOrientsContent();
                    }
                    thisWidget.leftWidgetPane.resize();
                });

                // Orientations
                thisWidget.jqElement.find('#widgetOrientFront').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_FRONT, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientBack').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_BACK, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientLeft').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_LEFT, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientRight').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_RIGHT, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientBottom').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_BOTTOM, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientTop').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_TOP, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientISO1').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_ISO1, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientISO2').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_ISO2, 1000.0);
                });

                // Toggle viewables contents
                thisWidget.leftWidgetPane.closeViewablesContent = function() {
                    thisWidget.jqElement.find('#leftPaneViewablesContent').css({ display: 'none' });
                    thisWidget.jqElement.find('#leftPaneViewablesTitleMark')
                        .attr({
                            src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_expand.svg'
                        });
                        this.viewstatesContentVis = false;
                };
                thisWidget.leftWidgetPane.openViewablesContent = function() {
                    thisWidget.jqElement.find('#leftPaneViewablesContent').css({ display: 'block' });
                    thisWidget.jqElement.find('#leftPaneViewablesTitleMark')
                        .attr({
                            src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg'
                        });
                        this.viewstatesContentVis = true;
                };
                thisWidget.jqElement.find('#leftPaneViewablesTitle').unbind('click').click(function () {
                    if (thisWidget.leftWidgetPane.viewstatesContentVis) {
                        thisWidget.leftWidgetPane.closeViewablesContent();
                    } else {
                        thisWidget.leftWidgetPane.openViewablesContent();
                    }
                    thisWidget.leftWidgetPane.resize();
                });

                if (thisWidget.displayPlaybackControls) {
                    // Sequence slider
                    thisWidget.bottomWidgetPane.moveSequenceScrollbar = function(evt) {
                        var _dragging = thisWidget.bottomWidgetPane.dragging;
                        if (!_dragging) return;
                        var pos = evt.type.includes('mouse') ? evt.clientX : evt.touches[0].pageX;
                        var left = pos - _dragging.left - _dragging.width / 2;
                        left = Math.min(Math.max(left, 0), _dragging.max);
                        _dragging.elem.style.left = left + _dragging.offset + 'px';
                        
                        var value = (left / _dragging.max) * 10000;
                        thisWidget.jqElement.find('#bottomPaneSequenceScrollbarBackgroundElapsed')[0].style.width = (value / 100) + '%';
                        thisWidget.bottomWidgetPane.GotoSequenceTime(value);
                    };

                    thisWidget.bottomWidgetPane.initialiseSequenceScrollbar = function(evt) {
                        evt.preventDefault();

                        var scrollbar = thisWidget.jqElement.find('#bottomPaneSequenceScrollbar')[0];
                        var container = thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer')[0];
                        var containerRect = container.getBoundingClientRect();
                        thisWidget.bottomWidgetPane.dragging = {
                            elem: scrollbar,
                            left: containerRect.left,
                            width: scrollbar.offsetWidth,
                            max: container.offsetWidth - scrollbar.offsetWidth,
                            offset: container.offsetLeft,
                            resume: thisWidget.playState == 'playing'
                        };

                        if (thisWidget.bottomWidgetPane.dragging.resume) {
                            thisWidget.model.PauseSequence();
                        }
                    };

                    // Sequence slider - touch
                    thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer').on('touchstart', function(evt) {
                        thisWidget.bottomWidgetPane.initialiseSequenceScrollbar(evt);
                        thisWidget.bottomWidgetPane.moveSequenceScrollbar(evt);

                        function touchMove(e) {
                            e.preventDefault();
                            thisWidget.bottomWidgetPane.moveSequenceScrollbar(e);
                        }
                        function touchEnd(ev) {
                            thisWidget.jqElement
                            .off('touchmove', touchMove)
                            .off('touchend', touchEnd);
                            ev.preventDefault();
                            if (thisWidget.bottomWidgetPane.dragging &&
                                thisWidget.bottomWidgetPane.dragging.resume) {
                                thisWidget.model.PlaySequenceStep();
                            }
                            thisWidget.bottomWidgetPane.dragging = null;
                        }
                        thisWidget.jqElement
                        .on('touchmove', touchMove)
                        .on('touchend', touchEnd);
                    });

                    // Sequence slider - mouse
                    thisWidget.jqElement.find('#bottomPaneSequenceScrollbarContainer').on('mousedown', function(evt) {
                        thisWidget.bottomWidgetPane.initialiseSequenceScrollbar(evt);
                        thisWidget.bottomWidgetPane.moveSequenceScrollbar(evt);

                        function mouseDrag(e) {
                            e.preventDefault();
                            thisWidget.bottomWidgetPane.moveSequenceScrollbar(e);
                        }
                        function mouseUp(ev) {
                            thisWidget.jqElement
                            .off('mousemove', mouseDrag)
                            .off('mouseup', mouseUp)
                            .off('mouseleave', mouseUp);
                            ev.preventDefault();
                            thisWidget.bottomWidgetPane.moveSequenceScrollbar(ev);
                            if (thisWidget.bottomWidgetPane.dragging &&
                                thisWidget.bottomWidgetPane.dragging.resume) {
                                thisWidget.model.PlaySequenceStep();
                            }
                            thisWidget.bottomWidgetPane.dragging = null;
                            if (!thisWidget.bottomWidgetPane.sliderHovering)
                                thisWidget.bottomWidgetPane.hideSequenceScrollbarHover();
                        }
                        thisWidget.jqElement
                        .on('mousemove', mouseDrag)
                        .on('mouseup', mouseUp)
                        .on('mouseleave', mouseUp);
                    })
                    .mouseenter(function() {
                        thisWidget.bottomWidgetPane.sliderHovering = true;
                        thisWidget.bottomWidgetPane.showSequenceScrollbarHover();
                    })
                    .mouseleave(function() {
                        thisWidget.bottomWidgetPane.sliderHovering = false;
                        if (!thisWidget.bottomWidgetPane.dragging) {
                            thisWidget.bottomWidgetPane.hideSequenceScrollbarHover();
                        }
                    });

                    thisWidget.bottomWidgetPane.showSequenceScrollbarHover = function() {
                        thisWidget.jqElement.find('#bottomPaneSequenceScrollbar').css({
                            background: 'rgba(0, 0, 0, 0.5)',
                            boxShadow: '0px 0px 0px 2px rgba(67, 196, 241, 0.7)'
                        });
                    };
                    thisWidget.bottomWidgetPane.hideSequenceScrollbarHover = function() {
                        thisWidget.jqElement.find('#bottomPaneSequenceScrollbar').css({
                            background: 'rgba(0, 0, 0, 0.0)',
                            boxShadow: ''
                        });
                    };


                    // Animation slider
                    thisWidget.bottomWidgetPane.moveAnimationScrollbar = function(evt) {
                        var _dragging = thisWidget.bottomWidgetPane.dragging;
                        if (!_dragging) return;
                        var pos = evt.type.includes('mouse') ? evt.clientX : evt.touches[0].pageX;
                        var left = pos - _dragging.left - _dragging.width / 2;
                        left = Math.min(Math.max(left, 0), _dragging.max);
                        _dragging.elem.style.left = left + _dragging.offset + 'px';
                        
                        var value = (left / _dragging.max) * 10000;
                        thisWidget.jqElement.find('#bottomPaneAnimationScrollbarBackgroundElapsed')[0].style.width = (value / 100) + '%';
                        thisWidget.bottomWidgetPane.GotoAnimationTime(value);
                    };

                    thisWidget.bottomWidgetPane.initialiseAnimationScrollbar = function(evt) {
                        evt.preventDefault();

                        var scrollbar = thisWidget.jqElement.find('#bottomPaneAnimationScrollbar')[0];
                        var container = thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer')[0];
                        var containerRect = container.getBoundingClientRect();
                        thisWidget.bottomWidgetPane.dragging = {
                            elem: scrollbar,
                            left: containerRect.left,
                            width: scrollbar.offsetWidth,
                            max: container.offsetWidth - scrollbar.offsetWidth,
                            offset: container.offsetLeft,
                            resume: thisWidget.playState == 'playing'
                        };

                        if (thisWidget.bottomWidgetPane.dragging.resume) {
                            thisWidget.model.PauseAnimation();
                        }
                    };

                    // Animation slider - touch
                    thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer').on('touchstart', function(evt) {
                        thisWidget.bottomWidgetPane.initialiseAnimationScrollbar(evt);
                        thisWidget.bottomWidgetPane.moveAnimationScrollbar(evt);

                        function touchMove(e) {
                            e.preventDefault();
                            thisWidget.bottomWidgetPane.moveAnimationScrollbar(e);
                        }
                        function touchEnd(ev) {
                            thisWidget.jqElement
                            .off('touchmove', touchMove)
                            .off('touchend', touchEnd);
                            ev.preventDefault();
                            if (thisWidget.bottomWidgetPane.dragging &&
                                thisWidget.bottomWidgetPane.dragging.resume) {
                                thisWidget.model.PlayAnimation();
                            }
                            thisWidget.bottomWidgetPane.dragging = null;
                        }
                        thisWidget.jqElement
                        .on('touchmove', touchMove)
                        .on('touchend', touchEnd);
                    });

                    // Animation slider - mouse
                    thisWidget.jqElement.find('#bottomPaneAnimationScrollbarContainer').on('mousedown', function(evt) {
                        thisWidget.bottomWidgetPane.initialiseAnimationScrollbar(evt);
                        thisWidget.bottomWidgetPane.moveAnimationScrollbar(evt);

                        function mouseDrag(e) {
                            e.preventDefault();
                            thisWidget.bottomWidgetPane.moveAnimationScrollbar(e);
                        }
                        function mouseUp(ev) {
                            thisWidget.jqElement
                            .off('mousemove', mouseDrag)
                            .off('mouseup', mouseUp)
                            .off('mouseleave', mouseUp);
                            ev.preventDefault();
                            thisWidget.bottomWidgetPane.moveAnimationScrollbar(ev);
                            if (thisWidget.bottomWidgetPane.dragging &&
                                thisWidget.bottomWidgetPane.dragging.resume) {
                                thisWidget.model.PlayAnimation();
                            }
                            thisWidget.bottomWidgetPane.dragging = null;
                            if (!thisWidget.bottomWidgetPane.sliderHovering)
                                thisWidget.bottomWidgetPane.hideAnimationScrollbarHover();
                        }
                        thisWidget.jqElement
                        .on('mousemove', mouseDrag)
                        .on('mouseup', mouseUp)
                        .on('mouseleave', mouseUp);
                    })
                    .mouseenter(function() {
                        thisWidget.bottomWidgetPane.sliderHovering = true;
                        thisWidget.bottomWidgetPane.showAnimationScrollbarHover();
                    })
                    .mouseleave(function() {
                        thisWidget.bottomWidgetPane.sliderHovering = false;
                        if (!thisWidget.bottomWidgetPane.dragging) {
                            thisWidget.bottomWidgetPane.hideAnimationScrollbarHover();
                        }
                    });

                    thisWidget.bottomWidgetPane.showAnimationScrollbarHover = function() {
                        thisWidget.jqElement.find('#bottomPaneAnimationScrollbar').css({
                            background: 'rgba(0, 0, 0, 0.5)',
                            boxShadow: '0px 0px 0px 2px rgba(67, 196, 241, 0.7)'
                        });
                    };
                    thisWidget.bottomWidgetPane.hideAnimationScrollbarHover = function() {
                        thisWidget.jqElement.find('#bottomPaneAnimationScrollbar').css({
                            background: 'rgba(0, 0, 0, 0.0)',
                            boxShadow: ''
                        });
                    };

                    // Bottom pane dragger
                    thisWidget.bottomWidgetPane.move = function(evt) {
                        var _dragging = thisWidget.bottomWidgetPane.dragging;
                        if (!_dragging) return;
                        _dragging.xpos = (evt.type.includes('mouse') ? evt.clientX : evt.touches[0].pageX) - _dragging.xparent;
                        var left = _dragging.xpos - _dragging.xoff;
                        if (left <= _dragging.xsnap) {
                            left = _dragging.xmin;
                            this.snapped = 'left';
                            _dragging.elem.style.left = '0px';
                            _dragging.elem.style.removeProperty('right');
                        } else if (left >= (_dragging.xmax - _dragging.xsnap)) {
                            left = _dragging.xmax;
                            this.snapped = 'right';
                            _dragging.elem.style.removeProperty('left');
                            _dragging.elem.style.right = '0px';
                        } else {
                            this.snapped = 'none';
                            _dragging.elem.style.left = left + 'px';
                            _dragging.elem.style.removeProperty('right');
                        }
                        this.containerLeft = left;
                    };

                    thisWidget.bottomWidgetPane.initialiseBottomPaneDragger = function(evt) {
                        evt.preventDefault();
                        var parentRect = thisWidget.jqElement[0].getBoundingClientRect();
                        var container = thisWidget.jqElement.find('#bottomPaneContainer')[0];
                        var containerRect = container.getBoundingClientRect();
                        thisWidget.bottomWidgetPane.dragging = {
                            elem: container,
                            xoff: 0,
                            xpos: 0,
                            xmin: 0,
                            xmax: thisWidget.jqElement.find('#bottomPaneContainerBG').outerWidth() - containerRect.width - 2,
                            xsnap: 10,
                            xparent: parentRect.left
                        };
                        var _dragging = thisWidget.bottomWidgetPane.dragging;
                        _dragging.xpos = (evt.type.includes('mouse') ? evt.clientX : evt.touches[0].pageX) - _dragging.xparent;
                        _dragging.xoff = _dragging.xpos - (containerRect.left - _dragging.xparent);
                    };

                    // Bottom pane dragger - touch
                    thisWidget.jqElement.find('#bottomPaneDragger').on('touchstart', function(evt) {
                        thisWidget.bottomWidgetPane.initialiseBottomPaneDragger(evt);

                        function touchMove(e) {
                            e.preventDefault();
                            thisWidget.bottomWidgetPane.move(e);
                        }
                        function touchEnd() {
                            thisWidget.jqElement
                            .off('touchmove', touchMove)
                            .off('touchend', touchEnd);
                            if (thisWidget.bottomWidgetPane.dragging) {
                                thisWidget.bottomWidgetPane.dragging = null;
                                thisWidget.bottomWidgetPane.storePosition();
                            }
                        }
                        thisWidget.jqElement
                        .on('touchmove', touchMove)
                        .on('touchend', touchEnd);
                    });

                    // Bottom pane dragger - mouse
                    thisWidget.jqElement.find('#bottomPaneDragger').on('mousedown', function(evt) {
                        thisWidget.bottomWidgetPane.initialiseBottomPaneDragger(evt);

                        function handleDrag(e) {
                            e.preventDefault();
                            thisWidget.bottomWidgetPane.move(e);
                        }
                        function handleMouseUp(e) {
                            thisWidget.jqElement
                            .off('mousemove', handleDrag)
                            .off('mouseup', handleMouseUp)
                            .off('mouseleave', handleMouseUp);
                            if (thisWidget.bottomWidgetPane.dragging) {
                                thisWidget.bottomWidgetPane.dragging = null;
                                thisWidget.bottomWidgetPane.storePosition();
                            }
                        }
                        thisWidget.jqElement
                        .on('mousemove', handleDrag)
                        .on('mouseup', handleMouseUp)
                        .on('mouseleave', handleMouseUp);
                    });

                    // Sequence & Animation
                    thisWidget.jqElement.find('#bottomPaneRewind').unbind('click').click(function() {
                        if ($(this).prop('disabled')) return;

                        if (thisWidget.bottomWidgetPane.mode == 'Sequence') {
                            thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(0);
                            thisWidget.model.GoToSequenceStep(0, Module.SequencePlayPosition.START, false);
                        } else if (thisWidget.bottomWidgetPane.mode == 'Animation') {
                            thisWidget.bottomWidgetPane.HandleAnimationCommand('stop');
                            thisWidget.bottomWidgetPane.UpdateAnimationSlider(0);
                        }
                    });
                    thisWidget.jqElement.find('#bottomPanePrevious').unbind('click').click(function() {
                        if ($(this).prop('disabled')) return;

                        var prevStep = Math.max(Number(thisWidget.getProperty('SequenceStepNumber')) - 1, 0);
                        thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(prevStep);
                        thisWidget.model.GoToSequenceStep(prevStep, prevStep == 0 ? Module.SequencePlayPosition.START : Module.SequencePlayPosition.END, false);
                        thisWidget.bottomWidgetPane.sequenceNoAck = true;
                    });
                    thisWidget.jqElement.find('#bottomPanePlay').unbind('click').click(function() {
                        if ($(this).prop('disabled')) return;

                        if (thisWidget.bottomWidgetPane.mode == 'Sequence') {
                            thisWidget.playAll = false;
                            if (thisWidget.playPosition === 'END') {
                                var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                                thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(currentStep);
                                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
                            } else {
                                thisWidget.model.PlaySequenceStep();
                            }
                        } else if (thisWidget.bottomWidgetPane.mode == 'Animation') {
                            thisWidget.bottomWidgetPane.HandleAnimationCommand('play');
                        }
                    });
                    thisWidget.jqElement.find('#bottomPanePlayAll').unbind('click').click(function() {
                        if ($(this).prop('disabled')) return;

                        thisWidget.playAll = true;
                        if (thisWidget.playPosition === 'END') {
                            var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                            thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(currentStep);
                            thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
                        } else {
                            thisWidget.model.PlaySequenceStep();
                        }
                    });
                    thisWidget.jqElement.find('#bottomPanePause').unbind('click').click(function() {
                        if ($(this).prop('disabled')) return;

                        if (thisWidget.bottomWidgetPane.mode == 'Sequence') {
                            thisWidget.playAll = false;
                            thisWidget.model.PauseSequence();
                        } else if (thisWidget.bottomWidgetPane.mode == 'Animation') {
                            thisWidget.bottomWidgetPane.HandleAnimationCommand('pause');
                        }
                    });
                    thisWidget.jqElement.find('#bottomPaneNext').unbind('click').click(function() {
                        if ($(this).prop('disabled')) return;

                        var nextStep = Math.min(Number(thisWidget.getProperty('SequenceStepNumber')) + 1, thisWidget.totalSteps);
                        thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(nextStep);
                        thisWidget.model.GoToSequenceStep(nextStep, Module.SequencePlayPosition.END, false);
                        thisWidget.bottomWidgetPane.sequenceNoAck = true;
                    });
                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogReplay').unbind('click').click(function() {
                        thisWidget.bottomWidgetPane.hideAcknowledgementDialog(function() {
                            var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                            thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(currentStep);
                            thisWidget.model.GoToSequenceStep(currentStep, Module.SequencePlayPosition.START, true);
                        });
                    });
                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogContinue').unbind('click').click(function() {
                        thisWidget.bottomWidgetPane.hideAcknowledgementDialog(function() {
                            var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                            if (currentStep == 0 || thisWidget.playAll) {
                                thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(currentStep + 1);
                                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
                            }
                        });
                    });
                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogComplete').unbind('click').click(function() {
                        thisWidget.bottomWidgetPane.hideAcknowledgementDialog();
                        thisWidget.playAll = false;
                    });
                    thisWidget.jqElement.find('#bottomPaneAcknowledgeDialogStop').unbind('click').click(function() {
                        thisWidget.bottomWidgetPane.hideAcknowledgementDialog();
                        thisWidget.playAll = false;
                        var prevStep = Math.max(Number(thisWidget.getProperty('SequenceStepNumber')) - 1, 0);
                        thisWidget.bottomWidgetPane.sequenceDuration = thisWidget.model.GetSequenceStepDuration(prevStep);
                        thisWidget.model.GoToSequenceStep(prevStep, prevStep == 0 ? Module.SequencePlayPosition.START : Module.SequencePlayPosition.END, false);
                        thisWidget.bottomWidgetPane.sequenceNoAck = true;
                    });
                }

                // initialise pane
                thisWidget.leftWidgetPane.resize();
                thisWidget.rightWidgetPane.resize();
            };

            var StructureLoadComplete = function() {
                TW.log.info('Structure Loaded');

                var infoTableValue = thisWidget.getProperty('Views');
                if (infoTableValue.rows == undefined)
                    infoTableValue.rows = [];

                var spinfoTableValue = thisWidget.getProperty('SelectedParts');
                if (spinfoTableValue.rows == undefined)
                    spinfoTableValue.rows = [];

                if (thisWidget.selProp) {
                    var visitorArray = [];
                    var visitor = thisWidget.model.MakeModelVisitor();
                    visitor.SetCallback(function(name, id, depth) {
                        visitorArray.push({id: id, depth: depth});
                    });
                    thisWidget.model.AcceptVisitor(visitor);

                    for (var i = 0; i < visitorArray.length ; i++) {
                        var idpath = visitorArray[i].id;
                        var parentId = "";
                        var n = idpath.lastIndexOf("/");
                        if (n == 0 && idpath.length > 1) {
                            parentId = "/";
                        } else if (n > 0) {
                            parentId = idpath.substr(0, n);
                        }
                        
                        var value = thisWidget.structure.GetPropertyValue(idpath, thisWidget.selProp.groupName, thisWidget.selProp.name);
                        if (value.length) {
                            var path = value;
                            if (parentId.length) {
                                var parent = thisWidget.selProp.idPropMap[parentId];
                                if (parent) {
                                    path = parent.path + "/" + value;
                                } else {
                                    path = "";
                                    for (var j=0;j<visitorArray[i].depth;j++) {
                                        path += "/";
                                    }
                                    path += value;
                                }
                            }
                            thisWidget.selProp.idPropMap[idpath] = {path: path, value: value};

                            if (thisWidget.selProp.valueMode) path = value;
                            if (thisWidget.selProp.propIdMap[path] != undefined) {
                                thisWidget.selProp.propIdMap[path].push(idpath);
                            } else {
                                thisWidget.selProp.propIdMap[path] = [idpath];
                            }
                        }
                    }
                    visitorArray = [];
                    visitor.delete();
                }

                thisWidget.viewsData.reset();

                const annoSets = thisWidget.structure.GetAnnotationSets();
                if (annoSets) {
                    for (let i = 0; i < annoSets.size() ; i++) {
                        const annoSetTemp = annoSets.get(i);
                        annoSetTemp.humanReadableDisplayName = decodeURIComponent(escape(annoSetTemp.name));
                        annoSetTemp.componentName = decodeURIComponent(escape(annoSetTemp.componentName));
                        thisWidget.viewsData.annotations.push(annoSetTemp);
                        if (annoSetTemp.propertyName == "model") {
                            infoTableValue.rows.push({
                                name: annoSetTemp.humanReadableDisplayName,
                                type: "annotation/model",
                                value: annoSetTemp.name,
                                partPath: annoSetTemp.componentName
                            });
                        } else if (annoSetTemp.propertyName == "document" ||
                                   annoSetTemp.propertyName == "drawing") {
                            // check if the ext is pdf
                            const extension =
                                annoSetTemp.propertyValue.substring(annoSetTemp.propertyValue.lastIndexOf(".") + 1).toLowerCase();
                            if (extension == "pdf") {
                                infoTableValue.rows.push({
                                    name: annoSetTemp.humanReadableDisplayName,
                                    type: "annotation/" + annoSetTemp.propertyName,
                                    value: annoSetTemp.name,
                                    partPath: annoSetTemp.componentName
                                });
                            }
                        }
                    }
                }

                const getPartPathFromIdPath = function (idPath) {
                    var name = [];
                    var idpath = idPath;
                    if (idpath == "/") {
                        return thisWidget.structure.GetInstanceName(idpath);
                    } else {
                        while (idpath.length) {
                            name.unshift(thisWidget.structure.GetInstanceName(idpath));
                            idpath = idpath.substring(0, idpath.lastIndexOf("/"));
                        }
                        name.unshift(thisWidget.structure.GetInstanceName("/"));
                    }
                    
                    return name.join("/");
                };

                const documents = thisWidget.structure.GetDocuments();
                if (documents) {
                    for (let i = 0; i < documents.size() ; i++) {
                        const docTemp = documents.get(i);
                        docTemp.humanReadableDisplayName = decodeURIComponent(escape(docTemp.displayName));
                        if (docTemp.type == Module.ViewableType.DOCUMENT ||
                            docTemp.type == Module.ViewableType.DRAWING) {
                            // check if the ext is pdf
                            const extension =
                                docTemp.fileSource.substring(docTemp.fileSource.lastIndexOf(".") + 1).toLowerCase();
                            if (extension == "pdf") {
                                const partPath = getPartPathFromIdPath(docTemp.idPath);
                                infoTableValue.rows.push({
                                    name: docTemp.humanReadableDisplayName,
                                    type: "viewable/" + (docTemp.type == Module.ViewableType.DOCUMENT ? "document" : "drawing"),
                                    value: docTemp.name,
                                    partPath: partPath
                                });
                                docTemp.partPath = partPath;
                                thisWidget.viewsData.documents.push(docTemp);
                            }
                        }
                    }
                }

                var widgetIllustrations = [];
                var widgetViewStates = [];
                var illustrations = thisWidget.structure.GetIllustrations();
                if (illustrations.size() > 0) {
                    for (let i = 0; i < illustrations.size() ; i++) {
                        const illustrationTemp = illustrations.get(i);
                        illustrationTemp.humanReadableDisplayName = decodeURIComponent(escape(illustrationTemp.name));
                        const partPath = getPartPathFromIdPath(illustrationTemp.idPath);
                        infoTableValue.rows.push({
                            name: illustrationTemp.humanReadableDisplayName,
                            type: 'viewable/illustration3d',
                            value: illustrationTemp.name,
                            partPath: partPath
                        });
                        illustrationTemp.partPath = partPath;
                        thisWidget.viewsData.viewables.push(illustrationTemp);

                        if (thisWidget.thingViewControls) {
                            widgetIllustrations.push({name: illustrationTemp.humanReadableDisplayName});
                        } else {
                            thisWidget.figureNums++;
                            thisWidget.figureName = illustrationTemp.humanReadableDisplayName;
                        }
                    }
                } else {
                    var viewStates = thisWidget.structure.GetViewStates();
                    if (viewStates) {
                        for (let i = 0; i < viewStates.size(); i++) {
                            const viewStateTemp = viewStates.get(i);
                            viewStateTemp.humanReadableDisplayName = decodeURIComponent(escape(viewStateTemp.name));
                            const partPath = getPartPathFromIdPath(viewStateTemp.path);
                            infoTableValue.rows.push({
                                name: viewStateTemp.humanReadableDisplayName,
                                type: 'viewstate',
                                value: viewStateTemp.path,
                                partPath: partPath
                            });
                            viewStateTemp.partPath = partPath;
                            thisWidget.viewsData.viewstates.push(viewStateTemp);
    
                            if (thisWidget.thingViewControls) {
                                if (viewStateTemp.path == '/') {
                                    widgetViewStates.push({
                                        name: viewStateTemp.humanReadableDisplayName,
                                        path: viewStateTemp.path,
                                        type: viewStateTemp.type
                                    });
                                }
                            }
                        }
                    }
                }

                if (thisWidget.thingViewControls) {
                    UpdateWidgetViewables(widgetIllustrations, widgetViewStates);
                    AssignWidgetButtonFunctions();
                }

                thisWidget.setProperty('Views', infoTableValue);
                thisWidget.setProperty('SelectedParts', spinfoTableValue);
            };

            var ModelLoadComplete = function() {
                thisWidget.ApplyBackgroundColor();
                thisWidget.ApplyOrientation(false);
                thisWidget.UpdateLocation();

                // Set callbacks
                thisWidget.model.SetSequenceEventCallback(function(playstate, stepNum, playpos) {
                    HandleSequenceStepResult(playstate, stepNum, playpos);
                });

                thisWidget.model.SetSelectionCallback(function(type, si, idPath, selected, selType) {
                    if (selType == Module.SelectionList.PRESELECTION) {
                        if (selected) {
                            thisWidget.setProperty("PreSelectedOccurrencePath", idPath);
                        } else {
                            thisWidget.setProperty("PreSelectedOccurrencePath", "");
                        }
                        thisWidget.jqElement.triggerHandler('PreSelectionChanged');
                    }
                });

                function modelLoaded() {
                    TW.log.info('Model loaded');
                    thisWidget.shapeScene.ShowProgress(false);

                    setTimeout(thisWidget.applyFormatter, 100);
                    thisWidget.jqElement.triggerHandler('Loaded');
                    thisWidget.loadingModel = false;
                }

                const pdfSource = thisWidget.structure.GetPropertyValue("/", "", "pdfSource");
                if (pdfSource === "true") {
                    // Loading PDF directly
                    if (thisWidget.viewsData.documents.length === 1) {
                        thisWidget.SetWidgetUIVisible(false);
                        thisWidget.LoadPdf(thisWidget.viewsData.documents[0]);
                    }
                    modelLoaded();
                } else if (thisWidget.figureNums == 0) {
                    // No figures so load default view
                    thisWidget.LoadDefaultView(function() {
                        thisWidget.ApplyOrientation(false);
                        thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000);
                        thisWidget.UpdateLocation();
                        modelLoaded();
                    });
                } else {
                    if (thisWidget.figureNums == 1) {
                        // If we have only one figure, load it
                        thisWidget.LoadIllustration(thisWidget.figureName, function(result, stepInfo) {
                            modelLoaded();
                            if (thisWidget.displayPlaybackControls) {
                                thisWidget.bottomWidgetPane.mode = result;
                                thisWidget.bottomWidgetPane.updateButtonStatus(stepInfo);
                            }
                        });
                    } else {
                        // no need to load anything
                        modelLoaded();

                        // but show the figures menu
                        thisWidget.jqElement.find('#leftPaneOpener')
                        .css({
                            cursor: 'default',
                            opacity: 0.2
                        }).prop({
                            disabled: true
                        });
                        if (thisWidget.leftWidgetPane != undefined) {
                            thisWidget.leftWidgetPane.open();
                            thisWidget.leftWidgetPane.closeOrientsContent();
                            thisWidget.leftWidgetPane.resize();
                        }
                    }
                }
            };

            var logErrorStack = function(errorStack) {
                for (var i=0;i<errorStack.size();i++) {
                    var error = errorStack.get(i);
                    TW.log.error('Load Model error [' + error.number + '] ' + error.name + ' - ' + error.message);
                }
            };

            thisWidget.loadingModel = true;
            thisWidget.model = thisWidget.shapeScene.MakeModel();

            if (thisWidget.windchillSourceData == true) {
                var widgetParams = new Module.NameValueVec();
                widgetParams.push_back({name:"sourceUrl",value:thisWidget.productToView});
                widgetParams.push_back({name:"templateUrl",value:thisWidget.templateUrl});
                widgetParams.push_back({name:"mapUrl",value:thisWidget.mapUrl});
                widgetParams.push_back({name:"oid",value:thisWidget.oid});
                widgetParams.push_back({name:"markupUrl",value:thisWidget.markupUrl});

                thisWidget.structure = thisWidget.session.LoadStructureWithWCURL(
                    widgetParams, true,
                    function(success, errorStack) {
                        if (success) {
                            thisWidget.model.LoadStructure(
                                thisWidget.structure, false, false,
                                function (_success, _isStructure, _errorStack) {
                                    if (_success === true) {
                                        if (_isStructure === true) {
                                            // The structure has finished loading
                                            StructureLoadComplete();
                                        } else {
                                            // The entire model has finished loading
                                            ModelLoadComplete();
                                        }
                                    } else {
                                        thisWidget.loadingModel = false;
                                        TW.log.error('Failed to load model');
                                        logErrorStack(_errorStack);
                                        thisWidget.UnloadModel();
                                    }
                                }
                            );
                        } else {
                            thisWidget.loadingModel = false;
                            TW.log.error('Failed to load structure with Windchill URL');
                            logErrorStack(errorStack);
                        }
                    }
                );
            } else {
                thisWidget.structure = thisWidget.session.LoadStructureWithURL(
                    thisWidget.productToView, true,
                    function(success, errorStack) {
                        if (success) {
                            thisWidget.model.LoadStructure(
                                thisWidget.structure, false, false,
                                function (_success, _isStructure, _errorStack) {
                                    if (_success === true) {
                                        if (_isStructure === true) {
                                            // The structure has finished loading
                                            StructureLoadComplete();
                                        } else {
                                            // The entire model has finished loading
                                            ModelLoadComplete();
                                        }
                                    } else {
                                        thisWidget.loadingModel = false;
                                        TW.log.error('Failed to load model');
                                        logErrorStack(_errorStack);
                                        thisWidget.UnloadModel();
                                    }
                                }
                            );
                        } else {
                            thisWidget.loadingModel = false;
                            TW.log.error('Failed to load structure with URL');
                            logErrorStack(errorStack);
                        }
                    }
                );
            }

            setTimeout(function() {
                thisWidget.shapeScene.ShowProgress(true);
            }, 500);
        }
    };

    this.UpdateLocation  = function() {
        thisWidget.GetViewLocation();
    };

    this.SetWidgetUIVisible = function (visibility) {
        if (!thisWidget.thingViewControls) return;
        $("#rightPaneOpener").css("display", visibility === true ? "" : "none");
        $("#rightPaneContainerBG").css("display", visibility === true ? "" : "none");
        $("#leftPaneOpener").css("display", visibility === true ? "" : "none");
        $("#leftPaneContainerBG").css("display", visibility === true ? "" : "none");
        $("#bottomPaneContainerBG").css("display", visibility === true ? "" : "none");

        thisWidget.resizeWidgetUI();
    };

    this.LoadPdf = function (doc) {
        if (!thisWidget.documentScene) {
            thisWidget.documentScene = thisWidget.session.MakeDocumentScene();
        }
        thisWidget.documentScene.LoadPdf(doc.idPath, doc.index, thisWidget.structure, function (success) {
            if (success) {
                thisWidget.documentScene.GetPdfBuffer(function(val) {
                    ThingView.LoadPDF(thisWidget.thingViewId, val, false, null, false, function(loadStatus) {
                        ThingView.ApplyPDFLocalisation(thisWidget.l8nTokens.pdf);
                        ThingView.SetPdfToolbar(thisWidget.thingViewId, true, thisWidget.pdfToolbar);
                        if (loadStatus == ThingView.LOAD_EVENT.LOAD_FAILURE) {
                            TW.log.error("OnLoadPDFError - Failed to load PDF.");
                        }
                    });
                });
            } else {
                TW.log.error("OnLoadPdfError - Failed to load PDF.");
            }
        });
    };

    this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
        switch (propertyName) {
            case 'Data': {
                if (thisWidget.shapeScene) {
                    thisWidget.selectedInstances = [];
                    thisWidget.shapeScene.DeselectAllInstances();
                } else {
                    TW.log.info("DeselectAll cannot be called as model is not loaded");
                }
                var i = selectedRowIndices.length;
                var idPathArr = new Module.VectorString();

                var infoTableValue = thisWidget.getProperty('SelectedParts');
                infoTableValue.rows = [];

                var lastIdPath;
                while (i--) {
                    var id = getCachedOccurrencePath(selectedRowIndices[i]);
                    idPathArr.push_back(id);
                    thisWidget.selectedInstances.push(id);
                    lastIdPath = id;
                    if (thisWidget.selProp) {
                        var propPath = thisWidget.getPropPath(id);
                        if (propPath != undefined) {
                            var obj = {};
                            obj[thisWidget.getKey()] = propPath;
                            infoTableValue.rows.push(obj);
                        }
                    } else {
                        infoTableValue.rows.push({ 'idPath': id });
                    }
                }
                thisWidget.shapeScene.SelectInstances(idPathArr, true);
                if (lastIdPath !== undefined)
                    thisWidget.setProperty('SelectedOccurrencePath', lastIdPath);
                else
                    thisWidget.setProperty('SelectedOccurrencePath', '');
                thisWidget.setProperty('SelectedParts', infoTableValue);
                if (thisWidget.thingViewControls) {
                    thisWidget.updateRightPaneButtonsAvailability();
                }
            }
            break;
            case 'Views': {
                if (selectedRows.length == 1) {
                    if (selectedRows[0].type == "annotation/model") {
                        if (ThingView.IsPDFSession() || ThingView.IsSVGSession()){
                            thisWidget.SetWidgetUIVisible(true);
                            ThingView.Destroy2DCanvas();
                            ThingView.Show3DCanvas(thisWidget.session);
                        }
                        if (thisWidget.model) {
                            thisWidget.StopPlaybackControls();
                            thisWidget.model.ResetToPvkDefault();
                            thisWidget.model.LoadAnnotationSetWithCallback(selectedRows[0].value, function (success, name) {
                                if (success === true) {
                                    TW.log.info("OnLoadAnnotationSetComplete");
                                    if (thisWidget.model.HasAnimation())
                                        thisWidget.jqElement.triggerHandler('HasAnimation');

                                    if (thisWidget.displayPlaybackControls) {
                                        thisWidget.bottomWidgetPane.mode = thisWidget.model.HasAnimation() ? "Animation" : "";
                                        thisWidget.bottomWidgetPane.updateButtonStatus();
                                    }
                                } else {
                                    TW.log.error("OnLoadAnnotationSetError");
                                }
                            });
                        } else {
                            TW.log.error("OnLoadAnnotationSetError - Model does not exist.");
                        }
                    } else if (selectedRows[0].type == "annotation/document" ||
                               selectedRows[0].type == "annotation/drawing") {
                        thisWidget.SetWidgetUIVisible(false);
                        if (!thisWidget.documentScene)
                            thisWidget.documentScene = thisWidget.session.MakeDocumentScene();
                        thisWidget.documentScene.LoadPdfAnnotationSet(selectedRows[0].value, thisWidget.structure, function (success) {
                            if (success) {
                                const annotationSetObject = thisWidget.documentScene.GetPdfAnnotationSet();
                                const annotationSet = [];
                                for (var i = 0; i < annotationSetObject.size(); i++) {
                                    annotationSet.push(annotationSetObject.get(i));
                                }
                                var docIndex = -1;
                                const propertyValue = thisWidget.viewsData.annotations.map(function(annotation, index){
                                    if (annotation.humanReadableDisplayName === selectedRows[0].name &&
                                        annotation.componentName == selectedRows[0].partPath) {
                                        docIndex = index;
                                        return annotation.propertyValue;
                                    }
                                });
                                if (docIndex != -1) {
                                    const documentViewable =
                                        thisWidget.viewsData.documents[thisWidget.viewsData.documents.map(function(viewable){return viewable.name;}).indexOf(propertyValue[docIndex])];
                                    ThingView.LoadPdfAnnotationSet(
                                        documentViewable,
                                        thisWidget.thingViewId,
                                        thisWidget.documentScene,
                                        thisWidget.structure,
                                        annotationSet,
                                        false,
                                        function () {
                                            ThingView.ApplyPDFLocalisation(thisWidget.l8nTokens.pdf);
                                            ThingView.SetPdfToolbar(thisWidget.thingViewId, true, thisWidget.pdfToolbar);
                                        }
                                    );
                                }
                            } else {
                                TW.log.error("OnLoadPdfAnnotationSetError - Failed to load PDF annotation set.");
                            }
                        });
                    } else if (selectedRows[0].type == "viewable/illustration3d") {
                        if (ThingView.IsPDFSession() || ThingView.IsSVGSession()){
                            thisWidget.SetWidgetUIVisible(true);
                            ThingView.Destroy2DCanvas();
                            ThingView.Show3DCanvas(thisWidget.session);
                        }
                        thisWidget.LoadIllustration(selectedRows[0].name, function(result, stepInfo) {
                            if (thisWidget.displayPlaybackControls) {
                                thisWidget.bottomWidgetPane.mode = result;
                                thisWidget.bottomWidgetPane.updateButtonStatus(stepInfo);
                            }
                        });
                    } else if (selectedRows[0].type == "viewable/document" ||
                               selectedRows[0].type == "viewable/drawing") {
                        thisWidget.SetWidgetUIVisible(false);

                        const docs = thisWidget.viewsData.documents;
                        var docIndex = -1;
                        for (let i=0;i<docs.length;i++) {
                            if (docs[i].humanReadableDisplayName === selectedRows[0].name &&
                                docs[i].partPath === selectedRows[0].partPath) {
                                docIndex = i;
                                break;
                            }
                        }
                        if (docIndex != -1) {
                            thisWidget.LoadPdf(docs[docIndex]);
                        }
                    } else if (selectedRows[0].type == "viewstate") {
                        if (ThingView.IsPDFSession() || ThingView.IsSVGSession()){
                            thisWidget.SetWidgetUIVisible(true);
                            ThingView.Destroy2DCanvas();
                            ThingView.Show3DCanvas(thisWidget.session);
                        }
                        thisWidget.ApplyShapeFilters(false);
                        thisWidget.LoadViewState(selectedRows[0].name, selectedRows[0].value);
                    }
                } else {
                    TW.log.info("must have only one selected row");
                }
            }
            break;
        }
    };

    this.updateProperty = function(updatePropertyInfo) {
        switch (updatePropertyInfo.TargetProperty) {
            case 'ProductToView': {
                if (!thisWidget.loadingModel) {
                    this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                    thisWidget.productToView = thisWidget.getProperty('ProductToView');

                    if (thisWidget.windchillSourceData == true) {
                        setTemplateUrl();
                    }
                
                    TW.log.info('ProductToView property updated unload existing model and load new one: ' + thisWidget.productToView);
                    thisWidget.UnloadModel();
                    thisWidget.LoadModel();
                }
                break;
            }
            case 'Orientation': {
                TW.log.info('Orientation updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
            case 'Position': {
                TW.log.info('Position updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
            case 'Orientations': {
                TW.log.info('Orientations updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyOrientation(true);
                break;
            }
            case 'MouseNavigation': {
                TW.log.info('MouseNavigation updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyNavigation();
                break;
            }
            case 'BackgroundStyle': {
                TW.log.info('BackgroundStyle updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.backgroundStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundStyle', ''));
                thisWidget.ApplyBackgroundColor();
                break;
            }
            case 'SelectedParts': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                var localSelectedParts = updatePropertyInfo.ActualDataRows;
                if (thisWidget.selProp) {
                    var tempArr = JSON.parse(JSON.stringify(localSelectedParts));
                    localSelectedParts = [];
                    for (var i0=0;i0<tempArr.length;++i0) {
                        var arr = thisWidget.selProp.propIdMap[thisWidget.selProp.valueMode ? tempArr[i0].propValue : tempArr[i0].propPath];
                        for (var i1=0;i1<arr.length;i1++) {
                            localSelectedParts.push({idPath:arr[i1]});
                        }
                    }
                }

                if (localSelectedParts.length == 0) { // Nothing selected, clear selection
                    thisWidget.selectedInstances = [];
                    thisWidget.shapeScene.DeselectAllInstances();
                    return;
                }

                var idPathArr = new Module.VectorString();
                var deselectidPathArr = new Module.VectorString();

                var selInstances = [];

                for (let i=0;i<thisWidget.selectedInstances.length;++i) {
                    let idx = -1;
                    for (var ii=0;ii<localSelectedParts.length;++ii) {
                        if (localSelectedParts[ii].idPath == thisWidget.selectedInstances[i])
                            idx = 0;
                    }

                    if (idx == -1) { // Deselect currently selected parts not in new selection list
                        deselectidPathArr.push_back(thisWidget.selectedInstances[i]);
                    } else {
                        selInstances.push(thisWidget.selectedInstances[i]);
                    }
                }

                var infoTableValue = thisWidget.getProperty('SelectedParts');
                infoTableValue.rows = [];

                for (var i=0;i<localSelectedParts.length;++i) {
                    var idPath = localSelectedParts[i].idPath;
                    if (idPath != undefined) {
                        var idx = thisWidget.selectedInstances.indexOf(idPath);
                        if (idx == -1) { // If new selection list is not in current selection list select the parts
                            idPathArr.push_back(idPath);
                            selInstances.push(idPath);
                        }
                        if (thisWidget.selProp) {
                            var propPath = thisWidget.getPropPath(idPath);
                            if (propPath != undefined) {
                                var obj = {};
                                obj[thisWidget.getKey()] = propPath;
                                infoTableValue.rows.push(obj);
                            }
                        } else {
                            infoTableValue.rows.push({'idPath': idPath});
                        }
                    }
                }

                thisWidget.selectedInstances = selInstances.slice(0);
                thisWidget.shapeScene.SelectInstances(deselectidPathArr, false);
                thisWidget.shapeScene.SelectInstances(idPathArr, true);
                thisWidget.setProperty('SelectedParts', infoTableValue);
                break;
            }
            case 'Data': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.localData = updatePropertyInfo.ActualDataRows;
                if (thisWidget.localData && thisWidget.localData.length > 0) {
                    let i = thisWidget.localData.length;
                    while (i--) {
                        thisWidget.cachedOccurrencePath[i] = null;
                    }
                }

                for (let i in thisWidget.localData) {
                    var formatResult = TW.getStyleFromStateFormatting({DataRow: thisWidget.localData[i], StateFormatting: thisWidget.formatter});
                    if (formatResult.foregroundColor) {
                        if (thisWidget.model) {
                            var color = this.parseRGBA(formatResult.foregroundColor);
                            thisWidget.model.SetPartColor(
                                thisWidget.localData[i][thisWidget.occurrenceIdField],
                                parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]),
                                Module.ChildBehaviour.IGNORED,
                                Module.InheritBehaviour.USE_DEFAULT
                            );
                        }
                    }
                }
                break;
            }
            case 'Gnomon': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.shapeView) {
                    var showGnomon = thisWidget.getProperty('Gnomon');
                    if (showGnomon == undefined) showGnomon = false;
                    if (showGnomon == true) {
                        thisWidget.shapeView.ShowGnomon(true);
                    } else if (showGnomon == false) {
                        thisWidget.shapeView.ShowGnomon(false);
                    }
                }
                break;
            }
            case 'EnablePartSelection': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplySelectionFilter();
                break;
            }
            case 'EnablePartDragger': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyPartDragger();
                if (thisWidget.thingViewControls) {
                    thisWidget.rightWidgetPane.setPartDraggerButtonStatus();
                }
                break;
            }
            case 'SpinCenter': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.shapeView) {
                    var showSpinCenter = thisWidget.getProperty('SpinCenter');
                    if (showSpinCenter == undefined) showSpinCenter = false;

                    if (showSpinCenter == true) {
                        thisWidget.shapeView.ShowSpinCenter(true);
                    } else if (showSpinCenter == false) {
                        thisWidget.shapeView.ShowSpinCenter(false);
                    }
                }
                break;
            }
            case 'WindchillSourceData': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
            case 'ProjectionMode': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyProjection();
                break;
            }
            case 'PerspectiveHFOV': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyProjection();
                break;
            }
        }
    };

    this.GetViewLocation = function() {
        if (thisWidget.shapeView) {
            var loc = thisWidget.shapeView.GetViewLocation();

            loc.position.x = Number(loc.position.x.toFixed(6));
            loc.position.y = Number(loc.position.y.toFixed(6));
            loc.position.z = Number(loc.position.z.toFixed(6));

            loc.orientation.x = Number(loc.orientation.x.toFixed(3));
            loc.orientation.y = Number(loc.orientation.y.toFixed(3));
            loc.orientation.z = Number(loc.orientation.z.toFixed(3));

            thisWidget.setProperty('Position', loc.position.x + ',' + loc.position.y + ',' + loc.position.z);
            thisWidget.setProperty('Orientation', loc.orientation.x + ',' + loc.orientation.y + ',' + loc.orientation.z);
        }
    };

    this.SetViewLocation = function() {
        if (thisWidget.shapeView) {
            var orientation = thisWidget.getProperty('Orientation');
            var orientArray = orientation.split(',');
            var position = thisWidget.getProperty('Position');
            var posArray = position.split(',');

            if (orientArray.length == 3 && posArray.length == 3) {
                var loc = {
                    position: {
                        x: Number(posArray[0]),
                        y: Number(posArray[1]),
                        z: Number(posArray[2]),
                        valid: true
                    },
                    orientation: {
                        x: Number(orientArray[0]),
                        y: Number(orientArray[1]),
                        z: Number(orientArray[2]) 
                    },
                    scale: { x: 1.0, y: 1.0, z: 1.0 },
                    size : { x: 1.0, y: 1.0, z: 1.0 },
                    valid: true
                };
                
                thisWidget.shapeView.SetViewLocation(loc);
            }
        }
    };

    this.LoadIllustration = function(name, callback) {
        if (thisWidget.model) {
            thisWidget.StopPlaybackControls();
            setTimeout(function() {
                thisWidget.model.LoadIllustrationWithCallback(
                    unescape(encodeURIComponent(name)),
                    function(success, pviFile, stepInfoVec) {
                        if (success === true) {
                            TW.log.info("OnLoadIllustrationComplete");
                            var figureType = "";
                            if (thisWidget.model.HasAnimation()) {
                                figureType = "Animation";
                                thisWidget.jqElement.triggerHandler('HasAnimation');
                            }
                            if (thisWidget.model.HasSequence()) {
                                figureType = "Sequence";
                                thisWidget.jqElement.triggerHandler('HasSequence');
                                thisWidget.setProperty('SequenceStepNumber', '0');
                            }
                            if (callback) callback(figureType, stepInfoVec);
                        } else {
                            TW.log.error("OnLoadIllustrationError");
                        }
                    }
                );
            }, 50);
        } else {
            TW.log.error("OnLoadViewStateError - Model does not exist.");
        }
    };

    this.LoadViewState = function(name, path) {
        if (thisWidget.model) {
            thisWidget.StopPlaybackControls();
            thisWidget.model.LoadViewStateWithCallback(
                unescape(encodeURIComponent(name)), path,
                function (success, _name) {
                    if (success === true) {
                        TW.log.info("OnLoadViewStateComplete");
                    } else {
                        TW.log.error("OnLoadViewStateError");
                    }
                }
            );
        } else {
            TW.log.error("OnLoadViewStateError - Model does not exist.");
        }
    };

    this.parseRGBA = function (color, integer) {
        var colorParts;
        var parsedColor = color.replace(/\s\s*/g, ''); // Remove all spaces

        // Checks for 6 digit hex and converts string to integer
        if (colorParts = /^#([\da-fA-F]{2})([\da-fA-F]{2})([\da-fA-F]{2})/.exec(parsedColor))
            colorParts = [parseInt(colorParts[1], 16), parseInt(colorParts[2], 16), parseInt(colorParts[3], 16)];

        // Checks for 3 digit hex and converts string to integer
        else if (colorParts = /^#([\da-fA-F])([\da-fA-F])([\da-fA-F])/.exec(parsedColor))
            colorParts = [parseInt(colorParts[1], 16) * 17, parseInt(colorParts[2], 16) * 17, parseInt(colorParts[3], 16) * 17];

        // Checks for rgba and converts string to
        // integer/float using unary + operator to save bytes
        else if (colorParts = /^rgba\(([\d]+),([\d]+),([\d]+),([\d]+|[\d]*.[\d]+)\)/.exec(parsedColor))
            colorParts = [+colorParts[1], +colorParts[2], +colorParts[3], +colorParts[4]];

        // Checks for rgb and converts string to
        // integer/float using unary + operator to save bytes
        else if (colorParts = /^rgb\(([\d]+),([\d]+),([\d]+)\)/.exec(parsedColor))
            colorParts = [+colorParts[1], +colorParts[2], +colorParts[3]];

        // Otherwise throw an exception to make debugging easier
        else
            colorParts = [0,0,0,1];

        // Performs RGBA conversion by default
        isNaN(colorParts[3]) && (colorParts[3] = 1);

        if (integer !== true) {
            if (colorParts[0] != 0)
                colorParts[0] = colorParts[0] / 255;
            if (colorParts[1] != 0)
                colorParts[1] = colorParts[1] / 255;
            if (colorParts[2] != 0)
                colorParts[2] = colorParts[2] / 255;
        }
        // Adds or removes 4th value based on rgba support
        // Support is flipped twice to prevent errors if
        // it's not defined
        return colorParts;
        };

    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'GetViewLocation') {
            thisWidget.GetViewLocation();
        } else if (serviceName === 'SetViewLocation') {
            thisWidget.SetViewLocation();
        } else if (serviceName === 'ZoomAll') {
            thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
        } else if (serviceName === 'ZoomSelected') {
            thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
        } else if (serviceName === 'PlaySequenceStep') {
            if (thisWidget.playPosition === 'END') {
                let currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
            } else {
                thisWidget.model.PlaySequenceStep();
            }
        } else if (serviceName === 'PauseSequence') {
            thisWidget.model.PauseSequence();
        } else if (serviceName === 'StopSequence') {
            thisWidget.model.StopSequence();
        } else if (serviceName === 'RewindSequence') {
            thisWidget.model.GoToSequenceStep(0, Module.SequencePlayPosition.START, false);
        } else if (serviceName === 'NextSequenceStep') {
            let currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
            if (thisWidget.playState === "playing")
                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
            else
                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, false);
        } else if (serviceName === 'PrevSequenceStep') {
            let currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
            if (thisWidget.playState === "stopped") {
                thisWidget.model.GoToSequenceStep(currentStep - 1, Module.SequencePlayPosition.START, false);
            } else if (thisWidget.playState === "playing") {
                thisWidget.model.GoToSequenceStep(currentStep, Module.SequencePlayPosition.START, true);
            }
        } else if (serviceName === 'PlayAnimation') {
            thisWidget.model.PlayAnimation();
            if (thisWidget.displayPlaybackControls) {
                thisWidget.bottomWidgetPane.SetAnimationInterval();
            }
        } else if (serviceName === 'PauseAnimation') {
            thisWidget.model.PauseAnimation();
            if (thisWidget.displayPlaybackControls) {
                thisWidget.bottomWidgetPane.KillAnimationInterval();
            }
        } else if (serviceName === 'StopAnimation') {
            thisWidget.model.StopAnimation();
            if (thisWidget.displayPlaybackControls) {
                thisWidget.bottomWidgetPane.KillAnimationInterval();
            }
        } else {
            TW.log.error('thingview widget, unexpected serviceName invoked "' + serviceName + '"');
        }
    };

    this.beforeDestroy = function() {
        if (thisWidget.shapeScene !== undefined)
            thisWidget.shapeScene.UnRegisterSelectionObserver();
        thisWidget.UnloadModel();
        if (thisWidget.session !== undefined) {
            ThingView.DeleteSession(thisWidget.thingViewId);
        }
        thisWidget.session = undefined;
        TW.log.info('Thing View Widget .beforeDestroy');
        if (thisWidget.jqElement) {
            thisWidget.jqElement.find('img').unbind('click');
        }

        if (thisWidget.mutationManager.observer) {
            thisWidget.mutationManager.observer.disconnect();
        }
        
        thisWidget.formatter = null;
        thisWidget.localData = null;
        thisWidget.cachedOccurrencePath = [];
        thisWidget = null;
    };
};

!(function (jQuery, document) {
    "use strict";

    var pluginName = "scrollable",
        defaults = {
            containerClass: "scrollable-container",
            containerNoScrollLeftClass: "scrollable-container-noscroll-left",
            containerNoScrollRightClass: "scrollable-container-noscroll-right",
            contentLeftClass: "scrollable-content-left",
            contentRightClass: "scrollable-content-right",
            scrollbarContainerLeftClass: "scrollable-scrollbar-container-left",
            scrollbarContainerRightClass: "scrollable-scrollbar-container-right",
            scrollBarLeftClass: "scrollable-scrollbar-left",
            scrollBarRightClass: "scrollable-scrollbar-right",
            scrollBarBGClass: "scrollable-scrollbar-background"
        };

    function Plugin(element, options) {
        this.element = element;
        this.settings = jQuery.extend({}, defaults, options);
        this.init();
    }

    jQuery.extend(Plugin.prototype, {
        init: function () {
            this.addScrollbar();
            this.addEvents();
            this.onResize();
        },
        addScrollbar: function () {
            jQuery(this.element).addClass(this.settings.containerClass);
            if (this.settings.pos == 'left') {
                this.wrapper = jQuery("<div class='" + this.settings.contentLeftClass + "' />");
            } else {
                this.wrapper = jQuery("<div class='" + this.settings.contentRightClass + "' />");
            }
            
            this.wrapper.append(jQuery(this.element).contents());
            jQuery(this.element).append(this.wrapper);

            if (this.settings.pos == 'left') {
                this.scrollbarContainer = jQuery("<div class='" + this.settings.scrollbarContainerLeftClass + "' />");
                this.scrollBar = jQuery("<div class='" + this.settings.scrollBarLeftClass + "' />");
            } else {
                this.scrollbarContainer = jQuery("<div class='" + this.settings.scrollbarContainerRightClass + "' />");
                this.scrollBar = jQuery("<div class='" + this.settings.scrollBarRightClass + "' />");
            }
            
            this.scrollBarBG = jQuery("<div class='" + this.settings.scrollBarBGClass + "' />");
            this.scrollbarContainer.append(this.scrollBar);
            this.scrollbarContainer.append(this.scrollBarBG);
            jQuery(this.element).prepend(this.scrollbarContainer);
        },
        addEvents: function () {
            this.wrapper.on("scroll." + pluginName, jQuery.proxy(this.onScroll, this));
            this.scrollBar.on('mousedown.' + pluginName, jQuery.proxy(this.onMousedown, this));
            this.scrollBar.on('touchstart.' + pluginName, jQuery.proxy(this.onTouchstart, this));

            this.scrollbarContainer.on('wheel.' + pluginName, jQuery.proxy(this.onWheel, this));
        },

        onTouchstart: function (ev) {
            var me = this;

            ev.preventDefault();
            var y = me.scrollBar[0].offsetTop;

            var onMove = function (end) {
                var delta = end.touches[0].pageY - ev.touches[0].pageY;
                me.scrollBar[0].style.top = Math.min(me.scrollbarContainer[0].clientHeight - me.scrollBar[0].clientHeight, Math.max(0, y + delta)) + 'px';
                me.wrapper[0].scrollTop = (me.wrapper[0].scrollHeight * me.scrollBar[0].offsetTop / me.scrollbarContainer[0].clientHeight);
            };

            jQuery(document).on("touchmove." + pluginName, onMove);
            jQuery(document).on("touchend." + pluginName, function () {
                jQuery(document).off("touchmove." + pluginName);
                jQuery(document).off("touchend." + pluginName);
            });
        },

        onMousedown: function (ev) {
            var me = this;

            ev.preventDefault();
            var y = me.scrollBar[0].offsetTop;

            var onMove = function (end) {
                var delta = end.pageY - ev.pageY;
                me.scrollBar[0].style.top = Math.min(me.scrollbarContainer[0].clientHeight - me.scrollBar[0].clientHeight, Math.max(0, y + delta)) + 'px';
                me.wrapper[0].scrollTop = (me.wrapper[0].scrollHeight * me.scrollBar[0].offsetTop / me.scrollbarContainer[0].clientHeight);
            };

            jQuery(document).on("mousemove." + pluginName, onMove);
            jQuery(document).on("mouseup." + pluginName, function () {
                jQuery(document).off("mousemove." + pluginName);
                jQuery(document).off("mouseup." + pluginName);
            });
        },

        onResize: function () {
            this.wrapper.css("max-height", jQuery(this.element).height());
            var wrapper_client_height = this.wrapper[0].clientHeight;
            this.scrollBar.css("height", this.scrollbarContainer[0].clientHeight * wrapper_client_height / this.wrapper[0].scrollHeight + "px");
            if (this.scrollbarContainer[0].clientHeight <= this.scrollBar[0].clientHeight) {
                if (this.settings.pos == 'left') {
                    if (this.settings.jqe) {
                        this.settings.jqe.find('.leftPaneViewableItem').removeClass('leftPaneViewableItemShort');
                    }
                    jQuery(this.element).addClass(this.settings.containerNoScrollLeftClass);
                } else {
                    jQuery(this.element).find('.radialButton').removeClass('rightPaneButtonsMoved');
                    jQuery(this.element).addClass(this.settings.containerNoScrollRightClass);
                }
            } else {
                if (this.settings.pos == 'left') {
                    if (this.settings.jqe) {
                        this.settings.jqe.find('.leftPaneViewableItem').addClass('leftPaneViewableItemShort');
                    }
                    jQuery(this.element).removeClass(this.settings.containerNoScrollLeftClass);
                } else {
                    jQuery(this.element).find('.radialButton').addClass('rightPaneButtonsMoved');
                    jQuery(this.element).removeClass(this.settings.containerNoScrollRightClass);
                }
            }

            this.onScroll();
        },

        onScroll: function () {
            this.scrollBar.css("top",
                               Math.min(this.scrollbarContainer[0].clientHeight - this.scrollBar[0].clientHeight,
                                        this.scrollbarContainer[0].clientHeight * this.wrapper[0].scrollTop / this.wrapper[0].scrollHeight) + "px");
        },

        onWheel: function (ev) {
            var me = this;

            ev.preventDefault();
            var y = me.scrollBar[0].offsetTop;
            var delta = ev.originalEvent.deltaY > 0 ? 10 : -10;

            me.scrollBar[0].style.top = Math.min(me.scrollbarContainer[0].clientHeight - me.scrollBar[0].clientHeight, Math.max(0, y + delta)) + 'px';
            me.wrapper[0].scrollTop = (me.wrapper[0].scrollHeight * me.scrollBar[0].offsetTop / me.scrollbarContainer[0].clientHeight);
        }
    });

    jQuery.fn[pluginName] = function (options) {
        var plugin = new Plugin(this, options);
        jQuery.data(this, "plugin_" + pluginName, plugin);
        return plugin;
    };
})(jQuery, document);