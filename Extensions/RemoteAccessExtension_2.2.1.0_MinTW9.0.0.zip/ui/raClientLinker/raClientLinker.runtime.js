(function () {
    // Basic UUID implementation from https://stackoverflow.com/a/2117523
    var generateUUID = function () {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    };

    TW.Runtime.Widgets.raClientLinker = function () {
        this.runtimeProperties = function () {
            return {
                'needsError': true,
                'propertyAttributes': {
                    RemoteEndpoint: {
                        isLocalizable:   true
                    },
                    ThingName: {
                        isLocalizable:   true
                    },
                    ProviderConfig: {
                        isLocalizable:   true
                    },
                    SessionId: {
                        isLocalizable:   true
                    },
                    ErrorMessage: {
                        isLocalizable:   false
                    }
                }
            };
        };

        this.renderHtml = function () {

            var html =
                '<div class="widget-content" style="display:none"></div>';
            return html;
        };

        this.serviceInvoked = function (serviceName) {
            if (serviceName === 'LaunchClient') {
                var sessionId = this.getProperty('SessionId');
                if (!sessionId) {
                    this.startSession();
                } else {
                    this.launchClient();
                }
            } else {
                TW.log.error('RAClientLinker widget, unexpected serviceName invoked "' + serviceName + '"');
            }
        };

        this.startSession = function () {
            var thingName = this.getProperty('ThingName');
            var remoteEndpoint = this.getProperty('RemoteEndpoint');
            var providerConfig = this.getProperty('ProviderConfig');

            if (thingName && remoteEndpoint) {
                var thisWidget = this;
                jQuery.ajax({
                    url: '/Thingworx/Things/' + thingName + '/Services/StartSession',
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({
                        parameters: {
                            dataShape:{
                                "fieldDefinitions":{
                                    "remoteEndpoint":{
                                        "name":"remoteEndpoint",
                                        "aspects":{

                                        },
                                        "description":"name of one the RemoteEndpoints which this Thing supports",
                                        "baseType":"STRING",
                                        "ordinal":1
                                    },
                                    "providerConfig":{
                                        "name":"providerConfig",
                                        "aspects":{

                                        },
                                        "description":"Custom configuration per provider",
                                        "baseType":"JSON",
                                        "ordinal":10
                                    }
                                }
                            },
                            rows: [{
                                remoteEndpoint: remoteEndpoint,
                                providerConfig: providerConfig
                            }]
                        }
                    })
                }).done(function (data) {
                    var sessionId = data.rows[0].result;
                    thisWidget.setProperty('SessionId', sessionId);
                    thisWidget.launchClient();
                }).fail(function (err) {
                    thisWidget.setProperty('ErrorMessage', err.responseText);
                    thisWidget.jqElement.triggerHandler('ClientLaunchFailed');
                    TW.log.error('Unable to start session', err);
                });
            } else {
                TW.log.error('Thing name and remote endpoint must be provided to start session');
            }
        };

        this.launchClient = function () {
            var thisWidget = this;
            var twHost = window.location.hostname,
                twPort = window.location.port;
            var clientId = generateUUID();
            var sessionId = this.getProperty('SessionId');
            thisWidget.jqElement.triggerHandler('SessionCreated');

            jQuery.ajax({
                url: '/Thingworx/Resources/EntityServices/Services/GetClientNonce',
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({
                    appKeyName: 'tw-ra-client-nonce'
                })
            }).done(function (data) {
                var appKey = data.rows[0].result;
                // prefix nonce keys with 'N' to let RAC know
                var url = 'tw-ra-client://N' +
                    appKey + '@' + twHost + ':' + twPort + '/' + sessionId + '?clientId=' + clientId;
                var iframe = jQuery('<iframe>', {
                    src: url
                }).hide();
                thisWidget.jqElement.append(iframe);
                setTimeout(function () {
                    iframe.remove();

                    thisWidget.jqElement.triggerHandler('AwaitingLaunch');
                    jQuery.ajax({
                        url: '/Thingworx/Subsystems/RemoteAccessSubsystem/Services/AwaitClientPresence',
                        type: 'POST',
                        contentType: 'application/json',
                        dataType: 'json',
                        data: JSON.stringify({
                            clientId: clientId
                        })
                    }).done(function (data) {
                        var present = data.rows[0].result;
                        if (!present) {
                            thisWidget.jqElement.triggerHandler('ClientNotInstalled');
                        } else {
                            sessionId = null;
                            thisWidget.setProperty('SessionId', sessionId);
                            thisWidget.jqElement.triggerHandler('ClientLaunched');
                        }
                    }).fail(function (err) {
                        TW.log.error('Unable to determine if client is present', err);
                    });
                }, 100);
            }).fail(function (err) {
                thisWidget.setProperty('ErrorMessage', err.responseText);
                thisWidget.jqElement.triggerHandler('ClientLaunchFailed');
                TW.log.error('Unable to request nonce', err);
            });
        };

        this.updateProperty = function (updatePropertyInfo) {
            this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
        };
    };
}());