TW.Runtime.Widgets.queryparameterfetcher= function () {
	var thisWidget = this;
	var queryParamName;
	var queryParamValue;
	
	this.renderHtml = function () {
        var html = '';
        html = '<div class="widget-content widget-queryparameterfetcher" style="display:none;"></div>';
        return html;
	};

	this.afterRender = function () {
		//Get the query parameter name
		thisWidget.queryParamName = thisWidget.getProperty("ParamName");
		thisWidget.queryParamValue = thisWidget.getQueryParam(thisWidget.queryParamName);
		thisWidget.setProperty('ParamValue',thisWidget.queryParamValue);
		thisWidget.jqElement.triggerHandler('Changed');
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'ParamName') {
			thisWidget.queryParamName = updatePropertyInfo.SinglePropertyValue;
			thisWidget.setProperty('ParamName', updatePropertyInfo.SinglePropertyValue);
			thisWidget.queryParamValue = thisWidget.getQueryParam(thisWidget.queryParamName);
			thisWidget.setProperty('ParamValue',thisWidget.queryParamValue);
			thisWidget.jqElement.triggerHandler('Changed');
		}
	};
	
	this.getQueryParam = function(paramName){
		var urlParams;
		(window.onpopstate = function () {
		    var match,
		        pl     = /\+/g,  // Regex for replacing addition symbol with a space
		        search = /([^&=]+)=?([^&]*)/g,
		        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
		        query  = window.location.hash.substring(1);

		    urlParams = {};
		    while (match = search.exec(query))
		       urlParams[decode(match[1])] = decode(match[2]);
		})();
		return urlParams[paramName];
	};
	
    this.serviceInvoked = function(serviceName) {
        if (serviceName === 'Fetch') {
    		thisWidget.queryParamName = thisWidget.getProperty("ParamName");
    		thisWidget.queryParamValue = thisWidget.getQueryParam(thisWidget.queryParamName);
    		thisWidget.setProperty('ParamValue',thisWidget.queryParamValue);
    		thisWidget.jqElement.triggerHandler('Changed');
        } 
    };
};