TW.IDE.Widgets.queryparameterfetcher = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/RuntimeQueryParameterFetcher/ui/queryparameterfetcher/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'QueryParameterFetcher',
			'description': 'Fetches Query Parameter from the URL identified by "ParamName" input property',
			'category': ['Custom'],
			'properties': {
				'ParamName': {
					'baseType': 'STRING',
					'isBindingTarget': true
				},
				'ParamValue': {
					'baseType': 'STRING',
					'isBindingSource': true
				}
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'ParamName':
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-queryparameterfetcher">' +
					'<span class="queryparameterfetcher-property">' + 'QueryParamFetcher: Invisible at Runtime' + '</span>' +
				'</div>';
	};

	this.afterRender = function () {};
	
    this.widgetEvents = function() {
        return {
            Changed: {}
        };
    };
    
    this.widgetServices = function() {
        return {
            Fetch: {warnIfNotBound: false}
        };
    };


};