﻿/*global Encoder,TW */

var TW_timelinechartIsExtension;

(function () {

    // loader for extension libs
    if (typeof(d3) == 'undefined') {
	    $('head').append('<script>' +
                          'window.defineBackup = window.define;' +
                          'window.define = undefined;' +
                          '</script>' +
                          '<script type="text/javascript" src="../Common/extensions/TimelineChartWidget-extension/ui/timelinechart/include/d3.v3.min.js"></script>' +
                          '<script>' +
                          'window.define = window.defineBackup;' +
                          '</script>');
	}
    $('head').append('<script type="text/javascript" src="../Common/extensions/TimelineChartWidget-extension/ui/timelinechart/include/d3-timeline.js"></script>');

    var addedDefaultChartStyles = false;

    TW.Runtime.Widgets.timelinechart = function () {
        "use strict";
        var thisWidget = this,
			domElement,
            currentData,
            widgetProperties,
            widgetContainer,
			widgetElement,
			clickedMin,
			clickedMax,
            widgetContainerId,
            chart,
            purge,
			top,
			svg,
			left,
            chartData,
			svgRoot,
			tooltipDiv,
			beginningDateMillis,
			endingDateMillis,
            dataRows,
			dateFormat,
			showAM_PM,
            chartTitleStyle,
            mashupParamDataSources = false;

        thisWidget.width = thisWidget.getProperty('Width');
        thisWidget.height = thisWidget.getProperty('Height');
		thisWidget.top = thisWidget.getProperty('Top');
		thisWidget.left = thisWidget.getProperty('Left');
        thisWidget.zIndex = thisWidget.getProperty('Z-index');
        thisWidget.json = thisWidget.getProperty('JSONData');
        thisWidget.clickedMax = thisWidget.getProperty('clickedMax');
        thisWidget.clickedMin = thisWidget.getProperty('clickedMin');
        thisWidget.dateFormat = thisWidget.getProperty('dateFormat');
        thisWidget.showAM_PM = thisWidget.getProperty('showAM_PM');

        thisWidget.startLabel = TW.Runtime.convertLocalizableString(thisWidget.getProperty('startTimeLabel'));
        thisWidget.endLabel = TW.Runtime.convertLocalizableString(thisWidget.getProperty('endTimeLabel'));
		
        thisWidget.beginningDateMillis = thisWidget.getProperty('beginningDateMillis');
        thisWidget.endingDateMillis = thisWidget.getProperty('endingDateMillis');
		

        this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': false
            };
        };

        this.renderHtml = function () {
            thisWidget.id = thisWidget.getProperty('Id');
            var html =
                '<div class="widget-content widget-timelinechart" id="' + this.jqElementId + '" style=" z-index: '+thisWidget.zIndex +';" >' +
                '<div id="timeline"></div>'+
				'</div>';


            return html;
        };

        this.afterRender = function () {
			var widgetReference = this;
            widgetProperties = thisWidget.properties;
            widgetContainer = thisWidget.jqElementId;
			widgetElement = this.jqElement;
            widgetContainerId = '#' + thisWidget.jqElementId;
			domElement = this.domElement;

            var widgetSelector = widgetContainer + ' .-element';
            // add svg tag to html element required to inject chart
            // styles
            var chartTitleElement = $(widgetContainerId).find('.chart-title');
            //chartTitleElement.switchClass('textsize-normal', chartTitleTextSizeClass);
			
			widgetElement.on('clickItem', function() {
				 widgetReference.setProperty('clickedMax',thisWidget.clickedMax);
				 widgetReference.setProperty('clickedMin',thisWidget.clickedMin);
				 widgetElement.triggerHandler('clicked');
			});
			
			
            // events
            $(widgetSelector).on('focus', function () {
                //console.log("focus");
                $(widgetContainer).addClass('focus');
            });

            $(widgetSelector).on('blur', function (e) {
                //console.log("blur");
                $(widgetContainer).removeClass('focus');
            });
			
			thisWidget.jqElement.dblclick(thisWidget.dblClickHandler);
			


        };

        this.updateProperty = function (updatePropertyInfo) {
            var thisWidget = this;
            var widgetProperties = thisWidget.properties;
            var seriesNumber;
            var yAxisFieldName;
			//console.log("updateProperty: "+updatePropertyInfo.TargetProperty);

			if (updatePropertyInfo.TargetProperty === "JSONData"){
				currentData = updatePropertyInfo.RawSinglePropertyValue;
				var parseData = JSON.parse(currentData);
				thisWidget.currentData = parseData;
			}
			if (updatePropertyInfo.TargetProperty === "beginningDateMillis"){
				thisWidget.beginningDateMillis = updatePropertyInfo.SinglePropertyValue;

			} else if (updatePropertyInfo.TargetProperty === "endingDateMillis" ){
				thisWidget.endingDateMillis = updatePropertyInfo.SinglePropertyValue;
			}

            if (updatePropertyInfo.TargetProperty === "startTimeLabel"){
                thisWidget.startLabel = updatePropertyInfo.SinglePropertyValue;

            } else if (updatePropertyInfo.TargetProperty === "endTimeLabel" ){
                thisWidget.endLabel = updatePropertyInfo.SinglePropertyValue;

            } else if (updatePropertyInfo.TargetProperty === "dateFormat") {
                thisWidget.dateFormat = updatePropertyInfo.SinglePropertyValue;
            }
        };

		
		
		this.clickItem = function (current, index, datum){
					thisWidget.clickedMin = current.starting_time;
					thisWidget.clickedMax = current.ending_time;
					widgetElement.trigger("clickItem");
		}
		
		
		this.serviceInvoked = function (serviceName) {
			var widgetReference = this;
			if (serviceName === 'render') {
				if (typeof thisWidget.svg !== "undefined"){
					this.update();
				}else {
					this.render();
				}
			}

		};
		

        this.render = function () {
			//thisWidget.currentData = data;
			var data = thisWidget.currentData;
			if (typeof thisWidget.svg == "undefined"){
				thisWidget.tooltipDiv = d3.select("#runtime-workspace").append("div")
				.attr("class", "tooltip")				
				.style("opacity", 0);
			
			thisWidget.svg = d3.select(widgetContainerId).append("svg").attr("width", thisWidget.width);
			}
			
			
			thisWidget.chart = d3.timeline().mouseover(function (d, i, datum) {
					thisWidget.tooltipDiv.transition()		
					.duration(200)		
					.style("opacity", .9);			
									
			}).mouseout(function (d, i, datum) {
			
					thisWidget.tooltipDiv.transition()		
					.duration(500)		
					.style("opacity", 0);	

			}).hover(function (d, i, datum) {
					
					var start = d3.time.format('%X')(new Date(d.starting_time));
					var end = d3.time.format('%X')(new Date(d.ending_time));
					var position = thisWidget.getRelativeCoords(thisWidget.jqElement);
				thisWidget.tooltipDiv.html(d.extra + "</br>"+ thisWidget.startLabel +": "+ start + "<br/>"+ thisWidget.endLabel +": "+ end)
					.style("left", (d3.event.pageX+ 23) +  "px")
					.style("top", (d3.event.pageY - 5 ) + "px");
					
			}).click(function (d, i, datum) {
				thisWidget.clickItem(d,i,datum);

			}).height(thisWidget.height).itemHeight(thisWidget.height-50)
			.margin({left:30, right:30, top:0, bottom:20})
			.beginning(thisWidget.beginningDateMillis)
			.ending(thisWidget.endingDateMillis)
			.tickFormat({
				format: function(d) { if (thisWidget.showAM_PM === true) {thisWidget.dateFormat = "%I";}return d3.time.format(thisWidget.dateFormat)(d) },
				tickTime: d3.time.hours,
				//tickInterval: 10,
				tickSize: 5,
			});
			

			thisWidget.svg.data([data]).call(thisWidget.chart);
			
			// Show "AM" or "PM" under the time axis
			if (thisWidget.showAM_PM === true) {
				var ticks = thisWidget.svg.selectAll("g.tick").filter(function(d, i) {return d.getHours() === 0 || d.getHours() === 12});
				ticks.each(function insertAM_PM(d, i) {
					var selection = d3.select(this).select("text");
					var attr = selection.node().attributes;
				    var length = attr.length;
				    var node_name = selection.property("nodeName");
				    var parent = d3.select(selection.node().parentNode);
				    var cloned = parent.append(node_name);
				    for (var j = 0; j < length; j++) {
				    	if (attr[j].name === "y") {
				    		cloned.attr(attr[j].name,parseInt(attr[j].value) + 10);
				    	} else {
				    		cloned.attr(attr[j].name,attr[j].value);
				    	}
				    }
				    if (d.getHours() === 0) {
				    	cloned.text("AM");
				    } else if (d.getHours() === 12) {
				    	cloned.text("PM");
				    }
				});
			}
        };

        this.update = function (){
			thisWidget.svg.selectAll("g").remove();
            this.render();
        };

        this.dblClickHandler = function(){
			widgetElement.triggerHandler('DoubleClicked');
        };




        //Format function for the tooltip values column
        this.valueFormatter = function(d,i) {
            return d;
        };

        //Format function for the tooltip header value.
        this.headerFormatter = function(d) {
            return d;
        };

        this.keyFormatter = function(d, i) {
            return d;
        };

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.button.beforeDestroy', err);
            }
        };
		
		this.getRelativeCoords = function (elem) {
			var box = elem[0].getBoundingClientRect();

			var body = document.body;
			var docEl = document.documentElement;

			var scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop;
			var scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft;

			var clientTop = docEl.clientTop || body.clientTop || 0;
			var clientLeft = docEl.clientLeft || body.clientLeft || 0;

			var top  = box.top +  scrollTop - clientTop;
			var left = box.left + scrollLeft - clientLeft;

			return { top: Math.round(top), left: Math.round(left) };
		}

    };
}());
