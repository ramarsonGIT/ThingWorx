﻿/*global Encoder,TW */

TW.IDE.Widgets.timelinechart = function () {

    "use strict";
    // max could be much higher
    this.isResponsive = false;
    var widgetContainerId;
    this.widgetIconUrl = function () {
        return  "../Common/extensions/TimelineChartWidget-extension/ui/timelinechart/images/timelinechart.ide.png";
    };

    this.widgetProperties = function () {
        var properties = {
            'name': 'Timeline Chart',
            'description': 'Displays a timeline using the d3-timeline JavaScript library',
            'category': ['Data', 'Charts'],
			'dataSourceProperty': 'JSONData',
            'supportsLabel': false,
	        'supportsAutoResize': false,
            'borderWidth': 1,
            'defaultBindingTargetProperty': 'JSONData',
            'properties': {               
                'JSONData': {
                    'description': 'Data source',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'warnIfNotBoundAsTarget': false
                },
                'Width': {
                    'defaultValue': 640
                },
                'Height': {
                    'defaultValue': 240
                },
                'Z-index': {
                    'baseType': 'NUMBER',
                    'defaultValue': 10
                },
                'clickedMax': {
                    'baseType': 'NUMBER',
					'isBindingSource': true,
					'defaultValue' : 0
                },
                'clickedMin': {
                    'baseType': 'NUMBER',
					'isBindingSource': true,
					'defaultValue' : 0
                },
                'beginningDateMillis': {
                    'baseType': 'NUMBER',
					'isBindingTarget': true,
					'defaultValue' : 0
                },
                'endingDateMillis': {
                    'baseType': 'NUMBER',
					'isBindingTarget': true,
					'defaultValue' : 0
                },
                'showAM_PM': {
                    'baseType': 'BOOLEAN',
					'isBindingTarget': true,
					'defaultValue' : false
                },
                'dateFormat': {
                    'baseType': 'STRING',
					'isBindingTarget': true,
					'defaultValue' : '%H:%M'
                },
                'startTimeLabel': {
                    'description': 'Start Time',
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': 'Start Time',
                    'isVisible': true,
                    'isLocalizable': true
                },
                'endTimeLabel': {
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'isLocalizable': true,
                    'defaultValue': 'End Time'
                }
            }
        };
     
        return properties;
    };

    this.widgetEvents = function () {
        return {
		 'DoubleClicked': {},
         'clicked': {}
        };
		
		
    };
	
	this.widgetServices = function() {
        return {
            'render': { 'warnIfNotBound': false }
        }
    }
	

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-timelinechart">'
             +  '<table height="100%" width="100%"><tr><td valign="middle" align="center">'
             +  '<span>Timeline Chart</span>'
             +  '</td></tr></table></div>';
        return html;
    };

    this.afterRender = function () {
        // this property can't be hidden in setProperties because ResponsiveLayout is still undefined in most cases
        widgetContainerId = '#' + this.jqElementId;
        // if this is in a inactive tab or similar we must prevent rendering until tab gets clicked
        if(this.properties.ResponsiveLayout){
            this.isResponsive = true;
        }
        if(this.isResponsive && $(widgetContainerId).closest('.widget-panel')) {
            this.isResponsive = false;

        }
            this.updatedProperties();
    };

    this.afterLoad = function () {
    };

    this.afterSetProperty = function (name, value) {
      var result = false;
      switch (name) {
         case 'clickedMax':
         case 'clickedMin':
            result = true;
            break;
      }
	  console.log(" after Set property");
      return result;
    };
    
    this.beforeSetProperty = function (name, value) {
    };

    
};
