﻿TW.IDE.Widgets.textboxValidate = function () {
    var thisWidget = this;

    this.widgetIconUrl = function () {
        return  "../Common/thingworx/widgets/textbox/textbox.ide.png";
    };

    function setToolTips(widget) {
        var tooltipPosition = widget.getProperty('ToolTipPosition').split(",");
        var toolTipDuration = widget.getProperty('ToolTipDuration') * 1000;
        $("#TT_" + widget.jqElementId).qtip({
            style: {
                classes: widget.getProperty('ToolTipStyles'),
                def: false
            },
            position: {
                my: tooltipPosition[0],
                at: tooltipPosition[1]
            },
            show: {
                solo: true
            },
            hide: {
                inactive: toolTipDuration
            }
        });
    }

    this.widgetProperties = function () {
        return {
            'name': 'Textboxvalidate',
            'description': 'Enables the user to enter text',
            'category': ['Common'],
            'dataSourceProperty': 'Text',
            'defaultBindingTargetProperty': 'Text',
            'supportsLabel': true,
            'supportsResetInputToDefault': true,
            'properties': {
                'Text': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING',
                    'warnIfNotBoundAsSource': false
                },
                'ToolTip': {
                    'description': 'describes what button does',
                    'defaultValue': 'Input Text',
                    'baseType': 'STRING',
                    'isLocalizable': true,
                    'isBindingTarget': true
                },
                'ToolTipStyles': {
                    'description': 'changes appearance of ToolTips',
                    'defaultValue': '.qtip-shadow',
                    'baseType': 'STRING',
                    'selectOptions': [
                        {value: 'qtip-tipsy', text: 'Black'},
                        {value: 'qtip-jtools', text: 'Black, White Border'},
                        {value: 'qtip-blue', text: 'Blue'},
                        {value: 'qtip-bootstrap', text: 'Bootstrap'},
                        {value: 'qtip-cluetip', text: 'Light Gray'},
                        {value: 'qtip-dark', text: 'Dark Gray'},
                        {value: 'qtip-tipped', text: 'Gray Border'},
                        {value: 'qtip-green', text: 'Green'},
                        {value: 'qtip-red', text: 'Red'},
                        {value: 'qtip-shadow', text: 'Shadow'},
                        {value: 'qtip-light', text: 'White'},
                        {value: 'qtip-cream', text: 'Yellow'}
                    ]
                },
                'ToolTipPosition': {
                    'description': 'where ToolTip appears',
                    'defaultValue': '"bottom left","top right"',
                    'baseType': 'STRING',
                    'selectOptions': [
                        {value: ["top left", "bottom right"], text: 'Lower Right'},
                        {value: ["bottom right", "top left"], text: 'Upper Left'},
                        {value: ["top right", "bottom left"], text: 'Lower Left'},
                        {value: ["bottom left", "top right"], text: 'Upper Right'}
                    ]
                },
                'ToolTipDuration': {
                    'description': 'Display Duration in Seconds',
                    'baseType': 'NUMBER',
                    'defaultValue': 2
                },
                'MaxChars': {
                    'defaultValue': 0,
                    'baseType': 'NUMBER'
                },
                'ValidationHinting': {
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'ValidationHint': {
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'Width': {
                    'defaultValue': 200
                },
                'Height': {
                    'defaultValue': 24,
                    'isEditable': true
                },
                'TextAlign': {
                    'defaultValue': 'left',
                    'baseType': 'STRING',
                    'description': 'The positioning of the text.',
                    'selectOptions': [
									  { value: 'left', text: 'Left' },
                	                  { value: 'right', text: 'Right' },
                	                  { value: 'center', text: 'Center' }
                	                  ]
                },
                'LabelAlignment': {
                    'baseType': 'STRING',
                    'defaultValue': 'left',
                    'selectOptions': [
                        { value: 'left', text: 'Left' },
                        { value: 'right', text: 'Right' },
                        { value: 'center', text: 'Center' }
                    ]
                },
                'PlaceholderText': {
                    'defaultValue': '',
                    'baseType': 'STRING',
                    'description': 'Textbox placeholder text. Not supported in IE9 and earlier versions.'
                },
                'ReadOnly': {
                    'description': 'Is the textbox read only',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'MaskInputCharacters': {
                    'description': 'Do not show contents of entry at runtime',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'TabSequence': {
                    'description': 'Tab sequence index',
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'CursorPosition': {
                    'isBindingSource': true,
                    'defaultValue': 0,
                    'baseType': 'NUMBER'
                },
                'isValid': {
                    'defaultValue': true,
                    'baseType': 'BOOLEAN',
                    'isBindingTarget': true
                },
                'Style': {
                    'baseType': 'STYLEDEFINITION',
					'defaultValue' : 'DefaultTextBoxStyle'
                },
                'InvalidInputStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'InvalidTextBoxStyle'
                },
                'ValidInputStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'ValidTextBoxStyle'
                },
				'TextboxLabelStyle': {
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultWidgetLabelStyle'
                },
				'DefaultTextboxFocusStyle': {
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultFocusStyle'
                }
				
            }
        };
    };

    this.renderHtml = function () {
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));
        var textSizeClass = 'textsize-normal';
		var textAlignClass = this.getProperty('TextAlign');
        if (this.getProperty('Style') !== undefined) {
            textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
        }
        var cssInfo = TW.getStyleCssTextualFromStyle(formatResult);
		var cssTextBoxText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
		var TextboxStyleBorder = TW.getStyleCssBorderFromStyle(formatResult);
        
        var html = '';
        html += 
            '<div class="widget-content widget-textbox '+ textAlignClass + '">' +
                '<div class="widget-textbox-wrapper" style="' + TextboxStyleBorder + '" title = "'
                + (this.getProperty('ToolTip') === undefined ? 'Navigate' :
                Encoder.htmlEncode(this.getProperty('ToolTip'))) + '">' +
                    '<span class="widget-textbox-text-icon"></span>' +
                    '<table ' + (thisWidget.getProperty('InnerShadow') === false ? '' : 'class="shadow"') + ' border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="'+ cssInfo +'" +>' +
                        '<tr><td valign="middle">' +
                            '<span class="widget-textbox-text ' + textSizeClass + '" style="' + cssTextBoxText +'">' + ((this.getProperty('Text') === undefined) ? 'Textbox' : Encoder.htmlEncode(this.getProperty('Text'))) + '</span>' +
                        '</td></tr>' +
                    '</table>' +
                '</div>' +
            '</div>';
        return html;
    };
	
	this.afterRender = function () {

        $('#' + thisWidget.jqElementId).find('.widget-textbox-wrapper').attr('id', 'TT_' + this.jqElementId);
		var TextboxLabelStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TextboxLabelStyle'));
		var TextboxLabel = TW.getStyleCssTextualNoBackgroundFromStyle(TextboxLabelStyle);
        var TextboxLabelSize = TW.getTextSize(TextboxLabelStyle.textSize);
        var TextboxLabelAlignment = this.getProperty('LabelAlignment', 'left');

		var TextboxHeight = this.getProperty('Height');

		var resource = TW.IDE.getMashupResource();
		var widgetStyles = '#' + thisWidget.jqElementId + '-bounding-box .builder-widget-label { '+ TextboxLabel + TextboxLabelSize + ' text-align: ' + TextboxLabelAlignment + '; }' +
            '#' + thisWidget.jqElementId + ' .widget-textbox-wrapper { height: ' + TextboxHeight + 'px; }';
		resource.styles.append(widgetStyles);
        
        window.setTimeout(setToolTips(this), 1000);
        
    };
	
    this.widgetEvents = function () {
        return {
            'Changed': {}
        }
    };

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'ToolTip':
            case 'ToolTipStyles':
            case 'ToolTipPosition':
            case 'ToolTipDuration':
            case 'MinMaxHinting':
            case 'Style':
            case 'ValidStyle':
            case 'InvalidStyle':
			case 'TextAlign':
			case 'TextboxLabelStyle':
			case 'isValid':
            case 'InnerShadow':
            case 'LabelAlignment':
                result = true;
                break;
            case 'Text':
                thisWidget.jqElement.find('.widget-textbox-text').text(value);
                break;
            default:
                break;
        }
        return result;

    };

    this.validate = function () {
        var result = [];
        var isReadOnly = this.getProperty('ReadOnly');
        if( isReadOnly !== true )  {
            if (!this.isPropertyBoundAsSource('Text')) {
                result.push({ severity: 'warning', message: '{target-id}: Text is not bound to any target.  If you check ReadOnly you will not receive this warning.' });
            }
        }
        return result;
    }


};