(function () {

    // ensure validation only occurs on button click event and not other property change events
    var clickCheck;
    var addedDefaultStyles = false;
    var border;
    var isValidationMode = false;
    var cssTextboxFocusBorder;
    var validBorder;
    var background;
    var validBackground;
    var invalidBorder;
    var invalidBackground;
    var internalPath = "../Common/extensions/textboxValidate_ExtensionPackage/ui/textboxValidate/";

    function setToolTips(widget) {
        var tooltipPosition = widget.getProperty('ToolTipPosition').split(",");
        var toolTipDuration = widget.getProperty('ToolTipDuration') * 1000;
        $("#" + widget.jqElementId).qtip({
            style: {
                classes: widget.getProperty('ToolTipStyles'),
                def: false
            },
            position: {
                my: tooltipPosition[0],
                at: tooltipPosition[1]
            },
            show: {
                solo: true
            },
            hide: {
                inactive: toolTipDuration
            }
        });
    }

    TW.Runtime.Widgets.textboxValidate = function () {
        var thisWidget = this;
        var defaultValue = undefined;
        var onInputChange = function () {
            thisWidget.setProperty('Text', thisWidget.jqElement.find('input').val());
            // fire my bindable event so listeners know something happened
            thisWidget.jqElement.triggerHandler('Changed');
        };

        this.runtimeProperties = function () {
            return {
                'needsError': true,
                'propertyAttributes': {
                    'ToolTip': {
                        'isLocalizable': true
                    },
                    'ValidationHint': {
                        'isLocalizable': true
                    }
                }
            };
        };

        this.renderHtml = function () {
            defaultValue = thisWidget.getProperty('Text');
            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'DefaultTextBoxStyle'));
            border = TW.getStyleCssBorderFromStyle(formatResult);

            var textSizeClass = 'textsize-normal ';
            var textAlignClass = thisWidget.getProperty('TextAlign');
            if (thisWidget.getProperty('Style') !== undefined) {
                textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
            }
            var cssInfo = TW.getStyleCssTextualFromStyle(formatResult);
            var cssTextBoxText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);

            var inputType = 'text';
            if (this.getProperty('MaskInputCharacters') === true) {
                inputType = 'password';
            }

            //not in scope for SFW: replace maxchars with pattern to include a minChars equivalent method
            /*    if (this.getProperty('MaxChars')>0) {
             pattern = ' required pattern=".{,'+this.getProperty('MaxChars')+'}" title="'+this.getProperty('MaxChars')+' characters maximum" ';
             }

             if (this.getProperty('MinChars') > 0) {
             pattern = ' required pattern=".{' + this.getProperty('MinChars') + ',}" title="' + this.getProperty('MinChars') + ' characters minimum" ';
             }
             if (this.getProperty('MinChars') > 0 && this.getProperty('MaxChars') > 0) {
             pattern = ' required pattern=".{' + this.getProperty('MinChars') + ','+this.getProperty('MaxChars')+'}"title="Enter between ' + this.getProperty('MinChars')+' and '+this.getProperty('MaxChars')+' characters." ';
             }
             */
            var pattern = ' maxlength="' + this.getProperty('MaxChars') + '"';
            var placeholderText = window.XSS.encodeHTML(thisWidget.getProperty('PlaceholderText'));

            var html =
                '<div class="widget-content widget-textbox" ' +
                'title="' + (this.getProperty('ToolTip') === undefined ? 'Input Text' :
                Encoder.htmlEncode(this.getProperty('ToolTip'))) + '">' +
                '<table class="shadow inputTable" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="' + cssInfo + '">' +
                '<tr><td valign="middle">' +
                '<input' + pattern + 'type="' + inputType + '" class="widget-textbox-box ' + textSizeClass + ' ' + textAlignClass + '" tabindex="' + thisWidget.getProperty('TabSequence') + '" style="' + cssTextBoxText + '" ' + (thisWidget.getProperty('ReadOnly') === true ?
                'disabled="disabled" ' : '') + ' value="' + (thisWidget.getProperty('Text') === undefined ? '' :
                thisWidget.getProperty('Text').replace(/"/g, "&quot;")) + '" placeholder="' + (placeholderText === undefined ?
                '' : placeholderText) + '">' +
                '</input>' +
                '</td></tr>' +
                '</table>' +
                '</div>';
            return html;
        };

        this.afterRender = function () {
            // notice when "text" changes and update the 'Text' property
            var TextboxLabelStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TextboxLabelStyle', 'DefaultWidgetLabelStyle'));
            var textboxFocusStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('DefaultTextboxFocusStyle', 'DefaultFocusStyle'));

            var TextboxLabel = TW.getStyleCssTextualNoBackgroundFromStyle(TextboxLabelStyle);
            var TextboxLabelSize = TW.getTextSize(TextboxLabelStyle.textSize);
            var TextboxLabelAlignment = this.getProperty('LabelAlignment', 'left');

            cssTextboxFocusBorder = TW.getStyleCssBorderFromStyle(textboxFocusStyle);
            var TextboxHeight = thisWidget.getProperty('Height');

            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'DefaultTextBoxStyle'));
            border = TW.getStyleCssBorderFromStyle(formatResult);
            background = TW.getStyleCssGradientFromStyle(formatResult);
            var validFormatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ValidInputStyle', 'DefaultTextBoxStyle'));
            validBorder = TW.getStyleCssBorderFromStyle(validFormatResult);
            validBackground = TW.getStyleCssGradientFromStyle(validFormatResult);
            var invalidFormatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('InvalidInputStyle', 'DefaultTextBoxStyle'));
            invalidBorder = TW.getStyleCssBorderFromStyle(invalidFormatResult);
            invalidBackground = TW.getStyleCssGradientFromStyle(invalidFormatResult);

            if (thisWidget.getProperty('TextboxLabelStyle', 'DefaultWidgetLabelStyle') === 'DefaultWidgetLabelStyle'
                && thisWidget.getProperty('DefaultTextboxFocusStyle', 'DefaultFocusStyle') === 'DefaultFocusStyle') {
                if (!addedDefaultStyles) {
                    addedDefaultStyles = true;
                    var defaultStyles = ' .runtime-widget-label { ' + TextboxLabel + TextboxLabelSize + ' text-align: ' + TextboxLabelAlignment + '; }' +
                        ' .widget-textbox table { ' + border + ' }' +
                        ' .widget-textbox.focus table { ' + cssTextboxFocusBorder + ' }' +
                        ' .widget-textbox-box { height: ' + TextboxHeight + 'px; }';
                    $.rule(defaultStyles).appendTo(TW.Runtime.globalWidgetStyleEl);
                }
            }
            else {
                var styleBlock =
                    '<style>' +
                    '#' + thisWidget.jqElementId + ' { ' + TextboxLabel + ' }' +
                    '#' + thisWidget.jqElementId + '-bounding-box .runtime-widget-label { ' + TextboxLabel + TextboxLabelSize + ' text-align: ' + TextboxLabelAlignment + '; }' +
                    '#' + thisWidget.jqElementId + ' table { ' + border + ' }' +
                    '#' + thisWidget.jqElementId + '.focus table { ' + cssTextboxFocusBorder + ' }' +
                    '</style>';

                $(styleBlock).prependTo(thisWidget.jqElement);
            }

            var textboxSelector = '#' + thisWidget.jqElementId + ' .widget-textbox-box';
            var textboxContainer = '#' + thisWidget.jqElementId + '.widget-textbox';

            $(textboxSelector).on('focus', function () {
                //$(textboxContainer).addClass('focus');
                thisWidget.setFocusStyle();
            });


            var inBlurHandlingInIe8 = false;
            $(textboxSelector).on('blur', function (e) {
                //$(textboxContainer).removeClass('focus');
                thisWidget.setBlurStyle();
                try {
                    if (e.target.selectionStart !== undefined) {
                        thisWidget.setProperty('CursorPosition', e.target.selectionStart);
                    }
                    else {
                        // ie8
                        if (inBlurHandlingInIe8) {
                            return;
                        }
                        inBlurHandlingInIe8 = true;
                        e.target.focus();
                        var el = e.target;
                        var range = document.selection.createRange();

                        if (range && range.parentElement() == el) {
                            var len = el.value.length;
                            var normalizedValue = el.value.replace(/\r\n/g, "\n");

                            // Create a working TextRange that lives only in the input
                            var textInputRange = el.createTextRange();
                            textInputRange.moveToBookmark(range.getBookmark());

                            // Check if the start and end of the selection are at the very end
                            // of the input, since moveStart/moveEnd doesn't return what we want
                            // in those cases
                            var endRange = el.createTextRange();
                            endRange.collapse(false);

                            var start, end;
                            if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
                                start = end = len;
                            }
                            else {
                                start = -textInputRange.moveStart("character", -len);
                                start += normalizedValue.slice(0, start).split("\n").length - 1;

                                if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
                                    end = len;
                                }
                                else {
                                    end = -textInputRange.moveEnd("character", -len);
                                    end += normalizedValue.slice(0, end).split("\n").length - 1;
                                }
                            }
                            thisWidget.setProperty('CursorPosition', start);
                        }
                        e.target.blur();
                        setTimeout(function () {
                            // keep ie8 from infinite loop
                            inBlurHandlingInIe8 = false;
                        }, 1);
                    }
                }
                catch (err) {
                    TW.log.error('error trying to get cursor position on blur', err);
                }
            });
            window.setTimeout(setToolTips(thisWidget), 1000);
            thisWidget.jqElement.find('input').on('change', onInputChange);
        };

        this.updateProperty = function (updatePropertyInfo) {
            var widgetReference = this;
            var widgetElement = this.jqElement;

            if (updatePropertyInfo.TargetProperty === 'Text') {
                thisWidget.jqElement.find('input').val(updatePropertyInfo.SinglePropertyValue);
                thisWidget.setProperty('Text', updatePropertyInfo.SinglePropertyValue);
            }
            else if (updatePropertyInfo.TargetProperty === 'ToolTip') {
                widgetElement.qtip('destroy');
                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                widgetElement.attr("title", widgetReference.getProperty('ToolTip'));
                window.setTimeout(setToolTips(widgetReference), 500);
            }
            // set ValidStyle to
            else if (updatePropertyInfo.TargetProperty === 'isValid' && this.clickCheck === "defined") {
                this.isValidationMode = true;
                if (updatePropertyInfo.SinglePropertyValue === "true") {
                    this.resetStyle(validBorder, validBackground, "green");
                }
                else {
                    this.resetStyle(invalidBorder, invalidBackground, "red");
                }
            }
            else {
                this.clickCheck = "defined";
            }
        };

        this.resetStyle = function (border, background, color) {
            var widgetReference = this;
            var widgetElement = this.jqElement;
            var borderColor = border.substr((border.indexOf("border-color:") + 13), 7);
            var borderWidth = border.substr((border.indexOf("border-width:") + 13), 3);
            var backgroundColor = background.substr((border.indexOf("background-color:") + 13), 7);
            var qtipStyle = "qtip-" + color;

            widgetElement.find('.inputTable').css("border-color", borderColor);
            widgetElement.find('.inputTable').css("border-width", borderWidth);
            widgetElement.find('.inputTable').css("background-color", backgroundColor);
            widgetElement.find('.inputTable').css("background-size", "18px,18px");
            // set the icon in the field (would use icon in style but no accessor property is offered)
            //widgetElement.find('.inputTable').css('background-image', 'url('+iconUrl+')');
            //widgetElement.find('.inputTable').css('background-repeat', 'no-repeat');
            //widgetElement.find('.inputTable').css('background-position', 'right');

            if (widgetReference.getProperty('ValidationHinting')) {
                // required field hint
                widgetElement.qtip('destroy');
                var toolTip = widgetReference.getProperty('ToolTip') + "  " + Encoder.htmlEncode(widgetReference.getProperty('ValidationHint'));
                widgetElement.attr("title", toolTip);
                window.setTimeout(setToolTips(widgetReference), 500);
            }

            widgetElement.qtip({
                style: {
                    classes: qtipStyle,
                    def: false
                },
                show: {
                    solo: false
                }
            });
        };

        this.resetInputToDefault = function () {
            var widgetReference = this;
            var widgetElement = this.jqElement;
            thisWidget.jqElement.find('input').val(defaultValue === undefined ? '' : defaultValue);
            thisWidget.setProperty('Text', defaultValue);
            //reset validation style to none
            this.resetStyle(border, background, "reset");
            widgetElement.qtip('destroy');
            widgetElement.attr("title", widgetReference.getProperty('ToolTip'));
            window.setTimeout(setToolTips(widgetReference), 500);
            this.isValidationMode = false;
        };

        this.setFocusStyle = function () {
            var widgetElement = this.jqElement;
            // if widget is not displaying validation styling, apply the focus border style
            if (!this.isValidationMode) {
                var borderColor = cssTextboxFocusBorder.substr((cssTextboxFocusBorder.indexOf("border-color:") + 13), 7);
                widgetElement.find('.inputTable').css("border-color", borderColor);
            }
        };

        this.setBlurStyle = function () {
            var widgetElement = this.jqElement;
            if (!this.isValidationMode) {
                var borderColor = border.substr((border.indexOf("border-color:") + 13), 7);
                widgetElement.find('.inputTable').css("border-color", borderColor);
            }
        };

        this.getProperty_Text = function () {
            if (thisWidget.jqElement !== undefined) {
                return thisWidget.jqElement.find('input').val();
            }
            else {
                return this.properties['Text'];
            }
        };

        this.beforeDestroy = function () {
            thisWidget.jqElement.find('input').off();
        };
    };
}());