(function () {

    TW.IDE.Dialogs["converge-accordion-menu-editor"] = function () {

        this.title = "Menu Data to Mashup Params";
        this.jqElementId = null;

        this.renderDialogHtml = function (widgetObj) {
            var existingParamDefs = widgetObj.properties['_DataToParamMappings'] || [];
            if (existingParamDefs.length === 0) {
                existingParamDefs.push({menuDataField: '', mashupParam: ''});
            }
            var html = '<div id="mapping-table">'
                    + '<div class="add-parameter-btn toolbar">'
                    + '<button class="btn btn-inverse converge-accordion-menu-editor-add">Add Mapping</button>'
                    + '</div>'
                    + '<table class="table table-striped table-bordered" id="converge-accordion-menu-editor-table">'
                    + '<thead><tr>'
                    + '<th align="left" width="216">Menu Data Field</th>'
                    + '<th align="left" width="216">Mashup Parameter (optional if same as menu data field)</th>'
                    + '<th align="left" width="33">Delete</th>'
                    + '</tr></thead>';
            +'<tbody>';
            for (var i = 0, l = existingParamDefs.length; i < l; i++) {
                html += this.genMappingRowHtml(existingParamDefs[i]);
            }
            html += '</tbody></table></div>';
            return html;
        };

        this.genMappingRowHtml = function (rowInfo) {
            rowInfo = rowInfo || {menuDataField: '', mashupParam: ''};
            return '<tr>'
                    + '<td><input class="converge-accordion-menu-editor-field" type="text" value="' + rowInfo['menuDataField'] + '" /></td>'
                    + '<td><input class="converge-accordion-menu-editor-param" type="text" value="' + rowInfo['mashupParam'] + '" /></td>'
                    + '<td><span class="converge-accordion-menu-editor-delete"><i class="remove-user icon-remove"></i></span></td>'
                    + '</tr>';
        };

        this.afterRender = function (domElementId) {
            this.jqElementId = domElementId;
            var jqElement = $('#' + this.jqElementId);
            var editor = this;
            jqElement.find('.converge-accordion-menu-editor-add').on('click', function (e) {
                e.stopPropagation();
                jqElement.find('tbody').append(editor.genMappingRowHtml());
            });
            jqElement.find('#mapping-table').on('click', '.converge-accordion-menu-editor-delete', function (e) {
                e.stopPropagation();
                $.confirm({
                    'title': 'Delete Confirmation',
                    'message': 'Delete this Mapping?',
                    'buttons': {
                        'Yes': {
                            'class': 'blue',
                            'action': function () {
                                $(e.target).closest('tr').remove();
                            }
                        },
                        'No': {
                            'class': 'gray',
                            'action': function () {
                            }
                        }
                    }
                });
            });
        };

        this.updateProperties = function (widgetObj) {
            var mappings = [];
            var errors = false;
            $('#' + this.jqElementId).find('tbody tr').each(function () {
                var el = $(this),
                    fieldEl = el.find('.converge-accordion-menu-editor-field'),
                    paramEl = el.find('.converge-accordion-menu-editor-param'),
                    fieldVal = $.trim(fieldEl.val() || ''),
                    paramVal = $.trim(paramEl.val() || '');
                if (fieldVal.length > 0) {
                    if (!TW.isValidParameterName(fieldVal)) {
                        errors = true;
                        fieldEl.focus();
                        alert('The Menu Data Field cannot start with a number and can contain only alpha-numeric characters and underscores');
                        return false;
                    }
                    if (paramVal.length > 0 && !TW.isValidParameterName(paramVal)) {
                        errors = true;
                        paramEl.focus();
                        alert('The Mashup Parameter cannot start with a number and can contain only alpha-numeric characters and underscores');
                        return false;
                    }
                    mappings.push({menuDataField: fieldVal, mashupParam: paramVal});
                }
            });
            if (errors) {
                return false;
            }
            widgetObj.setProperty('_DataToParamMappings', mappings);
            return true;
        };

        this.beforeDestroy = function () {
            $('#' + this.jqElementId).find('#mapping-table').empty();
        };
    };

}());

