/*global TW */

(function () {
    var addedDefaultStyles = false;

    TW.Runtime.Widgets.websockettunnel = function () {

        this.runtimeProperties = function () {
            return {
                propertyAttributes: {
                    Label: {
                        isLocalizable: true
                    },
                    ConnectLabel: {
                        isLocalizable: true
                    },
                    DisconnectLabel: {
                        isLocalizable: true
                    },
                    InterruptLabel: {
                        isLocalizable: true
                    }
                }
            };
        };

        /**
         * NO TUNNELNAME VALIDATION EVER OCCURS. Checks that it's set, but not that it's accurate.
         *
         * ASSUMES USER HAS ACCESS TO READ TUNNELINGISENABLED PROPERTY FOR DEVICEPROXY THING BOUND/ENTERED IN DEVICENAME PROPERTY.
         * WILL FAIL GRACEFULLY IF NOT
         *
         */

        var cssInfo;
        var cssButtonBackground;
        var cssButtonBorder;
        var cssButtonHoverText;
        var cssButtonHoverBackground;
        var cssButtonHoverBorder;
        var cssButtonActiveText;
        var cssButtonActiveBackground;
        var cssButtonActiveBorder;
        var cssButtonFocusBorder;

        var widgetReference = this;
        var roundedCorners = true;
        var cornerRadius = '0';
        var thisWidget = this;
        var connectedThing = true;

        var tunnelingEnabled = false;
        var subSystemEnabled = false;
        var tunnelingURL = 'Thingworx\/WSTunnelClient\/';

        // check browser compatibility. Only IE10, Chrome and Firefox work
        var isBrowserCompatible = function () {
            var result = false;
            if (!TW.Environment.Browser.isIE) {
                result = true;
            } else {
                if (TW.Environment.queryIEMode() === "IE10") {
                    result = true;
                }
            }

            return result;
        };

        this.renderHtml = function () {
            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'DefaultButtonStyle'));
            var textSizeClass = 'textsize-normal';

            if (this.getProperty('Style') !== undefined) {
                textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
            }

            var html =
                '<div class="widget-content widget-websockettunnel">' +
                    '<button class="websockettunnel-element" tabindex="' + thisWidget.getProperty('TabSequence') + '">' +
                        ((formatResult.image !== undefined && formatResult.image.length > 0) ? '<img src="' + formatResult.image + '"/>' : '') +
                        '<span class="widget-websockettunnel-text ' + textSizeClass + '">' +
                        (thisWidget.getProperty('Label') === undefined ? 'Remote Device' : Encoder.htmlEncode(thisWidget.getProperty('Label'))) +
                        '</span>' +
                    '</button>' +
                '</div>';
            return html;
        };

        this.afterRender = function () {
            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'DefaultButtonStyle'));
            var buttonHoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle', 'DefaultButtonHoverStyle'));
            var buttonActiveStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ActiveStyle', 'DefaultButtonActiveStyle'));
            var buttonFocusStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('FocusStyle', 'DefaultButtonFocusStyle'));

            cssInfo = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
            cssButtonBackground = TW.getStyleCssGradientFromStyle(formatResult);
            cssButtonBorder = TW.getStyleCssBorderFromStyle(formatResult);
            cssButtonHoverText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonHoverStyle);
            cssButtonHoverBackground = TW.getStyleCssGradientFromStyle(buttonHoverStyle);
            cssButtonHoverBorder = TW.getStyleCssBorderFromStyle(buttonHoverStyle);
            cssButtonActiveText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonActiveStyle);
            cssButtonActiveBackground = TW.getStyleCssGradientFromStyle(buttonActiveStyle);
            cssButtonActiveBorder = TW.getStyleCssBorderFromStyle(buttonActiveStyle);
            cssButtonFocusBorder = TW.getStyleCssBorderFromStyle(buttonFocusStyle);

            roundedCorners = this.getProperty('RoundedCorners', true);

            if (roundedCorners) {
                cornerRadius = '6';
            }

            if (thisWidget.getProperty('Style', 'DefaultButtonStyle') === 'DefaultButtonStyle' &&
                thisWidget.getProperty('HoverStyle', 'DefaultButtonHoverStyle') === 'DefaultButtonHoverStyle' &&
                thisWidget.getProperty('ActiveStyle', 'DefaultButtonActiveStyle') === 'DefaultButtonActiveStyle' &&
                thisWidget.getProperty('FocusStyle', 'DefaultButtonFocusStyle') === 'DefaultButtonFocusStyle') {
                if (!addedDefaultStyles) {
                    addedDefaultStyles = true;
                    var defaultStyles = ' .widget-websockettunnel .websockettunnel-element { ' + cssButtonBackground + cssButtonBorder + ' border-radius:' + cornerRadius + 'px; }' +
                        ' .widget-websockettunnel-disabled .websockettunnel-element { ' + cssButtonBorder + ' border-radius:' + cornerRadius + 'px; }' +
                        ' .widget-websockettunnel .websockettunnel-element:hover { ' + cssButtonHoverBackground + ' }' +
                        ' .widget-websockettunnel .websockettunnel-element:active { ' + cssButtonActiveBackground + ' }' +
                        ' .widget-websockettunnel .websockettunnel-element .widget-websockettunnel-text { ' + cssInfo + ' }' +
                        ' .widget-websockettunnel .websockettunnel-element:active .widget-websockettunnel-text { ' + cssButtonActiveText + ' }' +
                        ' .widget-websockettunnel .websockettunnel-element:hover .widget-websockettunnel-text { ' + cssButtonHoverText + ' }' +
                        ' .widget-websockettunnel .websockettunnel-element:focus { ' + cssButtonFocusBorder + ' }';
                    $.rule(defaultStyles).appendTo(TW.Runtime.globalWidgetStyleEl);
                }
            } else {
                var styleBlock =
                    '<style>' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element { ' + cssButtonBackground + cssButtonBorder + ' border-radius:' + cornerRadius + 'px; }' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel-disabled .websockettunnel-element { ' + cssButtonBorder + ' border-radius:' + cornerRadius + 'px; }' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element:hover { ' + cssButtonHoverBackground + ' }' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element:active { ' + cssButtonActiveBackground + ' }' +

                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element .widget-websockettunnel-text { ' + cssInfo + ' }' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element:active .widget-websockettunnel-text { ' + cssButtonActiveText + ' }' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element:hover .widget-websockettunnel-text { ' + cssButtonHoverText + ' }' +
                        '#' + thisWidget.jqElementId + '.widget-websockettunnel .websockettunnel-element:focus { ' + cssButtonFocusBorder + ' }' +

                    '</style>';

                $(styleBlock).prependTo(thisWidget.jqElement);
            }

            // not sure what this is all about, but I'm making it consistent with the DataExport button control ROE 9/28/12
            var buttonTextLineHeight = this.getProperty('Height');
            var buttonAdjustedTextLineHeight = buttonTextLineHeight - (formatResult.lineThickness * 2) + 'px';
            thisWidget.jqElement.find('.widget-websockettunnel-text').css('line-height', buttonAdjustedTextLineHeight);

            if (!isBrowserCompatible()) {
                thisWidget.jqElement.removeClass('widget-websockettunnel');

                if (!thisWidget.jqElement.hasClass('widget-websockettunnel-disabled')) {
                    thisWidget.jqElement.addClass('widget-websockettunnel-disabled');
                }

                thisWidget.jqElement.attr('title', 'Remote device websocket access does not work with IE at this time. Please use the Remote Access widget with Java Web Start to access your devices.');
            } else {

                // first figure out if it's an Edge thing or Connected thing
                var thingName = thisWidget.getProperty('RemoteThingName');

                if (thingName !== undefined) {
                    getTunnelStatusForThing();
                } else {
                    // no thing name yet
                    thisWidget.jqElement.removeClass('widget-websockettunnel');
                    if (!thisWidget.jqElement.hasClass('widget-websockettunnel-disabled')) {
                        thisWidget.jqElement.addClass('widget-websockettunnel-disabled');
                    }
                    thisWidget.jqElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThing]]'));
                }
            }
        }; // afterRender()

        var getTunnelStatusForThing = function () {

            var thingName = thisWidget.getProperty('RemoteThingName');

            var invoker = new ThingworxInvoker({
                entityType: 'Things',
                entityName: thingName,
                characteristic: 'Services',
                // hard coded to GetTunnelStatus of Tunneling ThingShape
                target: 'GetTunnelStatus',
                apiMethod: 'post'
            });

            invoker.invokeService(
                function (invoker) {

                    // hardcoded to jwsUrl field definition of TunnelStatus DataShape
                    //tunnelingURL  = invoker.result.rows[0]['wsUrl'].substring(1);
                    tunnelingURL  = invoker.result.rows[0]['wsUrl'];
                    // hardcoded to enabled field definition of TunnelStatus DataShape
                    tunnelingEnabled = invoker.result.rows[0]['enabled'];

                    if (tunnelingURL.indexOf('RemoteTunnel?target=') > -1) {
                        connectedThing = false;
                    }

                    subSystemEnabled = invoker.result.rows[0]['status'];

                    statusCallbackFunction(subSystemEnabled);

                    if (subSystemEnabled === true) {
                        var widgetProperties = thisWidget.properties;

                        thisWidget.jqElement.on('click', function (e) {
                            // ignore clicks if button is disabled
                            if (!thisWidget.jqElement.hasClass('widget-websockettunnel-disabled')) { // disabled button check

                                var styleBlock =
                                 '<style>' +
                                     'body { margin: 0px; } ' +
                                     '#noVNC_status_bar { width: 100%; } ' +
                                     '#noVNC_status { position: relative; height: auto; } ' +

                                     '#noVNC_buttons button { ' + cssButtonBackground + cssButtonBorder + ' border-radius:' +
                                        cornerRadius + 'px; display: inline; } ' +
                                     '#noVNC_buttons button { margin: 0 3px; ' + cssButtonBackground + cssButtonBorder +
                                        ' border-radius:' + cornerRadius + 'px; } ' +
                                     '#noVNC_buttons button:hover { ' + cssButtonHoverBackground + ' } ' +
                                     '#noVNC_buttons button:active { ' + cssButtonActiveBackground + ' } ' +

                                     '#noVNC_buttons button span { ' + cssInfo + ' }' +
                                     '#noVNC_buttons button:active span { ' + cssButtonActiveText + ' } ' +
                                     '#noVNC_buttons button:hover span { ' + cssButtonHoverText + ' } ' +
                                     '#noVNC_buttons button:focus { ' + cssButtonFocusBorder + ' } ' +
                                     '#noVNC_buttons button:disabled { opacity: 0.5; } ';

                                 if (thisWidget.properties.FitToCenter) {
                                    styleBlock += 'body { width: 100%; height: 100%; } ' +
                                        '#noVNC_container { display: flex; flex-direction: column; width: 100%; height: 100%; } ' +
                                        '#noVNC_inner_container { flex: 1 1 auto; overflow: auto; display: flex; } ' +
                                        '#noVNC_canvas_wrapper { display: inline-block; margin: auto; } ';
                                 }
                                 styleBlock += '</style>';

                                var w = window.open("RemoteAccess", "#");
                                var d = w.document.open();

                                var libraryPath = "../Common/extensions/WebSocketTunnelLibrary_ExtensionPackage/ui/websockettunnellibrary/";
                                var extPath = "../Common/extensions/WebSocketTunnel_ExtensionPackage/ui/websockettunnel/";

                                var scriptResources = '<script type="text/javascript" src="../Common/jquery/jquery-3.3.1.min.js"></script>';
                                scriptResources += '<script type="text/javascript" src="../Common/thingworx/ThingworxInvoker.js"></script>';
                                scriptResources += '<script type="text/javascript" src="../Common/thingworx/thingworx.utility.js"></script>';
                                scriptResources += '<script type="text/javascript" src="../Common/xss/XSS.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'util.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'webutil.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'base64.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'websock.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'des.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'keysymdef.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'keyboard.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'input.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'display.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'rfb.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'keysym.js"></script>';
                                scriptResources += '<script src="' + libraryPath + 'jsunzip.js"></script>';

                                scriptResources += '<script src="' + extPath + 'init.js"></script>';

                                // determine if the connection should be encrypted based on the how TWX is being accessed (via SSL or not) rather
                                // than based on the "Encrypt" config property
                                var encryptConnection = (window.location.protocol === "https:");

                                var script = '<script>' +
                                        '_wstInit({' +
                                            ' thingName: "' + thisWidget.properties.RemoteThingName + '",' +
                                            ' connectedThing: ' + connectedThing + ',' +
                                            ' logLevel: "' + thisWidget.properties.LogLevel + '",' +
                                            ' encryptConnection: ' + encryptConnection + ',' +
                                            ' viewOnly: ' + thisWidget.properties.ViewOnly + ',' +
                                            ' vncPassword: "' + thisWidget.properties.VNCPassword + '",' +
                                            ' tunnelingUrl: "' + tunnelingURL + '",' +
                                            ' tunnelName: "' + thisWidget.properties.TunnelName + '",' +
                                            ' timeOut: ' + thisWidget.properties.Timeout+ ',' +
                                            // status bar messages on for undefined (older mashups with this widget)
                                            ' showStatusMessages: ' + (thisWidget.properties.EnableStatusBarMessages !== false) +
                                        '});' +
                                    '</script>';

                                var body = '<body>' +
                                    '<div id="noVNC_container">' +
                                        '<div id="noVNC_status_bar" class="noVNC_status_bar">' +
                                            '<table border=0 width="100%">' +
                                                '<tr>' +
                                                    '<td>' +
                                                        '<div id="noVNC_buttons">' +
                                                            '<button id="connectButton">' +
                                                               '<span>' + thisWidget.getProperty('ConnectLabel', '[[connect]]') + '</span>' +
                                                            '</button>' +
                                                            '<button id="sendCtrlAltDelButton">' +
                                                                '<span>' + thisWidget.getProperty('InterruptLabel', '[[ctrlAltDel]]') + '</span>' +
                                                            '</button>' +
                                                            '<button id="shutdownButton">' +
                                                                '<span>' + thisWidget.getProperty('DisconnectLabel', '[[disconnect]]') + '</span>' +
                                                            '</button>' +
                                                        '</div>' +
                                                    '</td>' +
                                                    '<td width="100%">' +
                                                        '<div id="noVNC_status"></div>' +
                                                    '</td>' +
                                                '</tr>' +
                                            '</table>' +
                                        '</div>' +
                                        '<div id="noVNC_inner_container">' +
                                            '<div id="noVNC_canvas_wrapper">' +
                                                '<canvas id="noVNC_canvas">Canvas not supported.</canvas>' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>' +
                                    '</body>';

                                d.write("<!DOCTYPE html>" +
                                    "<html>" +
                                    "<head>" +
                                        "<title>" + thisWidget.properties.RemoteThingName + "</title>" +
                                        "<meta charset=\"utf-8\">" +
                                        "<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">" +
                                        "<link rel=\"stylesheet\" href=\"" + libraryPath + "base.css\" title=\"plain\">" +
                                        scriptResources +
                                        script  +
                                        styleBlock +
                                    "</head>" +
                                    body +
                                    "</html>");
                                d.close();
                            } // END disabled button check
                        });
                    }
                },
                function (invoker, xhr) {
                    TW.log.error('websockettunnel.runtime.js: error getting tunnel status for Thing: ' + thingName + '  xhr: "' + JSON.stringify(xhr) + '"');

                    thisWidget.jqElement.removeClass('widget-websockettunnel');
                    if (!thisWidget.jqElement.hasClass('widget-websockettunnel-disabled')) {
                        thisWidget.jqElement.addClass('widget-websockettunnel-disabled');
                    }
                    thisWidget.jqElement.attr('title', TW.Runtime.convertLocalizableString('[[tunnelStatusFailure]]'));
                }
            );
        };

        var statusCallbackFunction = function (status) {
            //TW.log.info('remoteaccess access status is ' + status);
            var widgetElement = widgetReference.jqElement;

            if (isBrowserCompatible()) {
                if (status === true) {

                    var deviceName = widgetReference.getProperty('RemoteThingName');
                    var tunnelName = widgetReference.getProperty('TunnelName');

                    // do we have all the right stuff?
                    if (deviceName !== undefined && deviceName !== '' && tunnelName !== undefined && tunnelName !== '') {
                        // check if device tunneling is enabled
                        //checkDeviceTunnelingEnablement(widgetReference, deviceName);
                        if (tunnelingEnabled === true) {
                            widgetElement.removeClass('widget-websockettunnel-disabled');
                            if (!widgetElement.hasClass('widget-websockettunnel')) {
                                widgetElement.addClass('widget-websockettunnel');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[remoteAccessToRemoteThingAvailable]]') + ' ' + deviceName + '.');
                        } else {
                            // NOT ENABLED FOR THIS DEVICE

                            // remove any classes that may have been displayed up to this point.
                            widgetElement.removeClass('widget-websockettunnel');
                            if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                widgetElement.addClass('widget-websockettunnel-disabled');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[remoteAccessToRemoteThingNotEnabled]]') + ' ' + deviceName + '.');
                        }
                    } else if ((deviceName !== undefined && deviceName !== '') || (tunnelName !== undefined && tunnelName !== '')) {
                        // if device name, check if tunneling is enabled
                        if (deviceName !== undefined && deviceName !== '') {
                            // INCOMPLETE NO TUNNEL
                            widgetElement.removeClass('widget-websockettunnel');
                            if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                widgetElement.addClass('widget-websockettunnel-disabled');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoTunnel]]'));
                        } else if (tunnelName !== undefined && tunnelName !== '') {
                            // INCOMPLETE NO DEVICE
                            widgetElement.removeClass('widget-websockettunnel');
                            if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                widgetElement.addClass('widget-websockettunnel-disabled');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThing]]'));
                        }

                    } else {
                        // DISABLED
                        widgetElement.removeClass('widget-websockettunnel');

                        if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                            widgetElement.addClass('widget-websockettunnel-disabled');
                        }
                        widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThingNoTunnel]]'));
                    }
                } else {
                    widgetElement.removeClass('widget-websockettunnel');

                    if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                        widgetElement.addClass('widget-websockettunnel-disabled');
                    }

                    if (connectedThing) {
                        widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[tunnelSubsystemNotRunning]]'));
                    } else {
                        widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[xmppNotRunning]]'));
                    }
                }
            }
        }; // statusCallbackFunction()

        this.updateProperty = function (updatePropertyInfo) {

            var widgetElement = this.jqElement;

            //TW.log.info('remoteaccess updateProperty updatePropertyInfo.TargetProperty: "' + updatePropertyInfo.TargetProperty + '", updatePropertyInfo.RawSinglePropertyValue: "' + updatePropertyInfo.RawSinglePropertyValue + '"');

            // set the new value (whatever it is for whichever property) in the widget property bag
            this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);

            var deviceName = this.getProperty('RemoteThingName');
            var tunnelName = this.getProperty('TunnelName');

            switch (updatePropertyInfo.TargetProperty) {
                case 'Label':
                    widgetElement.find('.widget-websockettunnel-text').text(updatePropertyInfo.RawSinglePropertyValue);
                    break;
                case 'RemoteThingName':
                    if (!TW.Environment.Browser.isIE) {
                            // thing name goes through here, but we only call it if we have a thing name - no point otherwise
                            if (deviceName !== undefined) {
                                getTunnelStatusForThing();
                            } else {
                                widgetElement.removeClass('widget-websockettunnel');
                                if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                    widgetElement.addClass('widget-websockettunnel-disabled');
                                }
                                widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThing]]'));
                            }
                        }
                    break;
                case 'TunnelName':
                    // TODO: can we assume the device is enabled?
                    if (isBrowserCompatible()) {
                        if (deviceName !== undefined && deviceName !== '' && tunnelName !== undefined && tunnelName !== '') {
                            // because we assume the device has been validated, we can check if it's enabled
                            if (tunnelingEnabled === true && subSystemEnabled === true) {
                                if (!widgetElement.hasClass('widget-websockettunnel-notenabled')) {
                                    widgetElement.removeClass('widget-websockettunnel-incomplete');
                                    widgetElement.removeClass('widget-websockettunnel-disabled');
                                    if (!widgetElement.hasClass('widget-websockettunnel')) {
                                        widgetElement.addClass('widget-websockettunnel');
                                    }

                                    // clear the div title
                                    widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[remoteAccessToRemoteThingAvailable]]') + ' ' + deviceName + '.');
                                }
                            } else if (subSystemEnabled === false) {
                                // NOT ENABLED subsystem

                                // remove any classes that may have been displayed up to this point.
                                widgetElement.removeClass('widget-websockettunnel');
                                if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                    widgetElement.addClass('widget-websockettunnel-disabled');
                                }
                                if (connectedThing) {
                                    widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[tunnelSubsystemNotRunning]]'));
                                } else {
                                    widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[xmppNotRunning]]'));
                                }
                            } else {
                                // NOT ENABLED FOR THIS DEVICE

                                // remove any classes that may have been displayed up to this point.
                                widgetElement.removeClass('widget-websockettunnel');
                                if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                    widgetElement.addClass('widget-websockettunnel-disabled');
                                }
                                widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[remoteAccessToRemoteThingNotEnabled]]') + ' ' + deviceName + '.');
                            }
                        } else if (deviceName !== undefined && deviceName !== '' && (tunnelName === undefined || tunnelName === '')) {
                            // INCOMPLETE NO TUNNEL
                            if (!widgetElement.hasClass('widget-websockettunnel-notenabled')) {
                                widgetElement.removeClass('widget-websockettunnel');
                                widgetElement.removeClass('widget-websockettunnel-disabled');
                                if (!widgetElement.hasClass('widget-websockettunnel-incomplete')) {
                                    widgetElement.addClass('widget-websockettunnel-incomplete');
                                }
                                widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoTunnel]]'));
                            }
                        } else if ((deviceName === undefined || deviceName === '') && (tunnelName !== undefined && tunnelName !== '')) {
                            // INCOMPLETE NO DEVICE

                            widgetElement.removeClass('widget-websockettunnel');
                            if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                widgetElement.addClass('widget-websockettunnel-disabled');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThing]]'));
                        } else if ((deviceName === undefined || deviceName === '') && (tunnelName === undefined || tunnelName === '')) {
                            // everything cleared out

                            // DISABLED

                            widgetElement.removeClass('widget-websockettunnel');
                            if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                widgetElement.addClass('widget-websockettunnel-disabled');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThingNoTunnel]]'));
                        } else {
                            // can't determine status

                            // DISABLED

                            widgetElement.removeClass('widget-websockettunnel');
                            if (!widgetElement.hasClass('widget-websockettunnel-disabled')) {
                                widgetElement.addClass('widget-websockettunnel-disabled');
                            }
                            widgetElement.attr('title', TW.Runtime.convertLocalizableString('[[incompleteRemoteAccessConfigNoThingNoTunnel]]'));
                        }
                    }
                    break;
            }
        };

        this.beforeDestroy = function () {

        };
    };
}());
