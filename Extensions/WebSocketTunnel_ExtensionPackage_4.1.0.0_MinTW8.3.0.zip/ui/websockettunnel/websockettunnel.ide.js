/*global Encoder, TW */

TW.IDE.Widgets.websockettunnel = function () {
    this.widgetProperties = function () {
        return {
            name:          'Web Socket Tunnel',
            description:   'Enables connection to a remote thing via web socket',
            category:      ['Common', 'Component'],
            iconImage:     'remoteAccess.png',
            isExtension:   true,
            isResizable:   true,
            supportsLabel: false,
            properties: {
                Label: {
                    description:     'Text of the Remote Device button.',
                    defaultValue:    'Remote Device',
                    baseType:        'STRING',
                    isBindingTarget: true,
                    isLocalizable:   true
                },
                TabSequence: {
                    description:  'Tab sequence index.',
                    defaultValue: 0,
                    baseType:     'NUMBER'
                },
                RemoteThingName: {
                    description:     'The name of the Remote Thing to access. Must extend the RemoteThing ThingPackage.',
                    defaultValue:    undefined,
                    baseType:        'THINGNAME',
                    isBindingTarget: true,
                    mustImplement: {
                        EntityType: 'ThingShapes',
                        EntityName: 'Tunneling'
                    }
                },
                TunnelName: {
                    description:     'The name of the tunnel for remote access. Can be bound to a Remote Thing\'s getTunnelNames service.',
                    defaultValue:    undefined,
                    baseType:        'STRING',
                    isBindingTarget: true
                },
                VNCPassword: {
                    description:     'The password used to access the VNC server.',
                    defaultValue:    undefined,
                    baseType:        'STRING',
                    isBindingTarget: true
                },
                Timeout: {
                    description:  'Time to create tunnel (msec).',
                    defaultValue: 300000,
                    baseType:     'NUMBER'
                },
                LogLevel: {
                    description:   'Log level for NoVNC execution.',
                    defaultValue:  'warn',
                    baseType:      'STRING',
                    selectOptions: [
                        {value: 'debug', text: 'Debug'},
                        {value: 'info',  text: 'Info'},
                        {value: 'warn',  text: 'Warn'},
                        {value: 'error', text: 'Error'}
                    ]
                },
                Encrypt: {
                    description:  'Set to true when making web socket connections on a secured server (SSL/HTTPS). The value of this property is no longer determining whether or not the connection is using SSL, instead it&apos;s determined by the current connection to Thingworx and whether it&apos;s being accessed via SSL or not',
                    defaultValue: true,
                    baseType:     'BOOLEAN'
                },
                ViewOnly: {
                    description:  'Set to true when connection is view only and no interaction with remote device is desired.',
                    defaultValue: false,
                    baseType:     'BOOLEAN'
                },
                EnableStatusBarMessages: {
                    description:  'Display VNC status messages.',
                    defaultValue: true,
                    baseType:     'BOOLEAN'
                },
                FitToCenter: {
                    description:  'Centers the layout for the connected UI.',
                    defaultValue: false,
                    baseType:     'BOOLEAN'
                },
                RoundedCorners: {
                    description:  'Remote Device button corner style.',
                    defaultValue: true,
                    baseType:     'BOOLEAN'
                },
                ConnectLabel: {
                    description:   'Text of the Connect button.',
                    defaultValue:  '[[connect]]',
                    baseType:      'STRING',
                    isLocalizable: true
                },
                DisconnectLabel: {
                    description:   'Text of the Disconnect button.',
                    defaultValue:  '[[disconnect]]',
                    baseType:      'STRING',
                    isLocalizable: true
                },
                InterruptLabel: {
                    description:   'Text of the Interrupt button.',
                    defaultValue:  '[[ctrlAltDel]]',
                    baseType:      'STRING',
                    isLocalizable: true
                },
                Style: {
                    defaultValue: 'DefaultButtonStyle',
                    baseType:     'STYLEDEFINITION'
                },
                HoverStyle: {
                    defaultValue: 'DefaultButtonHoverStyle',
                    baseType:     'STYLEDEFINITION'
                },
                ActiveStyle: {
                    defaultValue: 'DefaultButtonActiveStyle',
                    baseType:     'STYLEDEFINITION'
                },
                FocusStyle: {
                    defaultValue: 'DefaultButtonFocusStyle',
                    baseType:     'STYLEDEFINITION'
                },
                Width: {
                    description:  'width of widget',
                    defaultValue: 100,
                    baseType:     'NUMBER'
                },
                Height: {
                    description:  'height of widget',
                    defaultValue: 30,
                    baseType:     'NUMBER'
                }
            }
        };
    };

    this.widgetIconUrl = function() {
        return  "../Common/extensions/WebSocketTunnel_ExtensionPackage/ui/websockettunnel/remoteAccess.png";
    };

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Height':
            case 'HoverStyle':
            case 'Label':
            case 'Left':
            case 'RoundedCorners':
            case 'Style':
            case 'Top':
            case 'Width':
            case 'Z-index':
                result = true;
                break;

            default:
                break;
        }
        return result;
    };

    this.renderHtml = function () {
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));

        var buttonBorderWidth = TW.getStyleCssBorderWidthOnlyFromStyle(formatResult);
        var adjustedWrapperWidth = this.getProperty('Width') - buttonBorderWidth * 2;
        var adjustedWrapperHeight = this.getProperty('Height') - buttonBorderWidth * 2;

        var config = {
            height:        adjustedWrapperHeight,
            img:           '',
            label:         'Remote Device',
            textSizeClass: 'textsize-normal',
            width:         adjustedWrapperWidth
        };

        if (formatResult.image !== undefined && formatResult.image.length > 0) {
            config.img = '<img src="' + formatResult.image + '"/>';
        }

        if (this.getProperty('Style') !== undefined) {
            config.textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
        }

        if (this.getProperty('Label') !== undefined) {
            config.label = Encoder.htmlEncode(this.getProperty('Label'));
        }

        var widgetTemplate = _.template(
            '<div class="widget-content widget-websockettunnel">' +
                '<div class="widget-websockettunnel-wrapper" ' +
                'style="width:<%= width %>px; height:<%= height %>px;">' +
                    '<table border="0" cellpadding="0" cellspacing="0" cellborder="0" height="100%" width="100%">' +
                        '<tr>' +
                            '<td align="center" height="100%" width="100%" valign="middle">' +
                                '<%= img %>' +
                                '<span class="widget-websockettunnel-text <%= textSizeClass %>"><%= label %></span>' +
                            '</td>' +
                        '</tr>' +
                    '</table>' +
                '</div>' +
            '</div>'
        );

        return widgetTemplate(config);
    };

    this.afterRender = function () {
        var thisWidget = this;

        var buttonStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));
        var buttonHoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle'));

        var buttonBackground = TW.getStyleCssGradientFromStyle(buttonStyle);
        var buttonText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonStyle);
        var buttonBorder = TW.getStyleCssBorderFromStyle(buttonStyle);
        var buttonHoverBG = TW.getStyleCssGradientFromStyle(buttonHoverStyle);
        var buttonHoverText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonHoverStyle);
        var buttonHoverBorder = TW.getStyleCssBorderFromStyle(buttonHoverStyle);

        var roundedCorners = this.getProperty('RoundedCorners', true);

        var cornerRadius = '';

        if (roundedCorners) {
            cornerRadius = 'border-radius: 6px;';
        }

        var styleBlock = '<style>' +
                '#' + thisWidget.jqElementId + '.widget-websockettunnel table{'+ buttonText + ' } ' +
                '#' + thisWidget.jqElementId + '.widget-websockettunnel .widget-websockettunnel-wrapper {'+ buttonBackground + buttonBorder + cornerRadius + '}' +
                '#' + thisWidget.jqElementId + '.widget-websockettunnel:hover .widget-websockettunnel-wrapper {' + buttonHoverBG + buttonHoverBorder + '}' +
                '#' + thisWidget.jqElementId + '.widget-websockettunnel:hover table span {'+ buttonHoverText + ' } ' +
            '</style>';

        $(styleBlock).prependTo(thisWidget.jqElement);
    };

    this.validate = function () {
        var result = [];

        var deviceName = this.getProperty('RemoteThingName', '');

        if (deviceName === '' && this.isPropertyBoundAsTarget('RemoteThingName') === false) {
            result.push({severity: 'warning', message: 'RemoteThingName is not defined or bound for {target-id}' });
        }

        var tunnelName = this.getProperty('TunnelName', '');

        if (tunnelName === '' && this.isPropertyBoundAsTarget('TunnelName') === false) {
            result.push({severity: 'warning', message: 'TunnelName is not defined or bound for {target-id}' });
        }

        return result;
    };
};